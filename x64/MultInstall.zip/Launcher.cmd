@echo off
title MultiInstall - Lancement

:: 1. Vérifier droits admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo Demande des droits administrateur...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: 2. Aller dans le dossier du script
cd /d "%~dp0"

:: 3. Lancer le script PowerShell
powershell -NoProfile -ExecutionPolicy Bypass -File "MultInstall.ps1"


:: 4. Nettoyage et Auto-destruction
:: On se déplace à la racine pour ne pas bloquer le dossier
cd /d C:\

:: On lance une petite commande cachée indépendante qui attend 1 seconde (le temps que ce script se ferme)
:: puis supprime le dossier C:\temp\MultiInstall
start /b "" cmd /c "timeout /t 1 >nul & rmdir /s /q C:\temp\MultiInstall"

:: On ferme immédiatement ce script pour relâcher le verrou
exit