﻿

# Dossier de travail pour les téléchargements temporaires de MultInstall
# (ex-C:\temp - maintenant dans le dossier Temp standard de Windows)
$env:MultInstall = $env:TEMP

Add-Type -AssemblyName System.Windows.Forms, System.Drawing, Microsoft.VisualBasic
[System.Windows.Forms.Application]::EnableVisualStyles()

# Clés de licence (Office, ESET, ...) : stockées hors du script dans MultInstall.keys.ps1
# (fichier local, non versionné — voir .gitignore) pour ne pas exposer les licences
# dans le code source public. Si absent, l'utilisateur est invité à saisir la clé.
$script:MultInstallKeys = @{ }
$keysFile = Join-Path $PSScriptRoot "MultInstall.keys.ps1"
if (Test-Path $keysFile)
{
	try { . $keysFile } catch { }
}

function Get-MultInstallKey
{
	param ([string]$Name,
		[string]$Prompt)

	if ($script:MultInstallKeys.ContainsKey($Name) -and $script:MultInstallKeys[$Name])
	{
		return $script:MultInstallKeys[$Name]
	}

	return [Microsoft.VisualBasic.Interaction]::InputBox($Prompt, "Clé de licence requise", "")
}

function Test-Admin
{
	$currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
	return $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Admin))
{
	[System.Windows.Forms.MessageBox]::Show("Ce script nécessite des privilèges d'administration. Veuillez exécuter le script en tant qu'administrateur.", "Demande de privilèges d'administration", [System.Windows.Forms.MessageBoxButtons]::OKCancel, [System.Windows.Forms.MessageBoxIcon]::Information)
	exit
}

function Test-WingetInstalled
{
	try
	{
		$null = Get-Command winget -ErrorAction Stop
		return $true
	}
	catch
	{
		return $false
	}
}

function Hide-ConsoleWindow
{
	try
	{
		if (-not ([System.Management.Automation.PSTypeName]'ConsoleHelper.Window').Type)
		{
			Add-Type -Namespace ConsoleHelper -Name Window -MemberDefinition '
				[DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
				[DllImport("user32.dll")]  public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
			'
		}
		[ConsoleHelper.Window]::ShowWindow([ConsoleHelper.Window]::GetConsoleWindow(), 0) | Out-Null
	}
	catch { }
}

function Show-InputBox($Message, $WindowTitle, $DefaultValue)
{
	return [Microsoft.VisualBasic.Interaction]::InputBox($Message, $WindowTitle, $DefaultValue)
}
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#désactivé
#function Run-Script($scriptPath, $arguments)
#{
	
#	$process = New-Object System.Diagnostics.Process
#	$process.StartInfo.FileName = "cscript"
#	$process.StartInfo.Arguments = "`"$scriptPath`" $arguments"
#	$process.StartInfo.RedirectStandardOutput = $true
#	$process.StartInfo.UseShellExecute = $false
#	$process.Start()
	
#	return $process.StandardOutput.ReadToEnd()
#}

##########################################  Fonction Mot de passe ################################################
$code = @"
using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

public class RoundButton : Button
{
    private bool _hover = false;
    private bool _pressed = false;
    public RoundButton()
    {
        this.FlatStyle = FlatStyle.Flat;
        this.FlatAppearance.BorderSize = 0;
        this.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
    }
    protected override void OnMouseEnter(EventArgs e) { _hover = true; this.Invalidate(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { _hover = false; _pressed = false; this.Invalidate(); base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { _pressed = true; this.Invalidate(); base.OnMouseDown(e); }
    protected override void OnMouseUp(MouseEventArgs e) { _pressed = false; this.Invalidate(); base.OnMouseUp(e); }
    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        Rectangle rect = new Rectangle(0, 0, this.Width, this.Height);
        Color baseC = this.Enabled ? this.BackColor : Color.FromArgb(120, 120, 120);
        if (this.Enabled)
        {
            if (_pressed) baseC = ControlPaint.Dark(baseC, 0.12f);
            else if (_hover) baseC = ControlPaint.Light(baseC, 0.18f);
        }
        Color topC = ControlPaint.Light(baseC, 0.25f);
        Color botC = ControlPaint.Dark(baseC, 0.10f);
        Color c1 = _pressed ? botC : topC;
        Color c2 = _pressed ? topC : botC;
        using (LinearGradientBrush br = new LinearGradientBrush(rect, c1, c2, LinearGradientMode.Vertical))
        {
            g.FillRectangle(br, rect);
        }
        float bw = _hover ? 3f : 2f;
        Color borderC = _hover ? Color.White : Color.FromArgb(230, 255, 255, 255);
        using (Pen pen = new Pen(borderC, bw))
        {
            int o = (int)(bw / 2);
            g.DrawRectangle(pen, o, o, this.Width - (int)bw - 1, this.Height - (int)bw - 1);
        }
        Color txt = this.Enabled ? this.ForeColor : Color.FromArgb(225, 225, 225);
        TextFormatFlags flags = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak | TextFormatFlags.EndEllipsis;
        if (!this.UseMnemonic) { flags = flags | TextFormatFlags.NoPrefix; }
        Rectangle tr = Rectangle.Inflate(rect, -6, -2);
        if (_pressed) { tr.Offset(0, 1); }
        TextRenderer.DrawText(g, this.Text, this.Font, tr, txt, flags);
    }
}
"@

Add-Type -TypeDefinition $code -ReferencedAssemblies System.Windows.Forms, System.Drawing

function MotDePasse
{
	# Dimensions de la carte
	$windowWidth = 460
	$windowHeight = 300

	$form = New-Object System.Windows.Forms.Form
	$form.Text = 'Securite'
	$form.ClientSize = [System.Drawing.Size]::new($windowWidth, $windowHeight)
	$form.StartPosition = 'CenterScreen'
	$form.FormBorderStyle = 'None'
	$form.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
	$form.TopMost = $true

	# Couleur d'accent aleatoire (gardee) + variantes
	$random = New-Object System.Random
	$accent = [System.Drawing.Color]::FromArgb($random.Next(70, 256), $random.Next(70, 256), $random.Next(70, 256))
	$accent2 = [System.Drawing.Color]::FromArgb([Math]::Max(0, $accent.R - 80), [Math]::Max(0, $accent.G - 80), [Math]::Max(0, $accent.B - 80))
	$lum = (0.299 * $accent.R + 0.587 * $accent.G + 0.114 * $accent.B)
	$accentText = if ($lum -gt 150) { [System.Drawing.Color]::FromArgb(15, 23, 42) } else { [System.Drawing.Color]::White }

	# Coins arrondis
	$gp = New-Object System.Drawing.Drawing2D.GraphicsPath
	$rad = 20
	$gp.AddArc(0, 0, $rad, $rad, 180, 90)
	$gp.AddArc($windowWidth - $rad, 0, $rad, $rad, 270, 90)
	$gp.AddArc($windowWidth - $rad, $windowHeight - $rad, $rad, $rad, 0, 90)
	$gp.AddArc(0, $windowHeight - $rad, $rad, $rad, 90, 90)
	$gp.CloseAllFigures()
	$form.Region = New-Object System.Drawing.Region($gp)

	# En-tete avec degrade peint + icone cadenas + titre
	$header = New-Object System.Windows.Forms.Panel
	$header.Size = [System.Drawing.Size]::new($windowWidth, 116)
	$header.Location = [System.Drawing.Point]::new(0, 0)
	$header.Add_Paint({
			param($s, $e)
			$g = $e.Graphics
			$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
			$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::ClearTypeGridFit
			$rect = New-Object System.Drawing.Rectangle(0, 0, $s.Width, $s.Height)
			$br = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, $accent, $accent2, 60)
			$g.FillRectangle($br, $rect); $br.Dispose()
			# Pastille translucide + icone cadenas (Segoe MDL2 Assets)
			$circle = New-Object System.Drawing.Drawing2D.GraphicsPath
			$circle.AddEllipse(28, 30, 54, 54)
			$wb = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(60, 255, 255, 255))
			$g.FillPath($wb, $circle); $wb.Dispose(); $circle.Dispose()
			$iconFont = New-Object System.Drawing.Font('Segoe MDL2 Assets', 22)
			$iconBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::White)
			$g.DrawString([System.Char]::ConvertFromUtf32(0xE72E), $iconFont, $iconBrush, 39, 36)
			$titleFont = New-Object System.Drawing.Font('Segoe UI Semibold', 16)
			$subFont = New-Object System.Drawing.Font('Segoe UI', 9.5)
			$tb = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::White)
			$sb = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(235, 255, 255, 255))
			$g.DrawString('Acces securise', $titleFont, $tb, 98, 38)
			$g.DrawString('Saisissez votre mot de passe', $subFont, $sb, 100, 70)
			$iconFont.Dispose(); $iconBrush.Dispose(); $titleFont.Dispose(); $subFont.Dispose(); $tb.Dispose(); $sb.Dispose()
		})
	$form.Controls.Add($header)

	# Bouton fermer
	$btnClose = New-Object System.Windows.Forms.Button
	$btnClose.Text = 'X'
	$btnClose.Size = [System.Drawing.Size]::new(30, 26)
	$btnClose.Location = [System.Drawing.Point]::new($windowWidth - 38, 10)
	$btnClose.FlatStyle = 'Flat'
	$btnClose.FlatAppearance.BorderSize = 0
	$btnClose.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(80, 255, 255, 255)
	$btnClose.BackColor = [System.Drawing.Color]::Transparent
	$btnClose.ForeColor = [System.Drawing.Color]::White
	$btnClose.Font = New-Object System.Drawing.Font('Segoe UI', 10)
	$btnClose.DialogResult = 'Cancel'
	$btnClose.TabStop = $false
	$header.Controls.Add($btnClose)
	$form.CancelButton = $btnClose

	# Champ mot de passe
	$passwordBox = New-Object System.Windows.Forms.TextBox
	$passwordBox.UseSystemPasswordChar = $true
	$passwordBox.BorderStyle = 'FixedSingle'
	$passwordBox.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59)
	$passwordBox.ForeColor = [System.Drawing.Color]::White
	$passwordBox.Font = New-Object System.Drawing.Font('Segoe UI', 13)
	$passwordBox.Size = [System.Drawing.Size]::new($windowWidth - 64, 34)
	$passwordBox.Location = [System.Drawing.Point]::new(32, 140)
	$passwordBox.Add_KeyDown({ if ($_.KeyCode -eq 'Enter') { $form.DialogResult = 'OK' } })
	$form.Controls.Add($passwordBox)

	# Soulignement d'accent sous le champ
	$underline = New-Object System.Windows.Forms.Panel
	$underline.Size = [System.Drawing.Size]::new($windowWidth - 64, 3)
	$underline.Location = [System.Drawing.Point]::new(32, 140 + $passwordBox.Height + 1)
	$underline.BackColor = $accent
	$form.Controls.Add($underline)

	# Bouton deverrouiller (couleur d'accent)
	$button = New-Object RoundButton
	$button.Text = 'Deverrouiller'
	$button.DialogResult = 'OK'
	$button.BackColor = $accent
	$button.ForeColor = $accentText
	$button.FlatStyle = 'Flat'
	$button.FlatAppearance.BorderSize = 0
	$button.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 11)
	$button.Size = [System.Drawing.Size]::new($windowWidth - 64, 46)
	$button.Location = [System.Drawing.Point]::new(32, 200)
	$form.Controls.Add($button)
	$form.AcceptButton = $button

	# Pied de page
	$label = New-Object System.Windows.Forms.Label
	$label.Text = 'Entree pour valider  -  Echap pour annuler'
	$label.ForeColor = [System.Drawing.Color]::FromArgb(100, 116, 139)
	$label.Font = New-Object System.Drawing.Font('Segoe UI', 8)
	$label.AutoSize = $true
	$label.BackColor = [System.Drawing.Color]::Transparent
	$label.Location = [System.Drawing.Point]::new(32, 262)
	$form.Controls.Add($label)

	# Deplacement de la fenetre (sans bordure)
	$dragDown = { $script:pwDrag = $true; $script:pwStart = [System.Windows.Forms.Cursor]::Position; $script:pwLoc = $form.Location }
	$dragMove = { if ($script:pwDrag) { $cur = [System.Windows.Forms.Cursor]::Position; $form.Location = [System.Drawing.Point]::new($script:pwLoc.X + ($cur.X - $script:pwStart.X), $script:pwLoc.Y + ($cur.Y - $script:pwStart.Y)) } }
	$dragUp = { $script:pwDrag = $false }
	foreach ($ctl in @($form, $header)) { $ctl.Add_MouseDown($dragDown); $ctl.Add_MouseMove($dragMove); $ctl.Add_MouseUp($dragUp) }

	$form.Add_Shown({ $form.Activate(); $passwordBox.Focus() })
	
	$attempts = 0
	$maxAttempts = 3
	$correctHash = 'f85e3bc79a5ea6636aacacfbd2a9fb0d69add009fe0ea89b79cf9827185acc35' # SHA256 hash du mot de passe 
	
	while ($attempts -lt $maxAttempts)
	{
		if ($form.ShowDialog() -eq 'OK')
		{
			$inputHash = Get-StringHash $passwordBox.Text
			
			if ($inputHash -eq $correctHash)
			{
				$form.Close()
				return
			}
			else
			{
				$attempts++
				if ($attempts -eq $maxAttempts)
				{
					[System.Windows.Forms.MessageBox]::Show("Nombre maximum de tentatives atteint. Arrêt du script.", "Erreur", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
					$form.Close()
					exit
				}
				$passwordBox.Text = ""
			}
		}
		else
		{
			$form.Close()
			exit
		}
	}
}

function Get-StringHash
{
	param (
		[String]$String
	)
	$StringBuilder = New-Object System.Text.StringBuilder
	[System.Security.Cryptography.HashAlgorithm]::Create("SHA256").ComputeHash([System.Text.Encoding]::UTF8.GetBytes($String)) | ForEach-Object {
		[Void]$StringBuilder.Append($_.ToString("x2"))
	}
	$StringBuilder.ToString()
}


######################################################################################################################################################
#########################################################   FONCTIONS DE BOUTONS    ##################################################################
######################################################################################################################################################




#222222222222222222222222222222222222222222222222222   Installation Programmes de Base  2222222222222222222222222222222222222222222222222222222222222
function ProgBase
{ # Liste des applications à installer
	$appsToInstall = @(
		"AnyDesk.AnyDesk",
		"7zip.7zip",
		"FastStone.Viewer",
		"SumatraPDF.SumatraPDF",
		"Greenshot.Greenshot",
		"Mozilla.Firefox.fr",
		"Notepad++.Notepad++",
		"TeamViewer.TeamViewer",
		"VideoLAN.VLC",
		"RARLab.WinRAR",
		"Microsoft.PowerShell",
		"Adobe.Acrobat.Reader.64-bit",
		"Google.Chrome",
		"CodecGuide.K-LiteCodecPack.Full",
		"dotPDN.PaintDotNet"
	)
	
	# Sysinternals - uniquement la Suite complète
	$sysinternalsApps = @(
		"Microsoft.Sysinternals.Suite"
	)
	
	$allApps = $appsToInstall + $sysinternalsApps
	
	$textBox.AppendText("=== Démarrage de l'installation ===" + [Environment]::NewLine)
	$textBox.AppendText("Nombre total d'applications : $($allApps.Count)" + [Environment]::NewLine + [Environment]::NewLine)
	
	foreach ($id in $allApps)
	{
		$textBox.AppendText("► Installation : $id" + [Environment]::NewLine)
		[System.Windows.Forms.Application]::DoEvents()

		# Fichiers temporaires uniques par itération pour éviter les conflits de handles
		$safeId   = $id -replace '[^a-zA-Z0-9]', '_'
		$stdoutTmp = "$env:TEMP\winget_stdout_$safeId.txt"
		$stderrTmp = "$env:TEMP\winget_stderr_$safeId.txt"

		try
		{
			# Construction des arguments
			$arguments = @(
				"install",
				"--id", $id,
				"--accept-package-agreements",
				"--accept-source-agreements",
				"--silent"
			)

			# Exécution de winget (sans -Wait pour ne pas bloquer l'UI)
			$process = Start-Process -FilePath "winget.exe" `
									 -ArgumentList $arguments `
									 -PassThru `
									 -WindowStyle Hidden `
									 -RedirectStandardOutput $stdoutTmp `
									 -RedirectStandardError  $stderrTmp
			# Attente non-bloquante : DoEvents() pendant l'installation
			while (-not $process.HasExited) {
				[System.Windows.Forms.Application]::DoEvents()
				Start-Sleep -Milliseconds 200
			}

			# Analyse du code de sortie
			switch ($process.ExitCode)
			{
				0 {
					$textBox.AppendText("  ✓ Installé avec succès" + [Environment]::NewLine)
				}
				-1978335189 {
					$textBox.AppendText("  ℹ Déjà installé (version à jour)" + [Environment]::NewLine)
				}
				-1978335216 {
					$stderr = Get-Content $stderrTmp -ErrorAction SilentlyContinue | Select-Object -Last 3
					$textBox.AppendText("  ✗ Aucun installateur applicable" + [Environment]::NewLine)
					if ($stderr)
					{
						$textBox.AppendText("     Détail : $($stderr -join ' | ')" + [Environment]::NewLine)
					}
				}
				default {
					$textBox.AppendText("  ✗ Erreur code : $($process.ExitCode)" + [Environment]::NewLine)
				}
			}
		}
		catch
		{
			$textBox.AppendText("  ✗ Exception : $($_.Exception.Message)" + [Environment]::NewLine)
		}
		finally
		{
			# Nettoyage des fichiers temporaires de cette itération
			Remove-Item $stdoutTmp -ErrorAction SilentlyContinue
			Remove-Item $stderrTmp -ErrorAction SilentlyContinue
		}

		$textBox.AppendText([Environment]::NewLine)
		[System.Windows.Forms.Application]::DoEvents()
	}

	$textBox.AppendText("=== Installation terminée ===" + [Environment]::NewLine)
	Add-Content -Path "$env:TEMP\logfile.txt" -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Installation batch terminée"

}

# Lance une fonction (qui ecrit dans $textBox) dans une fenetre de log en arriere-plan : libere le launcher
function Invoke-BgFunc($funcBody, $title)
{
	# On passe le CODE SOURCE (.ToString()) et on le recompile dans le nouveau runspace via
	# [ScriptBlock]::Create() : passer le ScriptBlock vivant garde une affinite avec le runspace
	# principal occupe -> la fenetre se fige. Source recompilee = runspace enfant complet (cmdlets OK).
	$funcSrc = $funcBody.ToString()
	$iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
	$rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace($iss)
	$rs.ApartmentState = "STA"; $rs.ThreadOptions = "ReuseThread"; $rs.Open()
	$ps = [System.Management.Automation.PowerShell]::Create()
	$ps.Runspace = $rs
	$bgScript = @'
param($src, $title)
$env:PSModulePath = "$PSHOME\Modules;" + [Environment]::GetEnvironmentVariable('PSModulePath','Machine') + ';' + [Environment]::GetEnvironmentVariable('PSModulePath','User')
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
$win = New-Object System.Windows.Forms.Form
$win.Text = $title
$win.Size = New-Object System.Drawing.Size(760, 520)
$win.StartPosition = "CenterScreen"
$win.BackColor = [System.Drawing.Color]::FromArgb(243, 244, 246)
$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Multiline = $true; $textBox.ScrollBars = "Vertical"; $textBox.ReadOnly = $true; $textBox.Dock = "Fill"
$textBox.BackColor = [System.Drawing.Color]::FromArgb(17, 24, 39); $textBox.ForeColor = [System.Drawing.Color]::FromArgb(229, 231, 235)
$textBox.Font = New-Object System.Drawing.Font("Consolas", 9); $textBox.BorderStyle = "None"
$pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 46; $pBot.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59)
$bClose = New-Object System.Windows.Forms.Button
$bClose.Text = "Fermer"; $bClose.Size = New-Object System.Drawing.Size(110, 32); $bClose.Location = New-Object System.Drawing.Point(636, 7)
$bClose.FlatStyle = "Flat"; $bClose.FlatAppearance.BorderSize = 0
$bClose.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $bClose.ForeColor = [System.Drawing.Color]::White; $bClose.Enabled = $false
$bClose.Add_Click({ $win.Close() })
$pBot.Controls.Add($bClose)
$win.Controls.Add($textBox); $win.Controls.Add($pBot)
$win.Add_Shown({
	try { & ([ScriptBlock]::Create($src)) } catch { $textBox.AppendText("Erreur : " + $_.Exception.Message + [Environment]::NewLine) }
	if (-not $win.IsDisposed) { $textBox.AppendText([Environment]::NewLine + "=== Termine ===" + [Environment]::NewLine); $bClose.Enabled = $true }
})
[void]$win.ShowDialog()
'@
	$null = $ps.AddScript($bgScript).AddParameter('src', $funcSrc).AddParameter('title', $title).BeginInvoke()
}

# Version autonome (fenetre dediee) lancee en arriere-plan : ne bloque plus le launcher
function ProgBaseWin
{
	Add-Type -AssemblyName System.Windows.Forms, System.Drawing
	function global:JLog($m){ try { $jd=Join-Path $env:ProgramData "MultInstall"; if(-not(Test-Path $jd)){New-Item $jd -ItemType Directory -Force -ErrorAction SilentlyContinue|Out-Null}; Add-Content -Path (Join-Path $jd "journal.txt") -Value ("["+(Get-Date -Format "dd/MM HH:mm")+"] "+$m) -Encoding UTF8 -ErrorAction SilentlyContinue } catch {} }
	$allApps = @(
		"AnyDesk.AnyDesk","7zip.7zip","FastStone.Viewer","SumatraPDF.SumatraPDF","Greenshot.Greenshot",
		"Mozilla.Firefox.fr","Notepad++.Notepad++","TeamViewer.TeamViewer","VideoLAN.VLC","RARLab.WinRAR",
		"Microsoft.PowerShell","Adobe.Acrobat.Reader.64-bit","Google.Chrome","CodecGuide.K-LiteCodecPack.Full",
		"dotPDN.PaintDotNet","Microsoft.Sysinternals.Suite"
	)
	$f = New-Object System.Windows.Forms.Form
	$f.Text = "Programmes de base - Installation"
	$f.Size = New-Object System.Drawing.Size(780, 540)
	$f.StartPosition = "CenterScreen"
	$f.BackColor = [System.Drawing.Color]::FromArgb(243, 244, 246)
	$pb = New-Object System.Windows.Forms.ProgressBar
	$pb.Dock = "Top"; $pb.Height = 10; $pb.Style = "Continuous"; $pb.Minimum = 0; $pb.Maximum = $allApps.Count
	$tb = New-Object System.Windows.Forms.TextBox
	$tb.Multiline = $true; $tb.ScrollBars = "Vertical"; $tb.ReadOnly = $true; $tb.Dock = "Fill"
	$tb.BackColor = [System.Drawing.Color]::FromArgb(17, 24, 39); $tb.ForeColor = [System.Drawing.Color]::FromArgb(229, 231, 235)
	$tb.Font = New-Object System.Drawing.Font("Consolas", 9); $tb.BorderStyle = "None"
	$pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 46; $pBot.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59)
	$bClose = New-Object System.Windows.Forms.Button
	$bClose.Text = "Annuler"; $bClose.Size = New-Object System.Drawing.Size(140, 32); $bClose.Location = New-Object System.Drawing.Point(626, 7)
	$bClose.FlatStyle = "Flat"; $bClose.FlatAppearance.BorderSize = 0
	$bClose.BackColor = [System.Drawing.Color]::FromArgb(220, 38, 38); $bClose.ForeColor = [System.Drawing.Color]::White
	$state = @{ cancel = $false; done = $false }
	$bClose.Add_Click({ if ($state.done) { $f.Close() } else { $state.cancel = $true; $bClose.Text = "Annulation..."; $bClose.Enabled = $false } })
	$f.Add_FormClosing({ $state.cancel = $true })
	$pBot.Controls.Add($bClose)
	$f.Controls.Add($tb); $f.Controls.Add($pBot); $f.Controls.Add($pb)
	$log = { param($t) if ($f.IsDisposed) { return }; $tb.AppendText($t + [Environment]::NewLine); $tb.SelectionStart = $tb.TextLength; $tb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }
	$f.Add_Shown({
		& $log "=== Demarrage de l'installation ==="
		& $log ("Nombre total d'applications : " + $allApps.Count)
		& $log ""
		$done = 0
		foreach ($id in $allApps)
		{
			if ($state.cancel) { break }
			& $log ("> Installation : " + $id)
			$safeId = $id -replace '[^a-zA-Z0-9]', '_'
			$o = "$env:TEMP\winget_out_$safeId.txt"; $e = "$env:TEMP\winget_err_$safeId.txt"
			try
			{
				$wargs = @("install","--id",$id,"--accept-package-agreements","--accept-source-agreements","--silent")
				$proc = Start-Process -FilePath "winget.exe" -ArgumentList $wargs -PassThru -WindowStyle Hidden -RedirectStandardOutput $o -RedirectStandardError $e
				while (-not $proc.HasExited) {
					[System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 200
					if ($state.cancel) { try { $proc.Kill() } catch {}; break }
				}
				if (-not $state.cancel) {
					switch ($proc.ExitCode)
					{
						0 { & $log "  OK - Installe avec succes"; JLog ("Installe (base): " + $id) }
						-1978335189 { & $log "  Deja installe (a jour)"; JLog ("Deja a jour (base): " + $id) }
						default { & $log ("  Erreur code : " + $proc.ExitCode) }
					}
				}
			}
			catch { & $log ("  Exception : " + $_.Exception.Message) }
			finally { Remove-Item $o, $e -ErrorAction SilentlyContinue }
			$done++; if ($done -le $pb.Maximum) { $pb.Value = $done }
			& $log ""
		}
		$state.done = $true
		if ($state.cancel) {
			& $log "=== Interrompu par l'utilisateur ==="
			if (-not $f.IsDisposed) { $f.Close() }
		}
		else {
			& $log "=== Installation terminee ==="
			JLog ("Programmes de base: installation terminee (" + $done + " app)")
			Add-Content -Path "$env:TEMP\logfile.txt" -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Installation batch terminee"
			if (-not $f.IsDisposed) { $bClose.Text = "Fermer"; $bClose.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81) }
		}
	})
	[void]$f.ShowDialog()
}

#3333333333333333333333333333333333333333 Installation Pilotes Windows Vmware Constructeur  3333333333333333333333333333333333333333333333333333333333
function PilotesBis
{
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	
	# Fonction pour créer des cases à cocher
	function New-CheckBox
	{
		param (
			[string]$Text,
			[int]$Top
		)
		$checkBox = New-Object System.Windows.Forms.CheckBox
		$checkBox.Text = $Text
		$checkBox.AutoSize = $true
		$checkBox.Location = New-Object System.Drawing.Point(10, $Top)
		return $checkBox
	}
	
	# Création du formulaire
	$form = New-Object System.Windows.Forms.Form
	$form.Text = 'Mise à jour des pilotes'
	$form.ClientSize = New-Object System.Drawing.Size(400, 250)
	$form.StartPosition = 'CenterScreen'
	$form.FormBorderStyle = 'FixedDialog'
	$form.MaximizeBox = $false
	
	# Création des cases à cocher
	$chkWindowsDriver = New-CheckBox -Text 'Pilotes Windows' -Top 20
	$chkVMware = New-CheckBox -Text 'Pilotes VMware' -Top 50
	$chkHyperV = New-CheckBox -Text 'Pilotes Hyper-V' -Top 80
	$chkConstructor = New-CheckBox -Text 'Pilotes constructeur' -Top 110
	$form.Controls.AddRange(@($chkWindowsDriver, $chkVMware, $chkHyperV, $chkConstructor))
	
	# Bouton de mise à jour
	$btnUpdate = New-Object System.Windows.Forms.Button
	$btnUpdate.Location = New-Object System.Drawing.Point(100, 150)
	$btnUpdate.Size = New-Object System.Drawing.Size(200, 30)
	$btnUpdate.Text = 'Mettre à jour'
	$btnUpdate.Add_Click({
			if ($chkWindowsDriver.Checked)
			{
				$jobWindowsUpdate = Start-Job -ScriptBlock {
					if (-not (Get-Module -ListAvailable -Name PSWindowsUpdate))
					{
						Install-Module PSWindowsUpdate -Force -AllowClobber
					}
					Import-Module PSWindowsUpdate
					Get-WindowsUpdate -MicrosoftUpdate | Where-Object { $_.Title -like "*driver*" } | Install-WindowsUpdate -AcceptAll -IgnoreReboot
				}
			}
			
			if ($chkVMware.Checked)
			{
				$vmwareToolsPath = "${env:ProgramFiles}\VMware\VMware Tools\VMwareToolboxCmd.exe"
				if (Test-Path $vmwareToolsPath)
				{
					Start-Process $vmwareToolsPath -ArgumentList "upgrade"
				}
			}

			if ($chkHyperV.Checked)
			{
				# Vérifier qu'on est bien dans une VM Hyper-V
				$hvService = Get-Service -Name "vmicheartbeat" -ErrorAction SilentlyContinue
				$hvModel   = (Get-CimInstance Win32_ComputerSystem).Model

				if ($hvService -or $hvModel -like "*Virtual Machine*")
				{
					# Méthode 1 — Windows Update (intégration services Hyper-V via WU)
					$jobHyperV = Start-Job -ScriptBlock {
						if (-not (Get-Module -ListAvailable -Name PSWindowsUpdate))
						{
							Install-Module PSWindowsUpdate -Force -AllowClobber -Scope CurrentUser
						}
						Import-Module PSWindowsUpdate
						Get-WindowsUpdate -MicrosoftUpdate |
							Where-Object { $_.Title -like "*Hyper-V*" -or $_.Title -like "*Integration*" } |
							Install-WindowsUpdate -AcceptAll -IgnoreReboot
					}

					# Méthode 2 — vmguest.iso monté par l'hôte (lecteur DVD virtuel)
					$dvd = Get-CimInstance Win32_LogicalDisk |
						   Where-Object { $_.DriveType -eq 5 } | Select-Object -First 1
					if ($dvd)
					{
						$cab = Join-Path $dvd.DeviceID "support\amd64\packages\Microsoft-Hyper-V-Guest-x64.cab"
						if (Test-Path $cab)
						{
							Start-Process "dism.exe" `
								-ArgumentList "/Online /Add-Package /PackagePath:`"$cab`" /NoRestart" `
								-Wait -WindowStyle Hidden
						}
					}

					[System.Windows.Forms.MessageBox]::Show(
						"Mise à jour Hyper-V Integration Services lancée.`nRedémarrage recommandé à la fin.",
						"Hyper-V", "OK", "Information")
				}
				else
				{
					[System.Windows.Forms.MessageBox]::Show(
						"Ce PC n'est pas une machine virtuelle Hyper-V.",
						"Hyper-V", "OK", "Information")
				}
			}

			if ($chkConstructor.Checked)
			{
				$compInfo = Get-CimInstance -Class Win32_ComputerSystem
				$Manufacturer = $compInfo.Manufacturer
				$Model = $compInfo.Model
				$query = [uri]::EscapeDataString("$Manufacturer $Model drivers")
				Start-Process "https://www.google.com/search?q=$query"
			}
		})
	$form.Controls.Add($btnUpdate)
	
	$form.ShowDialog()
	
	# Attendre la fin des jobs de mise à jour (Windows + Hyper-V)
	foreach ($job in @($jobWindowsUpdate, $jobHyperV) | Where-Object { $_ })
	{
		Wait-Job $job | Out-Null
		Receive-Job $job
		Remove-Job $job
	}
}

################################################        Expiration MDP        ######################################################
function ExpirationMdp
{
	if ($PSVersionTable.PSEdition -eq 'Core') {
		$textBox.AppendText("⚠️ ExpirationMdp nécessite Windows PowerShell 5 (Set-LocalUser indisponible en PS7).`r`n")
		return
	}
	# ----------------------------------------------------------------------------
	# Désactivation de l'expiration du mot de passe pour l'utilisateur courant
	# ----------------------------------------------------------------------------
	try
	{

		$currentUser = $env:USERNAME
		Set-LocalUser -Name $currentUser -PasswordNeverExpires $true -ErrorAction Stop
		$textBox.AppendText("Expiration du mot de passe désactivée pour le compte '$currentUser'`r`n")
	}
	catch
	{
		$textBox.AppendText("⚠️ Impossible de désactiver l'expiration du mot de passe local : $($_.Exception.Message)`r`n")
	}
	
	# ----------------------------------------------------------------------------
	# Désactivation globale de l'expiration des mots de passe (net accounts)
	# ----------------------------------------------------------------------------
	try
	{
		# Exécute la commande net accounts
		$proc = Start-Process -FilePath "net" `
							  -ArgumentList "accounts", "/maxpwage:unlimited" `
							  -NoNewWindow -Wait -PassThru -ErrorAction Stop
		
		if ($proc.ExitCode -eq 0)
		{
			$textBox.AppendText("Expiration globale des mots de passe désactivée (net accounts /maxpwage:unlimited)`r`n")
		}
		else
		{
			$textBox.AppendText("Erreur lors de la désactivation globale de l'expiration (code $($proc.ExitCode))`r`n")
		}
	}
	catch
	{
		$textBox.AppendText("⚠️ Échec de la commande net accounts : $($_.Exception.Message)`r`n")
	}
	
	# Fin du script
		
}


########################################## Gestionaire IMP   ##################################"

function gestimp
{
	Add-Type -AssemblyName System.Windows.Forms
	
	# Création de la fenêtre principale
	$form = New-Object System.Windows.Forms.Form
	$form.Text = "Outils Réseau et Système"
	$form.Size = New-Object System.Drawing.Size(950, 700)
	$form.StartPosition = "CenterScreen"
	
	# Fonction utilitaire pour ajouter des boutons dynamiquement en 2 colonnes
	function Add-Button
	{
		param (
			[string]$text,
			[int]$index,
			[string[]]$command,
			[string]$color = ""
		)
		
		$btn = New-Object System.Windows.Forms.Button
		$btn.Text = $text
		$btn.Size = New-Object System.Drawing.Size(430, 30)
		
		$col = [int]($index % 2)
		$row = [int]([math]::Floor($index / 2))
		$x = 20 + ($col * 460)
		$y = 20 + ($row * 40)
		$btn.Location = New-Object System.Drawing.Point($x, $y)
		
		switch ($color)
		{
			"rayé"     { $btn.BackColor = [System.Drawing.Color]::LightGray; $btn.Font = New-Object System.Drawing.Font($btn.Font, [System.Drawing.FontStyle]::Strikeout) }
			"rouge"    { $btn.BackColor = [System.Drawing.Color]::LightCoral }
			"orange"   { $btn.BackColor = [System.Drawing.Color]::PeachPuff }
			"rose"     { $btn.BackColor = [System.Drawing.Color]::LightPink }
			"bleu"     { $btn.BackColor = [System.Drawing.Color]::LightSteelBlue }
		}
		
		$tooltip = New-Object System.Windows.Forms.ToolTip
		$tooltip.SetToolTip($btn, ($command -join ' '))
		
		$btn.Add_Click({
				$cmdArray = $this.Tag
				try
				{
					if ($cmdArray -and $cmdArray.Count -ge 1)
					{
						if ($cmdArray.Count -eq 1)
						{
							Start-Process -FilePath $cmdArray[0]
						}
						else
						{
							Start-Process -FilePath $cmdArray[0] -ArgumentList $cmdArray[1..($cmdArray.Count - 1)]
						}
					}
					else
					{
						throw "Commande vide."
					}
				}
				catch
				{
					[System.Windows.Forms.MessageBox]::Show("Commande invalide ou échec de lancement.`n$_", "Erreur", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
				}
			})
		
		$btn.Tag = $command
		$form.Controls.Add($btn)
	}
	
	# Liste de tous les boutons à afficher
	$buttons = @(
		@{ Text = "Connexions réseau (ncpa.cpl)"; Cmd = @("ncpa.cpl"); Style = "bleu" },
		@{ Text = "Centre Réseau et partage"; Cmd = @("control.exe", "/name", "Microsoft.NetworkAndSharingCenter"); Style = "bleu" },
		@{ Text = "Pare-feu Windows (classique)"; Cmd = @("firewall.cpl"); Style = "bleu" },
		@{ Text = "Pare-feu avec règles avancées"; Cmd = @("wf.msc"); Style = "bleu" },
		@{ Text = "Options Internet"; Cmd = @("inetcpl.cpl"); Style = "bleu" },
		@{ Text = "Dossiers partagés (sessions)"; Cmd = @("fsmgmt.msc"); Style = "bleu" },
		@{ Text = "Ordinateurs du réseau (explorateur)"; Cmd = @("explorer.exe", "shell:::{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}"); Style = "bleu" },
		
		@{ Text = "Gestion de l'ordinateur"; Cmd = @("compmgmt.msc"); Style = "rose" },
		@{ Text = "Gestion des disques"; Cmd = @("diskmgmt.msc"); Style = "orange" },
		@{ Text = "Gestion des services"; Cmd = @("services.msc"); Style = "rose" },
		@{ Text = "Planificateur de tâches"; Cmd = @("taskschd.msc"); Style = "rose" },
		@{ Text = "Gestionnaire de périphériques"; Cmd = @("devmgmt.msc"); Style = "rose" },
		@{ Text = "Éditeur du Registre"; Cmd = @("regedit.exe"); Style = "rose" },
		@{ Text = "Informations système"; Cmd = @("msinfo32.exe"); Style = "rose" },
		@{ Text = "Surveillance des performances"; Cmd = @("perfmon.msc"); Style = "rose" },
		@{ Text = "Configuration système (msconfig)"; Cmd = @("msconfig.exe"); Style = "rose" },
		
		@{ Text = "Assistant de sauvegarde (sdclt)"; Cmd = @("sdclt.exe"); Style = "orange" },
		@{ Text = "Assistant de migration de certificats (credwiz)"; Cmd = @("credwiz.exe"); Style = "orange" },
		@{ Text = "Transfert de fichiers Bluetooth (fsquirt)"; Cmd = @("fsquirt.exe"); Style = "orange" },
		@{ Text = "Programmes et fonctionnalités (appwiz.cpl)"; Cmd = @("appwiz.cpl"); Style = "orange" },
		@{ Text = "Nettoyage de disque (cleanmgr)"; Cmd = @("cleanmgr.exe"); Style = "orange" },
		
		@{ Text = "Vérification du disque (chkdsk)"; Cmd = @("cmd.exe", "/k", "chkdsk"); Style = "orange" },
		@{ Text = "Vérification des fichiers système (sfc /scannow)"; Cmd = @("cmd.exe", "/k", "sfc /scannow"); Style = "orange" },
		@{ Text = "Gestion de la mémoire virtuelle (sysdm.cpl)"; Cmd = @("sysdm.cpl"); Style = "orange" },
		
		@{ Text = "Sécurité Windows (Defender UI)"; Cmd = @("windowsdefender:"); Style = "rose" },
		@{ Text = "Stratégies locales (gpedit.msc)"; Cmd = @("gpedit.msc"); Style = "rose" },
		@{ Text = "Utilisateurs et groupes locaux (lusrmgr.msc)"; Cmd = @("lusrmgr.msc"); Style = "rose" },
		
		@{ Text = "Outil DISM (nettoyage image système)"; Cmd = @("cmd.exe", "/k", "dism /Online /Cleanup-Image /ScanHealth"); Style = "rose" },
		@{ Text = "Outil DISM (restauration image système)"; Cmd = @("cmd.exe", "/k", "dism /Online /Cleanup-Image /RestoreHealth"); Style = "rose" },
		
		@{ Text = "Périphériques et imprimantes (classique)"; Cmd = @("explorer.exe", "shell:::{A8A91A66-3A7D-4424-8D24-04E180695C7A}"); Style = "rouge" }
	)
	
	# Ajout dynamique des boutons en 2 colonnes
	for ($i = 0; $i -lt $buttons.Count; $i++)
	{
		$style = if ($buttons[$i].ContainsKey("Style")) { $buttons[$i]["Style"] }
		else { "" }
		Add-Button -text $buttons[$i].Text -index $i -command $buttons[$i].Cmd -color $style
	}
	$legend = New-Object System.Windows.Forms.Label
	$legend.AutoSize = $true
	$legend.Text = "🌐 Réseau = Bleu   💾 Disques = Orange   ⚙️ Système = Rose   🖨️ Imprimantes = Rouge"
	$legend.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Italic)
	$legend.Location = New-Object System.Drawing.Point(20, 630)
	$form.Controls.Add($legend)
	
	# Afficher la fenêtre
	$form.Topmost = $true
	$form.ShowDialog()
	
}
###################################### Hub Maintenance & Securite ######################################

# --- Helper commun : petite fenetre avec journal ---
function New-MaintWindow
{
    param($title, $w = 720, $h = 560)
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $f = New-Object System.Windows.Forms.Form
    $f.Text = $title; $f.Size = New-Object System.Drawing.Size($w, $h)
    $f.StartPosition = "CenterScreen"; $f.BackColor = [System.Drawing.Color]::FromArgb(243, 244, 246)
    $hdr = New-Object System.Windows.Forms.Panel; $hdr.Dock = "Top"; $hdr.Height = 46; $hdr.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $lb = New-Object System.Windows.Forms.Label; $lb.Text = "  $title"; $lb.Dock = "Fill"; $lb.ForeColor = "White"; $lb.TextAlign = "MiddleLeft"
    $lb.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 12); $hdr.Controls.Add($lb); $f.Controls.Add($hdr)
    $f.Tag = $hdr
    return $f
}

# 1) ============ POINT DE RESTAURATION + SAUVEGARDE REGISTRE ============
function RestorePointTool
{
    $f = New-MaintWindow "Point de restauration + sauvegarde registre" 720 540
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 96; $pBot.BackColor = [System.Drawing.Color]::FromArgb(243, 244, 246)
    $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Fill"; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219)
    $rtb.Font = New-Object System.Drawing.Font("Consolas", 9); $rtb.BorderStyle = "None"; $f.Controls.Add($rtb)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Red" { [System.Drawing.Color]::FromArgb(248,113,113) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()

    $lblD = New-Object System.Windows.Forms.Label; $lblD.Text = "Dossier sauvegarde registre :"; $lblD.Location = New-Object System.Drawing.Point(10, 8); $lblD.AutoSize = $true; $pBot.Controls.Add($lblD)
    $txtD = New-Object System.Windows.Forms.TextBox; $txtD.Location = New-Object System.Drawing.Point(10, 28); $txtD.Width = 520; $txtD.Text = (Join-Path $env:USERPROFILE "Documents"); $pBot.Controls.Add($txtD)
    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Creer point + sauvegarder registre"; $btnGo.Location = New-Object System.Drawing.Point(10, 56); $btnGo.Size = New-Object System.Drawing.Size(300, 32)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(22, 163, 74); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(320, 56); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront()

    $btnGo.Add_Click({
        $btnGo.Enabled = $false
        & $log "Activation de la protection systeme..." "Cyan"
        try { Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue } catch {}
        try { New-ItemProperty -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name "SystemRestorePointCreationFrequency" -Value 0 -PropertyType DWord -Force -ErrorAction SilentlyContinue | Out-Null } catch {}
        & $log "Creation du point de restauration..." "Cyan"
        try { Checkpoint-Computer -Description ("MultInstall - " + (Get-Date -Format "yyyy-MM-dd HH:mm")) -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop; & $log "   Point de restauration cree." "Green" }
        catch { & $log ("   Point de restauration : " + $_.Exception.Message) "Yellow" }
        $dest = $txtD.Text.Trim()
        if ($dest -and (Test-Path $dest)) {
            $rb = Join-Path $dest ("RegBackup_" + (Get-Date -Format "yyyyMMdd_HHmm")); New-Item $rb -ItemType Directory -Force | Out-Null
            & $log "Export des ruches registre..." "Cyan"
            foreach ($h in @("HKLM\SOFTWARE","HKLM\SYSTEM","HKCU","HKCR")) {
                $fn = Join-Path $rb (($h -replace "\\","_") + ".reg")
                $p = Start-Process "reg.exe" -ArgumentList @("export", $h, ("`"" + $fn + "`""), "/y") -WindowStyle Hidden -PassThru
                while (-not $p.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 150 }
                & $log ("   " + $h + " -> OK") "Green"
            }
            & $log ("Sauvegarde registre : " + $rb) "Cyan"
        } else { & $log "Dossier registre invalide, export ignore." "Yellow" }
        & $log "Termine." "Green"
        $btnGo.Enabled = $true
    }.GetNewClosure())

    $f.Add_Shown({ $f.Activate() })
    [void]$f.ShowDialog()
}

# 2) ============ RAPPORT DE SANTE PC (HTML) ============
function HealthReportTool
{
    $f = New-MaintWindow "Rapport de sante PC" 720 520
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 52; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Fill"; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219)
    $rtb.Font = New-Object System.Drawing.Font("Consolas", 9); $rtb.BorderStyle = "None"; $f.Controls.Add($rtb)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()
    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Generer le rapport HTML"; $btnGo.Location = New-Object System.Drawing.Point(10, 10); $btnGo.Size = New-Object System.Drawing.Size(240, 32)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(258, 10); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront()

    $btnGo.Add_Click({
        $btnGo.Enabled = $false
        & $log "Collecte des informations..." "Cyan"
        $rows = New-Object System.Collections.Generic.List[string]
        $add = { param($k, $v) $rows.Add("<tr><td class='k'>$k</td><td>$v</td></tr>") }
        try {
            $os = Get-CimInstance Win32_OperatingSystem
            $cs = Get-CimInstance Win32_ComputerSystem
            $cpu = (Get-CimInstance Win32_Processor | Select-Object -First 1).Name
            & $add "Nom du PC" $env:COMPUTERNAME
            & $add "Utilisateur" $cs.UserName
            & $add "Fabricant / Modele" ("{0} {1}" -f $cs.Manufacturer, $cs.Model)
            & $add "Windows" ("{0} ({1})" -f $os.Caption, $os.Version)
            & $add "Processeur" $cpu
            & $add "RAM totale" ("{0:N1} Go" -f ($cs.TotalPhysicalMemory / 1GB))
        } catch { & $log ("Infos systeme: " + $_.Exception.Message) "Yellow" }
        & $log "Disques..." "Cyan"
        try {
            Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
                & $add ("Disque " + $_.DeviceID) ("{0:N1} Go libres / {1:N1} Go" -f ($_.FreeSpace/1GB), ($_.Size/1GB))
            }
        } catch {}
        try {
            Get-PhysicalDisk -ErrorAction SilentlyContinue | ForEach-Object {
                & $add ("Sante disque: " + $_.FriendlyName) ("{0} (Wear: {1})" -f $_.HealthStatus, $_.MediaType)
            }
        } catch {}
        & $log "Batterie..." "Cyan"
        try {
            $bat = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
            if ($bat) { & $add "Batterie" ("{0}% - {1}" -f $bat.EstimatedChargeRemaining, $bat.Status) } else { & $add "Batterie" "Aucune (poste fixe)" }
        } catch {}
        & $log "Activation Windows..." "Cyan"
        try {
            $lic = Get-CimInstance SoftwareLicensingProduct -Filter "ApplicationID='55c92734-d682-4d71-983e-d6ec3f16059f' AND LicenseStatus=1" -ErrorAction SilentlyContinue | Select-Object -First 1
            $actStr = if ($lic) { "Active" } else { "Non active / inconnue" }
            & $add "Activation Windows" $actStr
        } catch {}
        & $log "Antivirus..." "Cyan"
        try {
            $av = Get-CimInstance -Namespace "root\SecurityCenter2" -ClassName AntiVirusProduct -ErrorAction SilentlyContinue
            if ($av) { & $add "Antivirus" (($av | ForEach-Object { $_.displayName }) -join ", ") } else { & $add "Antivirus" "Non detecte" }
        } catch { & $add "Antivirus" "Non disponible" }
        & $log "Derniere mise a jour..." "Cyan"
        try {
            $hf = Get-HotFix -ErrorAction SilentlyContinue | Sort-Object InstalledOn -Descending | Select-Object -First 1
            if ($hf) { & $add "Derniere MAJ Windows" ("{0} le {1}" -f $hf.HotFixID, $hf.InstalledOn) }
        } catch {}
        $uptime = (Get-Date) - $os.LastBootUpTime
        & $add "Uptime" ("{0} j {1} h" -f $uptime.Days, $uptime.Hours)

        $html = "<html><head><meta charset='utf-8'><style>body{font-family:Segoe UI,Arial;background:#f3f4f6;color:#111;padding:24px} h1{color:#1e293b} table{border-collapse:collapse;width:100%;max-width:780px;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.1)} td{padding:8px 12px;border-bottom:1px solid #eee} .k{font-weight:600;width:240px;color:#334155;background:#f8fafc} .ft{margin-top:16px;color:#64748b;font-size:12px}</style></head><body>"
        $html += "<h1>Rapport de sante PC - $env:COMPUTERNAME</h1><table>" + ($rows -join "") + "</table>"
        $html += "<p class='ft'>Genere le " + (Get-Date -Format "dd/MM/yyyy HH:mm") + " par MultInstall</p></body></html>"
        $out = Join-Path ([Environment]::GetFolderPath("Desktop")) ("RapportSante_" + $env:COMPUTERNAME + "_" + (Get-Date -Format "yyyyMMdd_HHmm") + ".html")
        $html | Out-File $out -Encoding UTF8
        & $log ("Rapport genere : " + $out) "Green"
        Start-Process $out
        $btnGo.Enabled = $true
    }.GetNewClosure())

    $f.Add_Shown({ $f.Activate() })
    [void]$f.ShowDialog()
}

# 3) ============ FINITIONS POST-INSTALLATION ============
function PostInstallTool
{
    $f = New-MaintWindow "Finitions post-installation" 560 560
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 100; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Bottom"; $rtb.Height = 120; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 8); $f.Controls.Add($rtb)
    $panel = New-Object System.Windows.Forms.Panel; $panel.Dock = "Fill"; $panel.AutoScroll = $true; $panel.BackColor = "White"; $panel.Padding = New-Object System.Windows.Forms.Padding(12); $f.Controls.Add($panel)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()

    $opts = @(
        @{ Text="Plan d alimentation : Hautes performances"; Key="power" },
        @{ Text="Desactiver la veille prolongee (hibernation)"; Key="hib" },
        @{ Text="Desactiver le demarrage rapide (fast startup)"; Key="faststart" },
        @{ Text="Afficher les extensions de fichiers"; Key="ext" },
        @{ Text="Afficher les fichiers caches"; Key="hidden" },
        @{ Text="Activer le mode sombre"; Key="dark" },
        @{ Text="Afficher l icone Ce PC sur le bureau"; Key="thispc" }
    )
    $checks = @{}
    $y = 4
    foreach ($o in $opts) {
        $cb = New-Object System.Windows.Forms.CheckBox; $cb.Text = $o.Text; $cb.Location = New-Object System.Drawing.Point(4, $y); $cb.AutoSize = $true; $cb.Checked = $true; $cb.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $panel.Controls.Add($cb); $checks[$o.Key] = $cb; $y += 30
    }

    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Appliquer"; $btnGo.Location = New-Object System.Drawing.Point(12, 8); $btnGo.Size = New-Object System.Drawing.Size(200, 34)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(22, 163, 74); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(220, 8); $btnC.Size = New-Object System.Drawing.Size(90, 34)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront(); $panel.BringToFront()

    $btnGo.Add_Click({
        $btnGo.Enabled = $false
        $adv = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
        if ($checks["power"].Checked)     { try { powercfg -setactive SCHEME_MIN 2>$null; & $log "Plan Hautes performances : OK" "Green" } catch {} }
        if ($checks["hib"].Checked)       { try { powercfg /h off 2>$null; & $log "Hibernation desactivee : OK" "Green" } catch {} }
        if ($checks["faststart"].Checked) { try { Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power" -Name HiberbootEnabled -Value 0 -ErrorAction SilentlyContinue; & $log "Demarrage rapide desactive : OK" "Green" } catch {} }
        if ($checks["ext"].Checked)       { try { Set-ItemProperty $adv -Name HideFileExt -Value 0 -ErrorAction SilentlyContinue; & $log "Extensions affichees : OK" "Green" } catch {} }
        if ($checks["hidden"].Checked)    { try { Set-ItemProperty $adv -Name Hidden -Value 1 -ErrorAction SilentlyContinue; & $log "Fichiers caches affiches : OK" "Green" } catch {} }
        if ($checks["dark"].Checked)      { try { Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" -Name AppsUseLightTheme -Value 0 -ErrorAction SilentlyContinue; Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" -Name SystemUsesLightTheme -Value 0 -ErrorAction SilentlyContinue; & $log "Mode sombre active : OK" "Green" } catch {} }
        if ($checks["thispc"].Checked)    { try { Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}" -Value 0 -ErrorAction SilentlyContinue; & $log "Icone Ce PC affichee : OK" "Green" } catch {} }
        & $log "Redemarrage de l Explorateur..." "Yellow"
        Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 600; Start-Process explorer
        & $log "Finitions appliquees." "Green"
        $btnGo.Enabled = $true
    }.GetNewClosure())

    $f.Add_Shown({ $f.Activate() })
    [void]$f.ShowDialog()
}

# 4) ============ REPARATION WINDOWS ============
function RepairWindowsTool
{
    $f = New-MaintWindow "Reparation Windows" 760 600
    $pTop = New-Object System.Windows.Forms.Panel; $pTop.Dock = "Top"; $pTop.Height = 180; $pTop.BackColor = "White"; $pTop.Padding = New-Object System.Windows.Forms.Padding(12); $f.Controls.Add($pTop)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Fill"; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 8); $rtb.BorderStyle = "None"; $f.Controls.Add($rtb)
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 50; $f.Controls.Add($pBot)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Red" { [System.Drawing.Color]::FromArgb(248,113,113) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()

    $reps = @(
        @{ Text="SFC /scannow (fichiers systeme)"; Key="sfc" },
        @{ Text="DISM RestoreHealth (image Windows)"; Key="dism" },
        @{ Text="Reset Winsock + pile IP"; Key="winsock" },
        @{ Text="Reparer Windows Update (reset)"; Key="wu" },
        @{ Text="Planifier CHKDSK au redemarrage"; Key="chkdsk" }
    )
    $checks = @{}; $y = 4
    foreach ($r in $reps) { $cb = New-Object System.Windows.Forms.CheckBox; $cb.Text = $r.Text; $cb.Location = New-Object System.Drawing.Point(4, $y); $cb.AutoSize = $true; $cb.Checked = $true; $cb.Font = New-Object System.Drawing.Font("Segoe UI", 9); $pTop.Controls.Add($cb); $checks[$r.Key] = $cb; $y += 28 }

    # De-accent (pour analyser les verdicts sans souci d accents)
    $deacc = { param($s) if (-not $s) { return "" } $s = $s.ToLower(); $s = $s -replace '[\u00e0\u00e2\u00e4]','a' -replace '[\u00e9\u00e8\u00ea\u00eb]','e' -replace '[\u00ee\u00ef]','i' -replace '[\u00f4\u00f6]','o' -replace '[\u00f9\u00fb\u00fc]','u' -replace '\u00e7','c'; return $s }.GetNewClosure()
    # Lance une commande : fenetre reactive (DoEvents), lit avec le bon encodage, filtre les barres de progression
    $runStep = {
        param($exe, $argLine, $enc)
        $o = Join-Path $env:TEMP ("rep_" + [guid]::NewGuid().ToString("N") + ".txt")
        $p = Start-Process $exe -ArgumentList $argLine -WindowStyle Hidden -PassThru -RedirectStandardOutput $o
        while (-not $p.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 250 }
        try { $p.WaitForExit() } catch {}
        $code = $p.ExitCode
        $txt = ""
        try {
            $bytes = [System.IO.File]::ReadAllBytes($o)
            $encoding = if ($enc -eq "unicode") { [System.Text.Encoding]::Unicode } elseif ($enc -eq "utf8") { [System.Text.Encoding]::UTF8 } else { [System.Text.Encoding]::GetEncoding(850) }
            $txt = $encoding.GetString($bytes)
        } catch {}
        Remove-Item $o -ErrorAction SilentlyContinue
        $shown = 0
        foreach ($ln in ($txt -split "`r|`n")) {
            $t = $ln.Trim()
            if (-not $t) { continue }
            if (($t -match '\[') -and ($t -match '%')) { continue }
            if ($t -match '^[=\.\s\[\]]+$') { continue }
            if ($t.Length -lt 4) { continue }
            & $log ("   " + $t) "Gray"; $shown++
            if ($shown -ge 30) { & $log "   (...)" "Gray"; break }
        }
        $script:repOut = & $deacc $txt
        return $code
    }.GetNewClosure()

    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Lancer les reparations"; $btnGo.Location = New-Object System.Drawing.Point(12, 9); $btnGo.Size = New-Object System.Drawing.Size(240, 32)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(190, 18, 60); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(260, 9); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $rpbar = New-Object System.Windows.Forms.ProgressBar
    $rpbar.Location = New-Object System.Drawing.Point(360, 11); $rpbar.Size = New-Object System.Drawing.Size(380, 28)
    $rpbar.Style = "Continuous"; $pBot.Controls.Add($rpbar)
    $f.Tag.SendToBack(); $pTop.BringToFront(); $pBot.BringToFront(); $rtb.BringToFront()

    $btnGo.Add_Click({
        $btnGo.Enabled = $false; $rpbar.Style = "Marquee"; $rtb.Clear()
        & $log "========== REPARATIONS ==========" "Yellow"
        if ($checks["sfc"].Checked) {
            & $log "SFC /scannow (3 a 10 min, patientez)..." "Cyan"
            try { Set-Service -Name TrustedInstaller -StartupType Manual -ErrorAction SilentlyContinue; Start-Service -Name TrustedInstaller -ErrorAction SilentlyContinue } catch {}
            & $runStep "sfc.exe" "/scannow" "unicode" | Out-Null
            $o = $script:repOut
            if ($o -match 'did not find any integrity|trouve aucune violation|aucune violation') { & $log "   => SFC : aucun probleme detecte." "Green" }
            elseif ($o -match 'successfully repaired|a repare') { & $log "   => SFC : fichiers corrompus REPARES." "Green" }
            elseif ($o -match 'could not perform|unable to fix|impossible.*reparer') { & $log "   => SFC : corruptions NON reparables (voir CBS.log)." "Yellow" }
            elseif ($o -match 'repair service|service de reparation|reussi a demarrer') { & $log "   => SFC : service de reparation (TrustedInstaller) indisponible. Lancez DISM puis reessayez SFC." "Yellow" }
            else { & $log "   => SFC : termine." "Cyan" }
        }
        if ($checks["dism"].Checked) {
            & $log "DISM RestoreHealth (plusieurs minutes)..." "Cyan"
            $dc = & $runStep "dism.exe" "/Online /Cleanup-Image /RestoreHealth" "oem"
            $o = $script:repOut
            if ($o -match 'no component store corruption|aucune corruption') { & $log "   => DISM : image saine (aucune corruption)." "Green" }
            elseif ($o -match 'completed successfully|operation a reussi|restauration a ete effectuee|restored') { & $log "   => DISM : image reparee avec succes." "Green" }
            elseif ($dc -and $dc -ne 0) { & $log ("   => DISM : code " + $dc + " (verifier connexion/source).") "Yellow" }
            else { & $log "   => DISM : termine." "Cyan" }
        }
        if ($checks["winsock"].Checked) {
            & $log "Reset Winsock + pile IP..." "Cyan"
            & $runStep "netsh.exe" "winsock reset" "utf8" | Out-Null
            & $runStep "netsh.exe" "int ip reset" "utf8" | Out-Null
            & $log "   => Reseau : reinitialise (redemarrage requis)." "Green"
        }
        if ($checks["wu"].Checked) {
            & $log "Reparation Windows Update..." "Cyan"
            foreach ($svc in @("wuauserv","cryptSvc","bits","msiserver")) { Stop-Service $svc -Force -ErrorAction SilentlyContinue }
            $sd = "$env:SystemRoot\SoftwareDistribution"; $cr = "$env:SystemRoot\System32\catroot2"
            try { if (Test-Path $sd) { Rename-Item $sd ($sd + ".old_" + (Get-Date -Format "HHmmss")) -ErrorAction SilentlyContinue } } catch {}
            try { if (Test-Path $cr) { Rename-Item $cr ($cr + ".old_" + (Get-Date -Format "HHmmss")) -ErrorAction SilentlyContinue } } catch {}
            foreach ($svc in @("wuauserv","cryptSvc","bits","msiserver")) { Start-Service $svc -ErrorAction SilentlyContinue }
            & $log "   => Windows Update : reinitialise." "Green"
        }
        if ($checks["chkdsk"].Checked) {
            & $log "Planification CHKDSK au redemarrage..." "Cyan"
            $null = cmd.exe /c "echo O| chkdsk $env:SystemDrive /F /R" 2>&1
            & $log "   => CHKDSK planifie au prochain redemarrage." "Green"
        }
        $rpbar.Style = "Continuous"
        & $log "========== TERMINE ========== (un redemarrage est conseille)" "Green"
        $btnGo.Enabled = $true
    }.GetNewClosure())

    $f.Add_Shown({ $f.Activate() })
    [void]$f.ShowDialog()
}

# 5) ============ DIAGNOSTIC MATERIEL ============
function HardwareDiagTool
{
    $f = New-MaintWindow "Diagnostic materiel" 780 580
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 50; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Fill"; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 9); $rtb.BorderStyle = "None"; $f.Controls.Add($rtb)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Red" { [System.Drawing.Color]::FromArgb(248,113,113) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()
    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Lancer le diagnostic"; $btnGo.Location = New-Object System.Drawing.Point(12, 9); $btnGo.Size = New-Object System.Drawing.Size(220, 32)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(240, 9); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront()
    $btnGo.Add_Click({
        $btnGo.Enabled = $false
        & $log "===== DIAGNOSTIC MATERIEL =====" "Yellow"
        & $log "Batterie..." "Cyan"
        try {
            $full = (Get-CimInstance -Namespace root\wmi -Class BatteryFullChargedCapacity -ErrorAction SilentlyContinue).FullChargedCapacity
            $design = (Get-CimInstance -Namespace root\wmi -Class BatteryStaticData -ErrorAction SilentlyContinue).DesignedCapacity
            if ($design -and $full -and $design -gt 0) {
                $wear = [math]::Round((1 - ($full / $design)) * 100, 1)
                $col = "Green"; if ($wear -ge 40) { $col = "Red" } elseif ($wear -ge 20) { $col = "Yellow" }
                & $log ("   Usure batterie : " + $wear + "% (concue " + $design + " / actuelle " + $full + " mWh)") $col
            } else { & $log "   Pas de batterie (poste fixe) ou info indisponible." "Gray" }
        } catch { & $log "   Batterie : info indisponible." "Gray" }
        & $log "Disques (SMART)..." "Cyan"
        try {
            Get-PhysicalDisk -ErrorAction SilentlyContinue | ForEach-Object {
                $d = $_; $rc = $d | Get-StorageReliabilityCounter -ErrorAction SilentlyContinue
                $col = "Green"; if ($d.HealthStatus -ne "Healthy") { $col = "Red" }
                $temp = if ($rc -and $rc.Temperature) { [string]$rc.Temperature + "C" } else { "?" }
                $wearD = if ($rc -and $rc.Wear -ne $null) { [string]$rc.Wear + "%" } else { "?" }
                & $log ("   " + $d.FriendlyName + " : sante " + $d.HealthStatus + ", temp " + $temp + ", usure " + $wearD) $col
            }
        } catch { & $log "   SMART indisponible." "Gray" }
        & $log "Memoire (RAM)..." "Cyan"
        try {
            Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue | ForEach-Object {
                & $log ("   Barrette : " + [math]::Round($_.Capacity / 1GB) + " Go @ " + $_.Speed + " MHz - " + $_.Manufacturer) "White"
            }
            & $log "   (Pour un test approfondi : planifier 'mdsched.exe' au redemarrage)" "Gray"
        } catch {}
        & $log "Peripheriques en erreur..." "Cyan"
        try {
            $bad = Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object { $_.ConfigManagerErrorCode -and $_.ConfigManagerErrorCode -ne 0 }
            if ($bad) { foreach ($d in $bad) { & $log ("   ERREUR : " + $d.Name + " (code " + $d.ConfigManagerErrorCode + ")") "Yellow" } }
            else { & $log "   Aucun peripherique en erreur." "Green" }
        } catch {}
        & $log "===== DIAGNOSTIC TERMINE =====" "Green"
        $btnGo.Enabled = $true
    }.GetNewClosure())
    $f.Add_Shown({ $f.Activate() })
    [void]$f.ShowDialog()
}

# 6) ============ NETTOYAGE DISQUE AVANCE ============
function DiskCleanupTool
{
    $f = New-MaintWindow "Nettoyage disque avance" 640 600
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 96; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Bottom"; $rtb.Height = 120; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 8); $f.Controls.Add($rtb)
    $panel = New-Object System.Windows.Forms.Panel; $panel.Dock = "Fill"; $panel.BackColor = "White"; $panel.AutoScroll = $true; $panel.Padding = New-Object System.Windows.Forms.Padding(12); $f.Controls.Add($panel)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()

    $items = @(
        @{ Key="utemp"; Text="Fichiers temporaires utilisateur"; Path=$env:TEMP },
        @{ Key="wtemp"; Text="Fichiers temporaires Windows"; Path="$env:SystemRoot\Temp" },
        @{ Key="wu";    Text="Cache Windows Update (Download)"; Path="$env:SystemRoot\SoftwareDistribution\Download" },
        @{ Key="thumb"; Text="Cache des miniatures"; Path="$env:LOCALAPPDATA\Microsoft\Windows\Explorer" },
        @{ Key="old";   Text="Windows.old (ancienne installation)"; Path="$env:SystemDrive\Windows.old" },
        @{ Key="crd";   Text="Cache Chrome"; Path="$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache" },
        @{ Key="edg";   Text="Cache Edge"; Path="$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cache" }
    )
    $cbs = @{}; $y = 4
    foreach ($it in $items) {
        $cb = New-Object System.Windows.Forms.CheckBox; $cb.Text = $it.Text; $cb.Tag = $it; $cb.Location = New-Object System.Drawing.Point(4, $y); $cb.AutoSize = $true; $cb.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $panel.Controls.Add($cb); $cbs[$it.Key] = $cb; $y += 30
    }
    $cbRecycle = New-Object System.Windows.Forms.CheckBox; $cbRecycle.Text = "Vider la corbeille"; $cbRecycle.Location = New-Object System.Drawing.Point(4, $y); $cbRecycle.AutoSize = $true; $cbRecycle.Font = New-Object System.Drawing.Font("Segoe UI", 9); $panel.Controls.Add($cbRecycle); $y += 30

    $dirSize = { param($p) if (-not (Test-Path $p)) { return 0 } try { return ((Get-ChildItem $p -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum) } catch { return 0 } }.GetNewClosure()

    $btnScan = New-Object System.Windows.Forms.Button; $btnScan.Text = "Calculer les tailles"; $btnScan.Location = New-Object System.Drawing.Point(12, 8); $btnScan.Size = New-Object System.Drawing.Size(180, 32)
    $btnScan.FlatStyle = "Flat"; $btnScan.FlatAppearance.BorderSize = 0; $btnScan.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235); $btnScan.ForeColor = "White"; $pBot.Controls.Add($btnScan)
    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Nettoyer la selection"; $btnGo.Location = New-Object System.Drawing.Point(200, 8); $btnGo.Size = New-Object System.Drawing.Size(200, 32)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(22, 163, 74); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(408, 8); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront(); $panel.BringToFront()

    $btnScan.Add_Click({
        $total = 0
        foreach ($it in $items) {
            $sz = & $dirSize $it.Path
            $total += $sz
            $cbs[$it.Key].Text = $it.Text + "  (" + [math]::Round($sz / 1MB, 1) + " Mo)"
        }
        & $log ("Espace recuperable estime : " + [math]::Round($total / 1MB, 1) + " Mo") "Cyan"
    }.GetNewClosure())

    $btnGo.Add_Click({
        $btnGo.Enabled = $false
        & $log "Nettoyage..." "Yellow"
        foreach ($it in $items) {
            if ($cbs[$it.Key].Checked -and (Test-Path $it.Path)) {
                try {
                    Get-ChildItem $it.Path -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
                    & $log ("   " + $it.Text + " : nettoye") "Green"
                } catch { & $log ("   " + $it.Text + " : partiel (fichiers en cours d usage)") "Yellow" }
            }
            [System.Windows.Forms.Application]::DoEvents()
        }
        if ($cbRecycle.Checked) { try { Clear-RecycleBin -Force -ErrorAction SilentlyContinue; & $log "   Corbeille videe" "Green" } catch {} }
        & $log "Nettoyage termine." "Green"
        $btnGo.Enabled = $true
    }.GetNewClosure())
    $f.Add_Shown({ $f.Activate() })
    [void]$f.ShowDialog()
}

# 7) ============ FICHE D'INTERVENTION (HTML) ============
function InterventionSheetTool
{
    $f = New-MaintWindow "Fiche d intervention client" 620 640
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 52; $f.Controls.Add($pBot)
    $panel = New-Object System.Windows.Forms.Panel; $panel.Dock = "Fill"; $panel.BackColor = "White"; $panel.AutoScroll = $true; $panel.Padding = New-Object System.Windows.Forms.Padding(14); $f.Controls.Add($panel)

    $lblCli = New-Object System.Windows.Forms.Label; $lblCli.Text = "Client :"; $lblCli.Location = New-Object System.Drawing.Point(6, 8); $lblCli.AutoSize = $true; $panel.Controls.Add($lblCli)
    $txtCli = New-Object System.Windows.Forms.TextBox; $txtCli.Location = New-Object System.Drawing.Point(110, 6); $txtCli.Width = 380; $panel.Controls.Add($txtCli)
    $lblTec = New-Object System.Windows.Forms.Label; $lblTec.Text = "Technicien :"; $lblTec.Location = New-Object System.Drawing.Point(6, 38); $lblTec.AutoSize = $true; $panel.Controls.Add($lblTec)
    $txtTec = New-Object System.Windows.Forms.TextBox; $txtTec.Location = New-Object System.Drawing.Point(110, 36); $txtTec.Width = 380; $panel.Controls.Add($txtTec)

    $lblAct = New-Object System.Windows.Forms.Label; $lblAct.Text = "Actions realisees :"; $lblAct.Location = New-Object System.Drawing.Point(6, 70); $lblAct.AutoSize = $true; $lblAct.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9); $panel.Controls.Add($lblAct)
    $actions = @("Installation programmes de base","Mise a jour pilotes","Mise a jour Windows","Nettoyage bloatware","Nettoyage disque","Analyse antivirus","Reparation Windows (SFC/DISM)","Point de restauration cree","Migration des donnees","Optimisation / finitions")
    $cbs = @(); $y = 94
    foreach ($a in $actions) { $cb = New-Object System.Windows.Forms.CheckBox; $cb.Text = $a; $cb.Location = New-Object System.Drawing.Point(10, $y); $cb.AutoSize = $true; $cb.Font = New-Object System.Drawing.Font("Segoe UI", 9); $panel.Controls.Add($cb); $cbs += $cb; $y += 26 }
    $lblRem = New-Object System.Windows.Forms.Label; $lblRem.Text = "Remarques :"; $lblRem.Location = New-Object System.Drawing.Point(6, ($y + 4)); $lblRem.AutoSize = $true; $panel.Controls.Add($lblRem)
    $txtRem = New-Object System.Windows.Forms.TextBox; $txtRem.Multiline = $true; $txtRem.ScrollBars = "Vertical"; $txtRem.Location = New-Object System.Drawing.Point(10, ($y + 26)); $txtRem.Size = New-Object System.Drawing.Size(560, 90); $panel.Controls.Add($txtRem)

    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Generer la fiche (HTML)"; $btnGo.Location = New-Object System.Drawing.Point(12, 10); $btnGo.Size = New-Object System.Drawing.Size(260, 32)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(79, 70, 229); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(280, 10); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $panel.BringToFront()

    $btnGo.Add_Click({
        try {
            $cs = Get-CimInstance Win32_ComputerSystem
            $os = Get-CimInstance Win32_OperatingSystem
            $cpu = (Get-CimInstance Win32_Processor | Select-Object -First 1).Name
            $ram = "{0:N1} Go" -f ($cs.TotalPhysicalMemory / 1GB)
        } catch {}
        $doneRows = ""
        foreach ($cb in $cbs) { if ($cb.Checked) { $doneRows += "<li>" + $cb.Text + "</li>" } }
        if (-not $doneRows) { $doneRows = "<li>(aucune cochee)</li>" }
        $rem = ($txtRem.Text -replace "<","&lt;" -replace ">","&gt;" -replace "`r`n","<br>")
        $h = "<html><head><meta charset='utf-8'><style>body{font-family:Segoe UI,Arial;color:#111;padding:28px;max-width:800px} h1{color:#1e293b} .box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:14px 18px;margin:10px 0} .k{color:#475569;font-weight:600} .sig{margin-top:40px;display:flex;justify-content:space-between} .ft{margin-top:18px;color:#64748b;font-size:12px}</style></head><body>"
        $h += "<h1>Fiche d intervention</h1>"
        $h += "<div class='box'><span class='k'>Client :</span> " + $txtCli.Text + "<br><span class='k'>Technicien :</span> " + $txtTec.Text + "<br><span class='k'>Date :</span> " + (Get-Date -Format "dd/MM/yyyy HH:mm") + "</div>"
        $h += "<div class='box'><span class='k'>Poste :</span> " + $env:COMPUTERNAME + "<br><span class='k'>Machine :</span> " + $cs.Manufacturer + " " + $cs.Model + "<br><span class='k'>Systeme :</span> " + $os.Caption + "<br><span class='k'>Processeur :</span> " + $cpu + "<br><span class='k'>RAM :</span> " + $ram + "</div>"
        $h += "<h3>Actions realisees</h3><ul>" + $doneRows + "</ul>"
        $h += "<h3>Remarques</h3><div class='box'>" + $rem + "</div>"
        $h += "<div class='sig'><div>Signature technicien :<br><br>____________________</div><div>Signature client :<br><br>____________________</div></div>"
        $h += "<p class='ft'>Genere par MultInstall</p></body></html>"
        $name = "Fiche_" + ($txtCli.Text -replace '[^a-zA-Z0-9]','_') + "_" + (Get-Date -Format "yyyyMMdd_HHmm") + ".html"
        $out = Join-Path ([Environment]::GetFolderPath("Desktop")) $name
        $h | Out-File $out -Encoding UTF8
        Start-Process $out
        [System.Windows.Forms.MessageBox]::Show("Fiche generee :`n" + $out + "`n`n(Imprimer / Enregistrer en PDF depuis le navigateur)", "OK")
    }.GetNewClosure())
    $f.Add_Shown({ $f.Activate() })
    [void]$f.ShowDialog()
}

# 8) ============ SECURISATION EXPRESS ============
function SecurityTool
{
    $f = New-MaintWindow "Securisation express" 600 580
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 50; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Bottom"; $rtb.Height = 130; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 8); $f.Controls.Add($rtb)
    $panel = New-Object System.Windows.Forms.Panel; $panel.Dock = "Fill"; $panel.BackColor = "White"; $panel.AutoScroll = $true; $panel.Padding = New-Object System.Windows.Forms.Padding(12); $f.Controls.Add($panel)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Red" { [System.Drawing.Color]::FromArgb(248,113,113) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()

    $opts = @(
        @{ Text="Activer le pare-feu (tous profils)"; Key="fw" },
        @{ Text="Activer Defender (protection temps reel)"; Key="def" },
        @{ Text="Analyse rapide Defender"; Key="scan" },
        @{ Text="Desactiver SMBv1 (vulnerable)"; Key="smb" },
        @{ Text="Desactiver l autorun USB"; Key="autorun" },
        @{ Text="Verifier BitLocker (+ sauver la cle au bureau) + etat MAJ"; Key="check" }
    )
    $cbs = @{}; $y = 4
    foreach ($o in $opts) { $cb = New-Object System.Windows.Forms.CheckBox; $cb.Text = $o.Text; $cb.Checked = $true; $cb.Location = New-Object System.Drawing.Point(4, $y); $cb.AutoSize = $true; $cb.Font = New-Object System.Drawing.Font("Segoe UI", 9); $panel.Controls.Add($cb); $cbs[$o.Key] = $cb; $y += 30 }

    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Appliquer"; $btnGo.Location = New-Object System.Drawing.Point(12, 9); $btnGo.Size = New-Object System.Drawing.Size(200, 32)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(190, 18, 60); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(220, 9); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront(); $panel.BringToFront()

    $btnGo.Add_Click({
        $btnGo.Enabled = $false
        & $log "===== SECURISATION =====" "Yellow"
        if ($cbs["fw"].Checked) { try { Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True -ErrorAction Stop; & $log "   Pare-feu : active" "Green" } catch { & $log ("   Pare-feu : " + $_.Exception.Message) "Yellow" } }
        if ($cbs["def"].Checked) { try { Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction Stop; & $log "   Defender temps reel : active" "Green" } catch { & $log ("   Defender : " + $_.Exception.Message) "Yellow" } }
        if ($cbs["scan"].Checked) { try { & $log "   Analyse rapide Defender en cours..." "Cyan"; Start-MpScan -ScanType QuickScan -ErrorAction Stop; & $log "   Analyse rapide : terminee" "Green" } catch { & $log ("   Analyse : " + $_.Exception.Message) "Yellow" } }
        if ($cbs["smb"].Checked) { try { Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force -ErrorAction Stop; & $log "   SMBv1 : desactive" "Green" } catch { & $log ("   SMBv1 : " + $_.Exception.Message) "Yellow" } }
        if ($cbs["autorun"].Checked) { try { if (-not (Test-Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer")) { New-Item "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Force | Out-Null }; Set-ItemProperty "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name NoDriveTypeAutoRun -Value 255 -Type DWord; & $log "   Autorun USB : desactive" "Green" } catch { & $log ("   Autorun : " + $_.Exception.Message) "Yellow" } }
        if ($cbs["check"].Checked) {
            try {
                $vols = Get-BitLockerVolume -ErrorAction SilentlyContinue
                $keyLines = @()
                foreach ($bl in $vols) {
                    & $log ("   BitLocker " + $bl.MountPoint + " : " + $bl.VolumeStatus + " / protection " + $bl.ProtectionStatus) "Cyan"
                    $rp = $bl.KeyProtector | Where-Object { $_.KeyProtectorType -eq 'RecoveryPassword' -and $_.RecoveryPassword }
                    foreach ($k in $rp) {
                        $keyLines += "Lecteur " + $bl.MountPoint + "  (" + $bl.VolumeStatus + ")"
                        $keyLines += "ID protecteur     : " + $k.KeyProtectorId
                        $keyLines += "Cle de recuperation : " + $k.RecoveryPassword
                        $keyLines += ""
                    }
                }
                if ($keyLines.Count -gt 0) {
                    $kf = Join-Path ([Environment]::GetFolderPath("Desktop")) ("CleBitLocker_" + $env:COMPUTERNAME + "_" + (Get-Date -Format "yyyyMMdd_HHmm") + ".txt")
                    $entete = @("===== Cles de recuperation BitLocker =====", ("Poste : " + $env:COMPUTERNAME), ("Date  : " + (Get-Date -Format "dd/MM/yyyy HH:mm")), "", "IMPORTANT : conserver en lieu sur (cloud/USB) et NE PAS laisser ce fichier sur le PC.", "")
                    ($entete + $keyLines) | Out-File $kf -Encoding UTF8
                    & $log ("   => Cle(s) BitLocker sauvegardee(s) : " + $kf) "Green"
                    & $log "   (Pensez a deplacer ce fichier hors du PC !)" "Yellow"
                } else {
                    & $log "   Aucun disque chiffre (ou pas de cle de recuperation)." "Gray"
                }
                if ($keyLines.Count -gt 0) {
                    $aad = $false; $dom = $false
                    try { $ds = (dsregcmd /status 2>$null) -join "`n"; if ($ds -match "AzureAdJoined\s*:\s*YES") { $aad = $true }; if ($ds -match "DomainJoined\s*:\s*YES") { $dom = $true } } catch {}
                    $msaNoted = $false
                    foreach ($bl in $vols) {
                        $rp2 = $bl.KeyProtector | Where-Object { $_.KeyProtectorType -eq 'RecoveryPassword' -and $_.RecoveryPassword }
                        foreach ($k in $rp2) {
                            if ($aad) {
                                try { BackupToAAD-BitLockerKeyProtector -MountPoint $bl.MountPoint -KeyProtectorId $k.KeyProtectorId -ErrorAction Stop; & $log ("   Cle " + $bl.MountPoint + " televersee dans le compte Microsoft/Entra (cloud).") "Green" }
                                catch { & $log ("   Cloud Entra " + $bl.MountPoint + " : " + $_.Exception.Message) "Yellow" }
                            } elseif ($dom) {
                                try { Backup-BitLockerKeyProtector -MountPoint $bl.MountPoint -KeyProtectorId $k.KeyProtectorId -ErrorAction Stop; & $log ("   Cle " + $bl.MountPoint + " sauvegardee dans Active Directory.") "Green" }
                                catch { & $log ("   AD " + $bl.MountPoint + " : " + $_.Exception.Message) "Yellow" }
                            } elseif (-not $msaNoted) {
                                & $log "   Compte local / Microsoft perso : televersement cloud non scriptable." "Cyan"
                                & $log "   -> Sauvegarder sur https://account.microsoft.com/devices/recoverykey" "Cyan"
                                $msaNoted = $true
                            }
                        }
                    }
                }
            } catch { & $log ("   BitLocker : " + $_.Exception.Message) "Yellow" }
            try { $hf = Get-HotFix -ErrorAction SilentlyContinue | Sort-Object InstalledOn -Descending | Select-Object -First 1; if ($hf) { & $log ("   Derniere MAJ : " + $hf.HotFixID + " (" + $hf.InstalledOn + ")") "Cyan" } } catch {}
        }
        & $log "===== TERMINE =====" "Green"
        $btnGo.Enabled = $true
    }.GetNewClosure())
    $f.Add_Shown({ $f.Activate() })
    [void]$f.ShowDialog()
}

# 9) ============ DESINSTALLEUR UNIVERSEL ============
function UninstallerTool
{
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    function global:JLog($m){ try { $jd=Join-Path $env:ProgramData "MultInstall"; if(-not(Test-Path $jd)){New-Item $jd -ItemType Directory -Force -ErrorAction SilentlyContinue|Out-Null}; Add-Content -Path (Join-Path $jd "journal.txt") -Value ("["+(Get-Date -Format "dd/MM HH:mm")+"] "+$m) -Encoding UTF8 -ErrorAction SilentlyContinue } catch {} }
    $f = New-MaintWindow "Desinstalleur universel" 720 640
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 50; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Bottom"; $rtb.Height = 90; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 8); $f.Controls.Add($rtb)
    $pTop = New-Object System.Windows.Forms.Panel; $pTop.Dock = "Top"; $pTop.Height = 34; $pTop.BackColor = "White"; $f.Controls.Add($pTop)
    $lblF = New-Object System.Windows.Forms.Label; $lblF.Text = "Filtre :"; $lblF.Location = New-Object System.Drawing.Point(8, 8); $lblF.AutoSize = $true; $pTop.Controls.Add($lblF)
    $txtF = New-Object System.Windows.Forms.TextBox; $txtF.Location = New-Object System.Drawing.Point(60, 5); $txtF.Width = 300; $pTop.Controls.Add($txtF)
    $clb = New-Object System.Windows.Forms.CheckedListBox; $clb.Dock = "Fill"; $clb.CheckOnClick = $true; $clb.Font = New-Object System.Drawing.Font("Segoe UI", 9); $f.Controls.Add($clb)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()

    $state = @{ apps = @() }
    $loadApps = {
        $state.apps = @()
        $keys = @("HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*","HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*","HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*")
        $seen = @{}
        foreach ($k in $keys) {
            Get-ItemProperty $k -ErrorAction SilentlyContinue | ForEach-Object {
                if ($_.DisplayName -and $_.UninstallString -and -not $_.SystemComponent -and -not $seen[$_.DisplayName]) {
                    $seen[$_.DisplayName] = $true
                    $state.apps += [PSCustomObject]@{ Name=$_.DisplayName; Type="classic"; Pkg=$null; Quiet=$_.QuietUninstallString; Uninst=$_.UninstallString; Loc=$_.InstallLocation; Pub=$_.Publisher }
                }
            }
        }
        Get-AppxPackage -PackageTypeFilter Main -ErrorAction SilentlyContinue | Where-Object { -not $_.IsFramework -and $_.SignatureKind -ne "System" -and $_.NonRemovable -ne $true } | ForEach-Object {
            if (-not $seen[$_.Name]) { $seen[$_.Name] = $true; $state.apps += [PSCustomObject]@{ Name=$_.Name; Type="appx"; Pkg=$_.PackageFullName; Quiet=$null; Uninst=$null; Loc=$null; Pub=$_.Publisher } }
        }
        $state.apps = $state.apps | Sort-Object Name
    }.GetNewClosure()

    # Recherche des residus (dossiers + cles registre) - facon Geek Uninstaller
    $scanLeftovers = {
        param($app)
        $res = @()
        $clean = ($app.Name -replace '\d+(\.\d+)*','').Trim()
        $tok = ($clean -split '[\s\-_,()]+' | Where-Object { $_.Length -ge 4 } | Select-Object -First 1)
        if ($app.Loc) {
            $lp = ($app.Loc.Trim('"')).TrimEnd('\')
            if ($lp -and (Test-Path $lp) -and ($lp -match 'Program Files|ProgramData|AppData')) { $res += [PSCustomObject]@{ Type='dossier'; Path=$lp } }
        }
        if ($tok) {
            foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramData, $env:APPDATA, $env:LOCALAPPDATA)) {
                if (-not $base -or -not (Test-Path $base)) { continue }
                Get-ChildItem -Path $base -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like ('*' + $tok + '*') } | ForEach-Object { $res += [PSCustomObject]@{ Type='dossier'; Path=$_.FullName } }
            }
            foreach ($rk in @('HKCU:\Software','HKLM:\Software','HKLM:\Software\WOW6432Node')) {
                Get-ChildItem -Path $rk -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -like ('*' + $tok + '*') } | ForEach-Object { $res += [PSCustomObject]@{ Type='registre'; Path=$_.PSPath } }
            }
        }
        return ($res | Sort-Object Path -Unique)
    }.GetNewClosure()

    $refresh = {
        $clb.Items.Clear()
        $flt = $txtF.Text.Trim()
        foreach ($a in $state.apps) { if (-not $flt -or $a.Name -like ("*" + $flt + "*")) { $clb.Items.Add($a.Name) | Out-Null } }
        & $log ($clb.Items.Count.ToString() + " logiciel(s) affiche(s).") "Cyan"
    }.GetNewClosure()
    $txtF.Add_TextChanged({ & $refresh }.GetNewClosure())

    $btnDel = New-Object System.Windows.Forms.Button; $btnDel.Text = "Desinstaller la selection"; $btnDel.Location = New-Object System.Drawing.Point(12, 9); $btnDel.Size = New-Object System.Drawing.Size(240, 32)
    $btnDel.FlatStyle = "Flat"; $btnDel.FlatAppearance.BorderSize = 0; $btnDel.BackColor = [System.Drawing.Color]::FromArgb(190, 18, 60); $btnDel.ForeColor = "White"; $pBot.Controls.Add($btnDel)
    $btnR = New-Object System.Windows.Forms.Button; $btnR.Text = "Actualiser"; $btnR.Location = New-Object System.Drawing.Point(260, 9); $btnR.Size = New-Object System.Drawing.Size(110, 32)
    $btnR.FlatStyle = "Flat"; $btnR.FlatAppearance.BorderSize = 0; $btnR.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235); $btnR.ForeColor = "White"; $pBot.Controls.Add($btnR)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(378, 9); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $btnR.Add_Click({ & $loadApps; & $refresh }.GetNewClosure())
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront(); $pTop.BringToFront(); $clb.BringToFront()

    $btnDel.Add_Click({
        $sel = @($clb.CheckedItems)
        if ($sel.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show("Aucun logiciel coche."); return }
        $r = [System.Windows.Forms.MessageBox]::Show(("Desinstaller " + $sel.Count + " logiciel(s) ?"), "Confirmation", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($r -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        $btnDel.Enabled = $false
        $done = @()
        foreach ($name in $sel) {
            $app = $state.apps | Where-Object { $_.Name -eq $name } | Select-Object -First 1
            if (-not $app) { continue }
            & $log ("Desinstallation : " + $name) "Cyan"
            if ($app.Type -eq "appx") {
                try { Get-AppxPackage -Name $app.Name -AllUsers -ErrorAction SilentlyContinue | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue; & $log ("   OK (Store) : " + $name) "Green"; JLog ("Desinstalle (Store): " + $name); $done += $app } catch { & $log ("   Echec : " + $name + " - " + $_.Exception.Message) "Yellow" }
                continue
            }
            $cmd = if ($app.Quiet) { $app.Quiet } else { $app.Uninst }
            if ($cmd -match "msiexec") { $cmd = $cmd -replace "/I", "/X"; if ($cmd -notmatch "/quiet") { $cmd = $cmd + " /quiet /norestart" } }
            try {
                $hidden = if ($app.Quiet -or $cmd -match "/quiet") { "Hidden" } else { "Normal" }
                $p = Start-Process "cmd.exe" -ArgumentList "/c $cmd" -WindowStyle $hidden -PassThru
                while (-not $p.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 200 }
                & $log ("   OK : " + $name) "Green"; JLog ("Desinstalle: " + $name); $done += $app
            } catch { & $log ("   Echec : " + $name + " - " + $_.Exception.Message) "Yellow" }
        }
        & $log "Desinstallation terminee." "Green"
        & $log "Recherche des residus (dossiers + registre)..." "Cyan"
        $left = @()
        foreach ($app in $done) { if ($app.Type -ne "appx") { $left += (& $scanLeftovers $app) } }
        $left = @($left | Sort-Object Path -Unique)
        if ($left.Count -gt 0) {
            foreach ($it in $left) { & $log ("   [" + $it.Type + "] " + $it.Path) "Yellow" }
            $rr = [System.Windows.Forms.MessageBox]::Show(($left.Count.ToString() + " residu(s) detecte(s).`nSupprimer ces dossiers et cles de registre ?"), "Residus detectes", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
            if ($rr -eq [System.Windows.Forms.DialogResult]::Yes) {
                foreach ($it in $left) {
                    try { Remove-Item -LiteralPath $it.Path -Recurse -Force -ErrorAction Stop; & $log ("   supprime : " + $it.Path) "Green" }
                    catch { & $log ("   non supprime : " + $it.Path) "Gray" }
                }
            }
        } else { & $log "   Aucun residu detecte." "Green" }
        & $loadApps; & $refresh
        $btnDel.Enabled = $true
    }.GetNewClosure())

    $f.Add_Shown({ $f.Activate(); & $loadApps; & $refresh }.GetNewClosure())
    [void]$f.ShowDialog()
}

# 10) ============ TEST QUALITE CONNEXION ============
function NetQualityTool
{
    $f = New-MaintWindow "Test qualite connexion Internet" 720 540
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 50; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Fill"; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 9); $rtb.BorderStyle = "None"; $f.Controls.Add($rtb)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Red" { [System.Drawing.Color]::FromArgb(248,113,113) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()
    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Lancer le test"; $btnGo.Location = New-Object System.Drawing.Point(12, 9); $btnGo.Size = New-Object System.Drawing.Size(200, 32)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(220, 9); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront()

    $btnGo.Add_Click({
        $btnGo.Enabled = $false
        & $log "===== TEST QUALITE CONNEXION =====" "Yellow"
        try { $pub = (Invoke-RestMethod -Uri "https://api.ipify.org" -TimeoutSec 8); & $log ("IP publique : " + $pub) "Cyan" } catch { & $log "IP publique : indisponible" "Yellow" }
        & $log "Ping (1.1.1.1, 10 essais)..." "Cyan"
        try {
            $pings = Test-Connection -ComputerName "1.1.1.1" -Count 10 -ErrorAction SilentlyContinue
            if ($pings) {
                $rtts = $pings | ForEach-Object { $_.ResponseTime }
                $avg = [math]::Round(($rtts | Measure-Object -Average).Average, 1)
                $min = ($rtts | Measure-Object -Minimum).Minimum
                $max = ($rtts | Measure-Object -Maximum).Maximum
                $loss = [math]::Round((1 - ($pings.Count / 10)) * 100, 0)
                $jit = [math]::Round((($rtts | Measure-Object -Maximum).Maximum - ($rtts | Measure-Object -Minimum).Minimum) / 2, 1)
                $col = "Green"; if ($avg -gt 80 -or $loss -gt 2) { $col = "Yellow" }; if ($avg -gt 150 -or $loss -gt 10) { $col = "Red" }
                & $log ("   Latence : " + $avg + " ms (min " + $min + " / max " + $max + ")") $col
                & $log ("   Jitter : ~" + $jit + " ms   |   Perte : " + $loss + "%") $col
            } else { & $log "   Ping : aucune reponse" "Red" }
        } catch { & $log ("   Ping : " + $_.Exception.Message) "Yellow" }
        & $log "Resolution DNS..." "Cyan"
        try {
            $sw = [System.Diagnostics.Stopwatch]::StartNew()
            Resolve-DnsName "www.google.com" -ErrorAction SilentlyContinue | Out-Null
            $sw.Stop()
            & $log ("   DNS : " + $sw.ElapsedMilliseconds + " ms") "Cyan"
        } catch {}
        & $log "Debit descendant (~25 Mo)..." "Cyan"
        try {
            $url = "https://speed.cloudflare.com/__down?bytes=25000000"
            $tmp = Join-Path $env:TEMP "spd.bin"
            $sw = [System.Diagnostics.Stopwatch]::StartNew()
            Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing -TimeoutSec 60
            $sw.Stop()
            $sizeMB = (Get-Item $tmp).Length / 1MB
            $sec = $sw.Elapsed.TotalSeconds
            if ($sec -gt 0) {
                $mbps = [math]::Round(($sizeMB * 8) / $sec, 1)
                $col = "Green"; if ($mbps -lt 30) { $col = "Yellow" }; if ($mbps -lt 8) { $col = "Red" }
                & $log ("   Debit descendant : ~" + $mbps + " Mbps (" + [math]::Round($sizeMB,1) + " Mo en " + [math]::Round($sec,1) + " s)") $col
            }
            Remove-Item $tmp -ErrorAction SilentlyContinue
        } catch { & $log ("   Debit : " + $_.Exception.Message) "Yellow" }
        & $log "===== TEST TERMINE =====" "Green"
        $btnGo.Enabled = $true
    }.GetNewClosure())
    $f.Add_Shown({ $f.Activate() })
    [void]$f.ShowDialog()
}

# 11) ============ GESTION POINTS DE RESTAURATION ============
function RestoreMgrTool
{
    $f = New-MaintWindow "Points de restauration" 720 540
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 50; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Bottom"; $rtb.Height = 80; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 8); $f.Controls.Add($rtb)
    $lst = New-Object System.Windows.Forms.ListBox; $lst.Dock = "Fill"; $lst.Font = New-Object System.Drawing.Font("Consolas", 9); $f.Controls.Add($lst)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()

    $script:rps = @()
    $reload = {
        $lst.Items.Clear(); $script:rps = @()
        try { $script:rps = @(Get-ComputerRestorePoint -ErrorAction SilentlyContinue | Sort-Object SequenceNumber -Descending) } catch {}
        foreach ($r in $script:rps) {
            $d = $r.ConvertToDateTime($r.CreationTime)
            $lst.Items.Add(("#" + $r.SequenceNumber + "  " + $d.ToString("dd/MM/yyyy HH:mm") + "  -  " + $r.Description)) | Out-Null
        }
        if ($script:rps.Count -eq 0) { & $log "Aucun point de restauration (ou protection desactivee)." "Yellow" } else { & $log ($script:rps.Count.ToString() + " point(s).") "Cyan" }
    }.GetNewClosure()

    $btnNew = New-Object System.Windows.Forms.Button; $btnNew.Text = "Creer"; $btnNew.Location = New-Object System.Drawing.Point(12, 9); $btnNew.Size = New-Object System.Drawing.Size(110, 32)
    $btnNew.FlatStyle = "Flat"; $btnNew.FlatAppearance.BorderSize = 0; $btnNew.BackColor = [System.Drawing.Color]::FromArgb(22, 163, 74); $btnNew.ForeColor = "White"; $pBot.Controls.Add($btnNew)
    $btnRes = New-Object System.Windows.Forms.Button; $btnRes.Text = "Restaurer (selection)"; $btnRes.Location = New-Object System.Drawing.Point(130, 9); $btnRes.Size = New-Object System.Drawing.Size(180, 32)
    $btnRes.FlatStyle = "Flat"; $btnRes.FlatAppearance.BorderSize = 0; $btnRes.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235); $btnRes.ForeColor = "White"; $pBot.Controls.Add($btnRes)
    $btnPurge = New-Object System.Windows.Forms.Button; $btnPurge.Text = "Purger tout"; $btnPurge.Location = New-Object System.Drawing.Point(318, 9); $btnPurge.Size = New-Object System.Drawing.Size(120, 32)
    $btnPurge.FlatStyle = "Flat"; $btnPurge.FlatAppearance.BorderSize = 0; $btnPurge.BackColor = [System.Drawing.Color]::FromArgb(190, 18, 60); $btnPurge.ForeColor = "White"; $pBot.Controls.Add($btnPurge)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(446, 9); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront(); $lst.BringToFront()

    $btnNew.Add_Click({
        & $log "Creation d un point..." "Cyan"
        try { Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue } catch {}
        try { New-ItemProperty -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name "SystemRestorePointCreationFrequency" -Value 0 -PropertyType DWord -Force -ErrorAction SilentlyContinue | Out-Null } catch {}
        try { Checkpoint-Computer -Description ("Manuel - " + (Get-Date -Format "dd/MM HH:mm")) -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop; & $log "   Point cree." "Green" } catch { & $log ("   " + $_.Exception.Message) "Yellow" }
        & $reload
    }.GetNewClosure())
    $btnRes.Add_Click({
        $i = $lst.SelectedIndex
        if ($i -lt 0) { [System.Windows.Forms.MessageBox]::Show("Selectionnez un point."); return }
        $rp = $script:rps[$i]
        $r = [System.Windows.Forms.MessageBox]::Show(("Restaurer le point #" + $rp.SequenceNumber + " ?`nLe PC va redemarrer."), "Confirmation", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($r -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        try { Restore-Computer -RestorePoint $rp.SequenceNumber -ErrorAction Stop } catch { & $log ("   " + $_.Exception.Message) "Yellow" }
    }.GetNewClosure())
    $btnPurge.Add_Click({
        $r = [System.Windows.Forms.MessageBox]::Show("Supprimer TOUS les points de restauration ?", "Confirmation", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($r -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        try { $p = Start-Process "vssadmin.exe" -ArgumentList "delete shadows /all /quiet" -WindowStyle Hidden -PassThru; while (-not $p.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 150 }; & $log "   Points supprimes." "Green" } catch { & $log ("   " + $_.Exception.Message) "Yellow" }
        & $reload
    }.GetNewClosure())

    $f.Add_Shown({ $f.Activate(); & $reload }.GetNewClosure())
    [void]$f.ShowDialog()
}

# 12) ============ COMPTE ADMIN LOCAL + AUTOLOGON ============
function LocalAdminTool
{
    $f = New-MaintWindow "Compte admin local + autologon" 560 580
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 50; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Bottom"; $rtb.Height = 110; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 8); $f.Controls.Add($rtb)
    $panel = New-Object System.Windows.Forms.Panel; $panel.Dock = "Fill"; $panel.BackColor = "White"; $panel.Padding = New-Object System.Windows.Forms.Padding(14); $f.Controls.Add($panel)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()

    $lblU = New-Object System.Windows.Forms.Label; $lblU.Text = "Nom du compte :"; $lblU.Location = New-Object System.Drawing.Point(6, 10); $lblU.AutoSize = $true; $panel.Controls.Add($lblU)
    $txtU = New-Object System.Windows.Forms.TextBox; $txtU.Location = New-Object System.Drawing.Point(150, 8); $txtU.Width = 300; $txtU.Text = "Admin"; $panel.Controls.Add($txtU)
    $lblP = New-Object System.Windows.Forms.Label; $lblP.Text = "Mot de passe :"; $lblP.Location = New-Object System.Drawing.Point(6, 42); $lblP.AutoSize = $true; $panel.Controls.Add($lblP)
    $txtP = New-Object System.Windows.Forms.TextBox; $txtP.Location = New-Object System.Drawing.Point(150, 40); $txtP.Width = 300; $panel.Controls.Add($txtP)
    $cbAdmin = New-Object System.Windows.Forms.CheckBox; $cbAdmin.Text = "Membre du groupe Administrateurs"; $cbAdmin.Checked = $true; $cbAdmin.Location = New-Object System.Drawing.Point(8, 76); $cbAdmin.AutoSize = $true; $panel.Controls.Add($cbAdmin)
    $cbNoExp = New-Object System.Windows.Forms.CheckBox; $cbNoExp.Text = "Mot de passe n expire jamais"; $cbNoExp.Checked = $true; $cbNoExp.Location = New-Object System.Drawing.Point(8, 104); $cbNoExp.AutoSize = $true; $panel.Controls.Add($cbNoExp)
    $cbAuto = New-Object System.Windows.Forms.CheckBox; $cbAuto.Text = "Configurer l autologon pour ce compte"; $cbAuto.Location = New-Object System.Drawing.Point(8, 132); $cbAuto.AutoSize = $true; $panel.Controls.Add($cbAuto)
    $lblWarn = New-Object System.Windows.Forms.Label; $lblWarn.Text = "Note : l autologon stocke le mot de passe en clair dans le registre."; $lblWarn.Location = New-Object System.Drawing.Point(8, 160); $lblWarn.AutoSize = $true; $lblWarn.ForeColor = [System.Drawing.Color]::FromArgb(180, 83, 9); $panel.Controls.Add($lblWarn)
    $lblL = New-Object System.Windows.Forms.Label; $lblL.Text = "Comptes locaux existants :"; $lblL.Location = New-Object System.Drawing.Point(8, 196); $lblL.AutoSize = $true; $lblL.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9); $panel.Controls.Add($lblL)
    $lstU = New-Object System.Windows.Forms.ListBox; $lstU.Location = New-Object System.Drawing.Point(8, 220); $lstU.Size = New-Object System.Drawing.Size(360, 150); $lstU.Font = New-Object System.Drawing.Font("Segoe UI", 9); $panel.Controls.Add($lstU)
    $btnRen = New-Object System.Windows.Forms.Button; $btnRen.Text = "Renommer"; $btnRen.Location = New-Object System.Drawing.Point(378, 220); $btnRen.Size = New-Object System.Drawing.Size(150, 32); $btnRen.FlatStyle="Flat"; $btnRen.FlatAppearance.BorderSize=0; $btnRen.BackColor=[System.Drawing.Color]::FromArgb(37,99,235); $btnRen.ForeColor="White"; $panel.Controls.Add($btnRen)
    $btnSup = New-Object System.Windows.Forms.Button; $btnSup.Text = "Supprimer"; $btnSup.Location = New-Object System.Drawing.Point(378, 258); $btnSup.Size = New-Object System.Drawing.Size(150, 32); $btnSup.FlatStyle="Flat"; $btnSup.FlatAppearance.BorderSize=0; $btnSup.BackColor=[System.Drawing.Color]::FromArgb(190,18,60); $btnSup.ForeColor="White"; $panel.Controls.Add($btnSup)
    $btnRefU = New-Object System.Windows.Forms.Button; $btnRefU.Text = "Actualiser"; $btnRefU.Location = New-Object System.Drawing.Point(378, 296); $btnRefU.Size = New-Object System.Drawing.Size(150, 32); $btnRefU.FlatStyle="Flat"; $btnRefU.FlatAppearance.BorderSize=0; $btnRefU.BackColor=[System.Drawing.Color]::FromArgb(55,65,81); $btnRefU.ForeColor="White"; $panel.Controls.Add($btnRefU)
    $btnTog = New-Object System.Windows.Forms.Button; $btnTog.Text = "Activer / Desactiver"; $btnTog.Location = New-Object System.Drawing.Point(378, 334); $btnTog.Size = New-Object System.Drawing.Size(150, 32); $btnTog.FlatStyle="Flat"; $btnTog.FlatAppearance.BorderSize=0; $btnTog.BackColor=[System.Drawing.Color]::FromArgb(22,163,74); $btnTog.ForeColor="White"; $panel.Controls.Add($btnTog)
    $reloadU = { $lstU.Items.Clear(); Get-LocalUser -ErrorAction SilentlyContinue | ForEach-Object { $st = if ($_.Enabled) { "" } else { "  (desactive)" }; $lstU.Items.Add($_.Name + $st) | Out-Null } }.GetNewClosure()
    $selName = { if ($lstU.SelectedIndex -lt 0) { return $null } return (($lstU.SelectedItem -split "  \(")[0]).Trim() }.GetNewClosure()
    $btnRefU.Add_Click({ & $reloadU }.GetNewClosure())
    $btnTog.Add_Click({
        $n = & $selName; if (-not $n) { [System.Windows.Forms.MessageBox]::Show("Selectionnez un compte."); return }
        $u = Get-LocalUser -Name $n -ErrorAction SilentlyContinue
        if (-not $u) { return }
        try {
            if ($u.Enabled) { Disable-LocalUser -Name $n -ErrorAction Stop; & $log ("Compte desactive : " + $n) "Yellow"; Add-Journal ("Compte desactive: " + $n) }
            else { Enable-LocalUser -Name $n -ErrorAction Stop; & $log ("Compte active : " + $n) "Green"; Add-Journal ("Compte active: " + $n) }
        } catch { & $log ("Activation : " + $_.Exception.Message) "Yellow" }
        & $reloadU
    }.GetNewClosure())
    $btnRen.Add_Click({
        $old = & $selName; if (-not $old) { [System.Windows.Forms.MessageBox]::Show("Selectionnez un compte."); return }
        Add-Type -AssemblyName Microsoft.VisualBasic
        $new = [Microsoft.VisualBasic.Interaction]::InputBox(("Nouveau nom pour '" + $old + "' :"), "Renommer le compte", $old)
        if (-not $new -or $new -eq $old) { return }
        try { Rename-LocalUser -Name $old -NewName $new -ErrorAction Stop; & $log ("Compte renomme : " + $old + " -> " + $new) "Green"; Add-Journal ("Compte renomme: " + $old + " -> " + $new) } catch { & $log ("Renommage : " + $_.Exception.Message) "Yellow" }
        & $reloadU
    }.GetNewClosure())
    $btnSup.Add_Click({
        $n = & $selName; if (-not $n) { [System.Windows.Forms.MessageBox]::Show("Selectionnez un compte."); return }
        if ($n -ieq $env:USERNAME) { [System.Windows.Forms.MessageBox]::Show("Impossible de supprimer le compte en cours d utilisation."); return }
        $r = [System.Windows.Forms.MessageBox]::Show(("Supprimer le compte '" + $n + "' ?`n(Le dossier de profil n est pas supprime.)"), "Confirmation", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($r -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        try { Remove-LocalUser -Name $n -ErrorAction Stop; & $log ("Compte supprime : " + $n) "Green"; Add-Journal ("Compte supprime: " + $n) } catch { & $log ("Suppression : " + $_.Exception.Message) "Yellow" }
        & $reloadU
    }.GetNewClosure())
    & $reloadU

    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Creer / Configurer"; $btnGo.Location = New-Object System.Drawing.Point(12, 9); $btnGo.Size = New-Object System.Drawing.Size(220, 32)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(22, 163, 74); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(240, 9); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront(); $panel.BringToFront()

    $btnGo.Add_Click({
        $u = $txtU.Text.Trim(); $pw = $txtP.Text
        if (-not $u) { [System.Windows.Forms.MessageBox]::Show("Indiquez un nom de compte."); return }
        $btnGo.Enabled = $false
        & $log ("Compte : " + $u) "Cyan"
        try {
            $sec = if ($pw) { ConvertTo-SecureString $pw -AsPlainText -Force } else { (New-Object System.Security.SecureString) }
            $exist = Get-LocalUser -Name $u -ErrorAction SilentlyContinue
            if ($exist) {
                if ($pw) { Set-LocalUser -Name $u -Password $sec -ErrorAction SilentlyContinue }
                & $log "   Compte existant : mot de passe mis a jour." "Green"
            } else {
                New-LocalUser -Name $u -Password $sec -ErrorAction Stop | Out-Null
                & $log "   Compte cree." "Green"; Add-Journal ("Compte cree: " + $u)
            }
            if ($cbNoExp.Checked) { Set-LocalUser -Name $u -PasswordNeverExpires $true -ErrorAction SilentlyContinue }
            if ($cbAdmin.Checked) {
                $grp = (Get-LocalGroup -ErrorAction SilentlyContinue | Where-Object { $_.SID -like "*-544" }).Name
                if (-not $grp) { $grp = "Administrateurs" }
                try { Add-LocalGroupMember -Group $grp -Member $u -ErrorAction Stop; & $log ("   Ajoute au groupe " + $grp) "Green" } catch { if ($_.Exception.Message -match "deja|already") { & $log "   Deja administrateur." "Gray" } else { & $log ("   Groupe : " + $_.Exception.Message) "Yellow" } }
            }
            if ($cbAuto.Checked) {
                $rp = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
                Set-ItemProperty $rp -Name AutoAdminLogon -Value "1" -ErrorAction SilentlyContinue
                Set-ItemProperty $rp -Name DefaultUserName -Value $u -ErrorAction SilentlyContinue
                Set-ItemProperty $rp -Name DefaultPassword -Value $pw -ErrorAction SilentlyContinue
                Set-ItemProperty $rp -Name DefaultDomainName -Value $env:COMPUTERNAME -ErrorAction SilentlyContinue
                & $log "   Autologon configure." "Green"
            }
            & $log "Termine." "Green"
            & $reloadU
        } catch { & $log ("   Erreur : " + $_.Exception.Message) "Yellow" }
        $btnGo.Enabled = $true
    }.GetNewClosure())
    $f.Add_Shown({ $f.Activate() })
    [void]$f.ShowDialog()
}

###################################### Outils externes portables + Recup nom PC hors ligne ######################################

# Helper generique : telecharge un zip, l'extrait et lance l'exe (re-telecharge a chaque fois = pas de cache corrompu)
###################################### RDP - Restrictions & raccourci ######################################
function RdpTool
{
    $f = New-MaintWindow "RDP - Restrictions et raccourci" 620 560
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 50; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Bottom"; $rtb.Height = 120; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 8); $f.Controls.Add($rtb)
    $panel = New-Object System.Windows.Forms.Panel; $panel.Dock = "Fill"; $panel.BackColor = "White"; $panel.Padding = New-Object System.Windows.Forms.Padding(14); $panel.AutoScroll = $true; $f.Controls.Add($panel)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Red" { [System.Drawing.Color]::FromArgb(248,113,113) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()

    $lblH = New-Object System.Windows.Forms.Label; $lblH.Text = "Cible (IP ou nom du PC) :"; $lblH.Location = New-Object System.Drawing.Point(6, 8); $lblH.AutoSize = $true; $panel.Controls.Add($lblH)
    $txtHost = New-Object System.Windows.Forms.TextBox; $txtHost.Location = New-Object System.Drawing.Point(200, 6); $txtHost.Width = 360; $panel.Controls.Add($txtHost)
    $lblU = New-Object System.Windows.Forms.Label; $lblU.Text = "Utilisateur (optionnel) :"; $lblU.Location = New-Object System.Drawing.Point(6, 40); $lblU.AutoSize = $true; $panel.Controls.Add($lblU)
    $txtUser = New-Object System.Windows.Forms.TextBox; $txtUser.Location = New-Object System.Drawing.Point(200, 38); $txtUser.Width = 360; $panel.Controls.Add($txtUser)
    $lblR = New-Object System.Windows.Forms.Label; $lblR.Text = "Redirections a inclure dans le raccourci :"; $lblR.Location = New-Object System.Drawing.Point(6, 74); $lblR.AutoSize = $true; $lblR.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9); $panel.Controls.Add($lblR)
    $mkcb = { param($t, $y, $chk) $cb = New-Object System.Windows.Forms.CheckBox; $cb.Text = $t; $cb.Location = New-Object System.Drawing.Point(12, $y); $cb.AutoSize = $true; $cb.Checked = $chk; $cb.Font = New-Object System.Drawing.Font("Segoe UI", 9); $panel.Controls.Add($cb); return $cb }.GetNewClosure()
    $cbClip = & $mkcb "Presse-papier" 100 $true
    $cbPrint = & $mkcb "Imprimantes" 126 $true
    $cbDrives = & $mkcb "Lecteurs locaux (disques)" 152 $true
    $cbAudio = & $mkcb "Son (lecture)" 178 $true
    $cbMic = & $mkcb "Microphone" 204 $false
    $cbFull = & $mkcb "Plein ecran" 230 $true
    $cbNoWarn = & $mkcb "Supprimer l avertissement de securite au lancement" 256 $true
    $supprAvert = {
        & $log "Suppression de l avertissement RDP..." "Cyan"
        try {
            $c1 = "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\Client"
            if (-not (Test-Path $c1)) { New-Item -Path $c1 -Force | Out-Null }
            New-ItemProperty -Path $c1 -Name "RedirectionWarningDialogVersion" -Value 1 -PropertyType DWord -Force | Out-Null
            & $log "   HKLM RedirectionWarningDialogVersion = 1" "Green"
        } catch { & $log ("   HKLM : " + $_.Exception.Message) "Yellow" }
        try {
            $c2 = "HKCU:\Software\Microsoft\Terminal Server Client"
            if (-not (Test-Path $c2)) { New-Item -Path $c2 -Force | Out-Null }
            New-ItemProperty -Path $c2 -Name "AuthenticationLevelOverride" -Value 0 -PropertyType DWord -Force | Out-Null
            & $log "   HKCU AuthenticationLevelOverride = 0" "Green"
        } catch { & $log ("   HKCU : " + $_.Exception.Message) "Yellow" }
        try { Start-Process gpupdate -ArgumentList "/force" -WindowStyle Hidden -ErrorAction SilentlyContinue } catch {}
        & $log "   => Avertissement RDP supprime (gpupdate lance). Relancez la connexion." "Green"
    }.GetNewClosure()
    $btnWarn = New-Object System.Windows.Forms.Button
    $btnWarn.Text = "Supprimer l avertissement RDP (ce PC)"
    $btnWarn.Location = New-Object System.Drawing.Point(12, 290); $btnWarn.Size = New-Object System.Drawing.Size(420, 34)
    $btnWarn.FlatStyle = "Flat"; $btnWarn.FlatAppearance.BorderSize = 0; $btnWarn.BackColor = [System.Drawing.Color]::FromArgb(234, 88, 12); $btnWarn.ForeColor = "White"; $btnWarn.Cursor = "Hand"
    $panel.Controls.Add($btnWarn)
    $btnWarn.Add_Click({ & $supprAvert }.GetNewClosure())

    $btnRdp = New-Object System.Windows.Forms.Button; $btnRdp.Text = "Generer le raccourci .rdp"; $btnRdp.Location = New-Object System.Drawing.Point(8, 9); $btnRdp.Size = New-Object System.Drawing.Size(220, 32)
    $btnRdp.FlatStyle = "Flat"; $btnRdp.FlatAppearance.BorderSize = 0; $btnRdp.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235); $btnRdp.ForeColor = "White"; $pBot.Controls.Add($btnRdp)
    $btnLift = New-Object System.Windows.Forms.Button; $btnLift.Text = "Lever les restrictions RDP (ce PC)"; $btnLift.Location = New-Object System.Drawing.Point(236, 9); $btnLift.Size = New-Object System.Drawing.Size(268, 32)
    $btnLift.FlatStyle = "Flat"; $btnLift.FlatAppearance.BorderSize = 0; $btnLift.BackColor = [System.Drawing.Color]::FromArgb(22, 163, 74); $btnLift.ForeColor = "White"; $pBot.Controls.Add($btnLift)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(512, 9); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront(); $panel.BringToFront()

    $btnRdp.Add_Click({
        $h = $txtHost.Text.Trim()
        if (-not $h) { [System.Windows.Forms.MessageBox]::Show("Indiquez l adresse IP ou le nom du PC cible."); return }
        $lines = @()
        $lines += "full address:s:" + $h
        if ($txtUser.Text.Trim()) { $lines += "username:s:" + $txtUser.Text.Trim() }
        $lines += "redirectclipboard:i:" + $(if ($cbClip.Checked) { "1" } else { "0" })
        $lines += "redirectprinters:i:" + $(if ($cbPrint.Checked) { "1" } else { "0" })
        $lines += "drivestoredirect:s:" + $(if ($cbDrives.Checked) { "*" } else { "" })
        $lines += "audiomode:i:" + $(if ($cbAudio.Checked) { "0" } else { "2" })
        $lines += "audiocapturemode:i:" + $(if ($cbMic.Checked) { "1" } else { "0" })
        $lines += "screen mode id:i:" + $(if ($cbFull.Checked) { "2" } else { "1" })
        $lines += "redirectcomports:i:0"
        $lines += "redirectsmartcards:i:1"
        $lines += "prompt for credentials:i:1"
        $safe = ($h -replace '[^a-zA-Z0-9._-]', '_')
        $out = Join-Path ([Environment]::GetFolderPath("Desktop")) ("RDP_" + $safe + ".rdp")
        $lines | Out-File -FilePath $out -Encoding ASCII
        & $log ("Raccourci cree : " + $out) "Green"
        & $log "   (Double-cliquez dessus pour vous connecter avec ces choix.)" "Gray"
        if ($cbNoWarn.Checked) { & $supprAvert }
    }.GetNewClosure())

    $btnLift.Add_Click({
        $r = [System.Windows.Forms.MessageBox]::Show("Autoriser TOUTES les redirections RDP (presse-papier, imprimantes, lecteurs, son, PnP...) sur CE PC et activer le Bureau a distance ?", "Confirmation", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
        if ($r -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        & $log "Levee des restrictions RDP..." "Cyan"
        $gpo = "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
        try {
            if (-not (Test-Path $gpo)) { New-Item -Path $gpo -Force | Out-Null }
            foreach ($v in @("fDisableClip","fDisableCdm","fDisableCcm","fDisableLPT","fDisableCpm","fDisableCam","fDisablePNPRedir")) {
                Set-ItemProperty -Path $gpo -Name $v -Value 0 -Type DWord -ErrorAction SilentlyContinue
            }
            & $log "   Redirections autorisees (presse-papier, imprimantes, lecteurs, son, PnP)." "Green"
        } catch { & $log ("   Restrictions : " + $_.Exception.Message) "Yellow" }
        try {
            Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" -Name fDenyTSConnections -Value 0 -ErrorAction SilentlyContinue
            & $log "   Bureau a distance active." "Green"
        } catch {}
        try {
            Enable-NetFirewallRule -Group "@FirewallAPI.dll,-28752" -ErrorAction SilentlyContinue
            & $log "   Regle pare-feu Bureau a distance activee." "Green"
        } catch { & $log "   Pare-feu : verifier manuellement." "Yellow" }
        & $log "   => Termine. Les changements s appliquent aux nouvelles sessions RDP." "Green"
    }.GetNewClosure())

    $f.Add_Shown({ $f.Activate(); & $log "RDP : levez les restrictions sur le PC distant, et/ou generez un raccourci .rdp avec vos choix." "Gray" }.GetNewClosure())
    [void]$f.ShowDialog()
}

###################################### Audit compatibilite Windows 11 ######################################
function AuditWin11
{
    $f = New-MaintWindow "Audit compatibilite Windows 11" 780 600
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 50; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Fill"; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 9); $rtb.BorderStyle = "None"; $f.Controls.Add($rtb)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Red" { [System.Drawing.Color]::FromArgb(248,113,113) } "Gray" { [System.Drawing.Color]::FromArgb(148,163,184) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()
    $state = @{ rows = @() }
    $check = { param($name, $ok, $detail) $state.rows += [PSCustomObject]@{ Crit=$name; Ok=[bool]$ok; Detail=$detail }; if ($ok) { & $log ("[OK]  " + $name + " : " + $detail) "Green" } else { & $log ("[X]   " + $name + " : " + $detail) "Red" } }.GetNewClosure()

    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Lancer l audit"; $btnGo.Location = New-Object System.Drawing.Point(12, 9); $btnGo.Size = New-Object System.Drawing.Size(200, 32)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnRep = New-Object System.Windows.Forms.Button; $btnRep.Text = "Rapport HTML"; $btnRep.Location = New-Object System.Drawing.Point(220, 9); $btnRep.Size = New-Object System.Drawing.Size(150, 32)
    $btnRep.FlatStyle = "Flat"; $btnRep.FlatAppearance.BorderSize = 0; $btnRep.BackColor = [System.Drawing.Color]::FromArgb(79, 70, 229); $btnRep.ForeColor = "White"; $pBot.Controls.Add($btnRep)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(378, 9); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront()

    $btnGo.Add_Click({
        $btnGo.Enabled = $false; $state.rows = @(); $rtb.Clear()
        & $log "===== AUDIT COMPATIBILITE WINDOWS 11 =====" "Cyan"
        # Architecture
        $is64 = [Environment]::Is64BitOperatingSystem
        $d64 = if ($is64) { "64 bits" } else { "32 bits (non compatible)" }
        & $check "Architecture 64 bits" $is64 $d64
        # RAM
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
        $ramGB = if ($cs) { [math]::Round($cs.TotalPhysicalMemory / 1GB, 1) } else { 0 }
        & $check "Memoire RAM (>= 4 Go)" ($ramGB -ge 4) ($ramGB.ToString() + " Go")
        # Stockage (disque systeme)
        $diskGB = 0
        try { $dk = Get-Disk -ErrorAction SilentlyContinue | Where-Object { $_.IsBoot } | Select-Object -First 1; if (-not $dk) { $dk = Get-Disk -Number 0 -ErrorAction SilentlyContinue }; if ($dk) { $diskGB = [math]::Round($dk.Size / 1GB, 0) } } catch {}
        if ($diskGB -eq 0) { try { $diskGB = [math]::Round((Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='" + $env:SystemDrive + "'")).Size / 1GB, 0) } catch {} }
        & $check "Stockage (>= 64 Go)" ($diskGB -ge 64) ($diskGB.ToString() + " Go")
        # Processeur (coeurs / frequence / 64 bits)
        $cpu = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
        $cores = if ($cpu) { [int]$cpu.NumberOfCores } else { 0 }
        $mhz = if ($cpu) { [int]$cpu.MaxClockSpeed } else { 0 }
        $cpuOk = ($cores -ge 2) -and ($mhz -ge 1000)
        $cpuName = if ($cpu) { ($cpu.Name -replace '\s+', ' ').Trim() } else { "inconnu" }
        & $check "Processeur (>= 2 coeurs, >= 1 GHz)" $cpuOk ($cpuName + " - " + $cores + " coeurs @ " + [math]::Round($mhz/1000,2) + " GHz")
        # Firmware UEFI + Secure Boot
        $uefi = $false; $sb = $false
        try { $sb = [bool](Confirm-SecureBootUEFI -ErrorAction Stop); $uefi = $true } catch { $uefi = $false; $sb = $false }
        if (-not $uefi) { try { if (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State") { $uefi = $true; $sb = ((Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State" -ErrorAction SilentlyContinue).UEFISecureBootEnabled -eq 1) } } catch {} }
        $dUefi = if ($uefi) { "UEFI" } else { "BIOS Legacy (non compatible)" }
        & $check "Firmware UEFI" $uefi $dUefi
        $dSb = if ($sb) { "Active" } else { "Desactive (a activer dans le BIOS)" }
        & $check "Secure Boot active" $sb $dSb
        # TPM 2.0
        $tpmOk = $false; $tpmDet = "absent"
        try {
            $t = Get-Tpm -ErrorAction SilentlyContinue
            if ($t -and $t.TpmPresent) {
                $ver = $null
                try { $ver = (Get-CimInstance -Namespace "root\cimv2\security\microsofttpm" -Class Win32_Tpm -ErrorAction SilentlyContinue).SpecVersion } catch {}
                $is2 = ($ver -match "2\.0") -or ($ver -like "2*")
                $tpmOk = ($t.TpmPresent -and $t.TpmEnabled -and $is2)
                $tpmDet = "present, actif=" + $t.TpmEnabled + ", version=" + $ver
            }
        } catch {}
        & $check "TPM 2.0 present et actif" $tpmOk $tpmDet
        # Indicatif : generation CPU
        $gen = "indeterminee"
        if ($cpuName -match "Ultra") { $gen = "Intel Core Ultra (compatible)" }
        elseif ($cpuName -match "i[3579][- ](\d{4,5})") { $num=[int]$Matches[1]; $g=[math]::Floor($num/1000); if ($num -ge 10000) { $g=[math]::Floor($num/1000) }; if ($g -ge 8) { $gen = "Intel " + $g + "e generation (eligible)" } else { $gen = "Intel " + $g + "e generation (trop ancien pour la liste officielle)" } }
        elseif ($cpuName -match "Ryzen\s+\w+\s+(\d{4})") { $num=[int]$Matches[1]; if ($num -ge 2000) { $gen = "AMD Ryzen " + $num + " (eligible)" } else { $gen = "AMD Ryzen " + $num + " (1ere gen, non eligible officiellement)" } }
        & $log ("   Info modele CPU (indicatif) : " + $gen) "Gray"
        # Verdict
        $fail = @($state.rows | Where-Object { -not $_.Ok })
        & $log "" "Gray"
        if ($fail.Count -eq 0) { & $log ">>> VERDICT : COMPATIBLE Windows 11" "Green" }
        else {
            & $log (">>> VERDICT : NON COMPATIBLE (" + $fail.Count + " critere(s) en echec)") "Red"
            foreach ($x in $fail) { & $log ("      - " + $x.Crit) "Yellow" }
        }
        $btnGo.Enabled = $true
    }.GetNewClosure())

    $btnRep.Add_Click({
        if ($state.rows.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show("Lancez d abord l audit."); return }
        $fail = @($state.rows | Where-Object { -not $_.Ok })
        $verdict = if ($fail.Count -eq 0) { "COMPATIBLE Windows 11" } else { "NON COMPATIBLE (" + $fail.Count + " critere(s) en echec)" }
        $vcol = if ($fail.Count -eq 0) { "#16a34a" } else { "#dc2626" }
        $rowsH = ""
        foreach ($r in $state.rows) {
            $st = if ($r.Ok) { "<span style='color:#16a34a;font-weight:600'>OK</span>" } else { "<span style='color:#dc2626;font-weight:600'>ECHEC</span>" }
            $rowsH += "<tr><td>" + $r.Crit + "</td><td>" + $st + "</td><td>" + $r.Detail + "</td></tr>"
        }
        $h = "<html><head><meta charset='utf-8'><style>body{font-family:Segoe UI,Arial;padding:26px;color:#111} h1{color:#1e293b} .v{font-size:20px;font-weight:700;color:" + $vcol + ";margin:10px 0} table{border-collapse:collapse;width:100%;max-width:760px;background:#fff} td{padding:8px 12px;border-bottom:1px solid #eee} th{text-align:left;background:#f1f5f9;padding:8px 12px}</style></head><body>"
        $h += "<h1>Audit compatibilite Windows 11 - " + $env:COMPUTERNAME + "</h1><div class='v'>" + $verdict + "</div>"
        $h += "<table><tr><th>Critere</th><th>Etat</th><th>Detail</th></tr>" + $rowsH + "</table>"
        $h += "<p style='color:#64748b;font-size:12px;margin-top:16px'>Genere le " + (Get-Date -Format "dd/MM/yyyy HH:mm") + " par MultInstall</p></body></html>"
        $out = Join-Path ([Environment]::GetFolderPath("Desktop")) ("AuditWin11_" + $env:COMPUTERNAME + "_" + (Get-Date -Format "yyyyMMdd_HHmm") + ".html")
        $h | Out-File $out -Encoding UTF8
        Start-Process $out
    }.GetNewClosure())

    $f.Add_Shown({ $f.Activate(); & $log "Cliquez sur 'Lancer l audit' pour evaluer la compatibilite Windows 11." "Gray" }.GetNewClosure())
    [void]$f.ShowDialog()
}

function Start-PortableTool
{
    param($Url, $ZipName, $ExeFilter, $Label)
    Add-Type -AssemblyName System.Windows.Forms
    $zip = Join-Path $env:TEMP $ZipName
    $dir = Join-Path $env:TEMP ([System.IO.Path]::GetFileNameWithoutExtension($ZipName))
    try {
        if (Test-Path $zip) { Remove-Item $zip -Force -ErrorAction SilentlyContinue }
        if (Test-Path $dir) { Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue }
        if ($textBox) { $textBox.AppendText("Telechargement de " + $Label + "..." + [Environment]::NewLine); [System.Windows.Forms.Application]::DoEvents() }
        Invoke-WebRequest -Uri $Url -OutFile $zip -UseBasicParsing -TimeoutSec 90
        Expand-Archive -Path $zip -DestinationPath $dir -Force -ErrorAction Stop
        $exe = Get-ChildItem -Path $dir -Recurse -Filter $ExeFilter -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
        if ($exe) { Start-Process -FilePath $exe; if ($textBox) { $textBox.AppendText($Label + " lance." + [Environment]::NewLine) } }
        else { [System.Windows.Forms.MessageBox]::Show("Executable introuvable pour " + $Label + ".", $Label) }
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Erreur " + $Label + " : " + $_.Exception.Message, $Label)
    }
}

# Recupere le nom d'un PC depuis une installation Windows HORS LIGNE (disque secondaire / USB)
function RecupNomPcHL
{
    Add-Type -AssemblyName Microsoft.VisualBasic
    Add-Type -AssemblyName System.Windows.Forms
    $cands = @()
    foreach ($d in (Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
        try { if (Test-Path (Join-Path $d.Root "Windows\System32\config\SYSTEM")) { $cands += ($d.Root.TrimEnd('\')) } } catch {}
    }
    $hint = if ($cands) { "Disques avec Windows detectes : " + ($cands -join ", ") } else { "Aucune install Windows hors ligne detectee automatiquement." }
    $def = if ($cands) { $cands[0] } else { "E:" }
    $drv = [Microsoft.VisualBasic.Interaction]::InputBox(("Lecteur de l'installation Windows hors ligne (ex: E:)`n`n" + $hint), "Recup Nom PC (hors ligne)", $def)
    if (-not $drv) { return }
    $drv = $drv.TrimEnd('\')
    $hive = Join-Path $drv "Windows\System32\config\SYSTEM"
    if (-not (Test-Path $hive)) { [System.Windows.Forms.MessageBox]::Show("Ruche SYSTEM introuvable sur " + $drv, "Erreur"); return }
    $key = "HKLM\MultInstallTempHive"
    try {
        & reg load $key $hive | Out-Null
        $name = $null
        foreach ($cs in @("ControlSet001","ControlSet002","CurrentControlSet")) {
            $pth = "HKLM:\MultInstallTempHive\" + $cs + "\Control\ComputerName\ComputerName"
            if (Test-Path $pth) { $name = (Get-ItemProperty -Path $pth -ErrorAction SilentlyContinue).ComputerName; if ($name) { break } }
        }
        if ($name) {
            [System.Windows.Forms.MessageBox]::Show("Nom du PC (hors ligne) :`n`n" + $name, "Resultat")
            if ($textBox) { $textBox.AppendText("Nom PC hors ligne (" + $drv + ") : " + $name + [Environment]::NewLine) }
        } else { [System.Windows.Forms.MessageBox]::Show("Nom introuvable dans la ruche.", "Resultat") }
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Erreur : " + $_.Exception.Message, "Erreur")
    } finally {
        Start-Sleep -Milliseconds 200
        & reg unload $key 2>$null | Out-Null
    }
}

###################################### Pilotes - Gestion polyvalente ######################################
function PilotesTool
{
    $f = New-MaintWindow "Pilotes - Gestion polyvalente" 800 600
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 120; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Fill"; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 9); $rtb.BorderStyle = "None"; $f.Controls.Add($rtb)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Red" { [System.Drawing.Color]::FromArgb(248,113,113) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()

    $pbar = New-Object System.Windows.Forms.ProgressBar; $pbar.Location = New-Object System.Drawing.Point(120, 84); $pbar.Size = New-Object System.Drawing.Size(660, 20); $pbar.Style = "Continuous"; $pBot.Controls.Add($pbar)

    # Lance un process et affiche sa sortie (encodage OEM), fenetre reactive
    $run = {
        param($exe, $argLine, $label)
        $pbar.Style = "Marquee"
        $o = Join-Path $env:TEMP ("drv_" + [guid]::NewGuid().ToString("N") + ".txt")
        $p = Start-Process $exe -ArgumentList $argLine -WindowStyle Hidden -PassThru -RedirectStandardOutput $o
        while (-not $p.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 200 }
        try { $p.WaitForExit() } catch {}
        $txt = ""
        try { $bytes = [System.IO.File]::ReadAllBytes($o); $txt = [System.Text.Encoding]::GetEncoding(850).GetString($bytes) } catch {}
        Remove-Item $o -ErrorAction SilentlyContinue
        $pbar.Style = "Continuous"
        $script:drvOut = $txt
        return $p.ExitCode
    }.GetNewClosure()

    $mk = { param($t, $x, $y, $w, $col) $b = New-Object System.Windows.Forms.Button; $b.Text = $t; $b.Location = New-Object System.Drawing.Point($x, $y); $b.Size = New-Object System.Drawing.Size($w, 32); $b.FlatStyle = "Flat"; $b.FlatAppearance.BorderSize = 0; $b.BackColor = $col; $b.ForeColor = "White"; $b.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 8); $pBot.Controls.Add($b); return $b }.GetNewClosure()
    $btnSave = & $mk "Sauvegarder tous les pilotes" 8 8 250 ([System.Drawing.Color]::FromArgb(22,163,74))
    $btnRest = & $mk "Restaurer depuis un dossier" 266 8 250 ([System.Drawing.Color]::FromArgb(37,99,235))
    $btnList = & $mk "Lister les pilotes tiers" 524 8 256 ([System.Drawing.Color]::FromArgb(79,70,229))
    $btnProb = & $mk "Peripheriques en erreur" 8 44 250 ([System.Drawing.Color]::FromArgb(202,138,4))
    $btnUpd  = & $mk "Rechercher MAJ pilotes (WU)" 266 44 250 ([System.Drawing.Color]::FromArgb(13,148,136))
    $btnDev  = & $mk "Gestionnaire de peripheriques" 524 44 256 ([System.Drawing.Color]::FromArgb(71,85,105))
    $btnC = & $mk "Fermer" 8 80 100 ([System.Drawing.Color]::FromArgb(55,65,81))
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront()

    $btnSave.Add_Click({
        $dest = Join-Path ([Environment]::GetFolderPath("Desktop")) ("Pilotes_" + $env:COMPUTERNAME + "_" + (Get-Date -Format "yyyyMMdd_HHmm"))
        New-Item -Path $dest -ItemType Directory -Force | Out-Null
        & $log "Sauvegarde des pilotes tiers en cours (peut prendre 1-2 min)..." "Cyan"
        $code = & $run "pnputil.exe" ("/export-driver * `"" + $dest + "`"") "save"
        $n = (Get-ChildItem $dest -Directory -ErrorAction SilentlyContinue).Count
        if ($n -gt 0) { & $log ("   => " + $n + " pilote(s) sauvegarde(s) dans : " + $dest) "Green" }
        else { & $log ("   => Aucun pilote exporte (code " + $code + ")") "Yellow" }
        Start-Process explorer.exe $dest
    }.GetNewClosure())

    $btnRest.Add_Click({
        $fb = New-Object System.Windows.Forms.FolderBrowserDialog
        $fb.Description = "Choisir le dossier de sauvegarde des pilotes"
        if ($fb.ShowDialog() -ne "OK") { return }
        & $log ("Restauration depuis : " + $fb.SelectedPath) "Cyan"
        $code = & $run "pnputil.exe" ("/add-driver `"" + $fb.SelectedPath + "\*.inf`" /subdirs /install") "restore"
        $o = "" + $script:drvOut
        foreach ($ln in ($o -split "`r|`n")) { $t = $ln.Trim(); if ($t -and $t -notmatch "^Microsoft" -and $t.Length -gt 3) { & $log ("   " + $t) "Gray" } }
        & $log ("   => Restauration terminee (code " + $code + ")") "Green"
    }.GetNewClosure())

    $btnList.Add_Click({
        & $log "Pilotes tiers installes :" "Cyan"
        $code = & $run "pnputil.exe" "/enum-drivers" "list"
        $o = "" + $script:drvOut
        $pub = ""; $orig = ""; $cnt = 0
        foreach ($ln in ($o -split "`r|`n")) {
            $t = $ln.Trim()
            if ($t -match "Nom publi.*:\s*(.+)$" -or $t -match "Published Name\s*:\s*(.+)$") { $pub = $Matches[1].Trim() }
            elseif ($t -match "Nom d.origine.*:\s*(.+)$" -or $t -match "Original Name\s*:\s*(.+)$") { $orig = $Matches[1].Trim() }
            elseif (($t -match "Fournisseur.*:\s*(.+)$" -or $t -match "Provider Name\s*:\s*(.+)$")) { $prov = $Matches[1].Trim(); if ($pub) { & $log ("   " + $pub + "  <- " + $orig + "  (" + $prov + ")") "White"; $cnt++; $pub = "" } }
        }
        & $log ("   => " + $cnt + " pilote(s) tiers.") "Green"
    }.GetNewClosure())

    $btnProb.Add_Click({
        & $log "Peripheriques en erreur ou sans pilote :" "Cyan"
        try {
            $bad = Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object { $_.ConfigManagerErrorCode -and $_.ConfigManagerErrorCode -ne 0 }
            if ($bad) { foreach ($d in $bad) { & $log ("   [code " + $d.ConfigManagerErrorCode + "] " + $d.Name) "Yellow" } ; & $log ("   => " + @($bad).Count + " peripherique(s) a corriger.") "Yellow" }
            else { & $log "   => Aucun peripherique en erreur. Tous les pilotes sont OK." "Green" }
        } catch { & $log ("   Erreur : " + $_.Exception.Message) "Red" }
    }.GetNewClosure())

    $btnUpd.Add_Click({
        & $log "Recherche de mises a jour de pilotes via Windows Update..." "Cyan"
        try { Start-Process "ms-settings:windowsupdate" ; & $log "   Page Windows Update ouverte (les pilotes optionnels sont sous 'Options avancees > Mises a jour facultatives')." "Green" } catch {}
        try { Start-Process "usoclient.exe" -ArgumentList "StartInteractiveScan" -WindowStyle Hidden -ErrorAction SilentlyContinue } catch {}
    }.GetNewClosure())

    $btnDev.Add_Click({ Start-Process "devmgmt.msc" }.GetNewClosure())

    $f.Add_Shown({ $f.Activate(); & $log "Outil pilotes pret. Choisissez une action ci-dessous." "Gray" }.GetNewClosure())
    [void]$f.ShowDialog()
}

###################################### Infos ordinateur - inventaire complet ######################################
function InfosPC
{
    $f = New-MaintWindow "Infos ordinateur - inventaire complet" 840 660
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 50; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Fill"; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(226, 232, 240); $rtb.Font = New-Object System.Drawing.Font("Consolas", 9); $rtb.BorderStyle = "None"; $f.Controls.Add($rtb)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Gray" { [System.Drawing.Color]::FromArgb(148,163,184) } default { [System.Drawing.Color]::FromArgb(226,232,240) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()
    $state = @{ rows = @(); sec = "" }
    $sec = { param($t) $state.sec = $t; & $log "" "Gray"; & $log ("===== " + $t + " =====") "Cyan" }.GetNewClosure()
    $kv = { param($k, $v) if ($null -eq $v -or "$v" -eq "") { $v = "-" }; & $log ("  " + ([string]$k).PadRight(26) + ": " + $v) "White"; $state.rows += [PSCustomObject]@{ Sec=$state.sec; K=$k; V=[string]$v } }.GetNewClosure()

    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Actualiser"; $btnGo.Location = New-Object System.Drawing.Point(12, 9); $btnGo.Size = New-Object System.Drawing.Size(160, 32)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnRep = New-Object System.Windows.Forms.Button; $btnRep.Text = "Rapport HTML"; $btnRep.Location = New-Object System.Drawing.Point(180, 9); $btnRep.Size = New-Object System.Drawing.Size(150, 32)
    $btnRep.FlatStyle = "Flat"; $btnRep.FlatAppearance.BorderSize = 0; $btnRep.BackColor = [System.Drawing.Color]::FromArgb(79, 70, 229); $btnRep.ForeColor = "White"; $pBot.Controls.Add($btnRep)
    $btnCopy = New-Object System.Windows.Forms.Button; $btnCopy.Text = "Copier"; $btnCopy.Location = New-Object System.Drawing.Point(338, 9); $btnCopy.Size = New-Object System.Drawing.Size(110, 32)
    $btnCopy.FlatStyle = "Flat"; $btnCopy.FlatAppearance.BorderSize = 0; $btnCopy.BackColor = [System.Drawing.Color]::FromArgb(71, 85, 105); $btnCopy.ForeColor = "White"; $pBot.Controls.Add($btnCopy)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(456, 9); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $btnCopy.Add_Click({ try { [System.Windows.Forms.Clipboard]::SetText($rtb.Text) } catch {} }.GetNewClosure())
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront()

    $collect = {
        $btnGo.Enabled = $false; $state.rows = @(); $rtb.Clear()
        & $log "Collecte des informations..." "Gray"
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue

        & $sec "SYSTEME"
        & $kv "Nom du PC" $env:COMPUTERNAME
        & $kv "Utilisateur" $cs.UserName
        & $kv "Systeme" $os.Caption
        & $kv "Edition / Version" ($os.Version + "  (build " + $os.BuildNumber + ")")
        try { $cv = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -ErrorAction SilentlyContinue; $rel = $cv.DisplayVersion; if (-not $rel) { $rel = $cv.ReleaseId }; & $kv "Version (release)" $rel; if ($cv.UBR) { & $kv "Build complet" ($os.BuildNumber + "." + $cv.UBR) } } catch {}
        & $kv "Architecture" $os.OSArchitecture
        try { & $kv "Installe le" ($os.InstallDate.ToString("dd/MM/yyyy HH:mm")) } catch {}
        try { $up = (Get-Date) - $os.LastBootUpTime; & $kv "Uptime" ($up.Days + " j " + $up.Hours + " h " + $up.Minutes + " min") } catch {}
        try { $lic = Get-CimInstance SoftwareLicensingProduct -Filter "ApplicationID='55c92734-d682-4d71-983e-d6ec3f16059f' AND LicenseStatus=1" -ErrorAction SilentlyContinue | Select-Object -First 1; if ($lic) { & $kv "Activation Windows" "Active" } else { & $kv "Activation Windows" "Non active / inconnue" } } catch {}

        & $sec "CARTE MERE / BIOS"
        $bb = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue
        & $kv "Fabricant / Modele PC" ($cs.Manufacturer + " " + $cs.Model)
        & $kv "Carte mere" ($bb.Manufacturer + " " + $bb.Product)
        $bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
        & $kv "BIOS" ($bios.Manufacturer + " " + $bios.SMBIOSBIOSVersion)
        try { & $kv "Date BIOS" ($bios.ReleaseDate.ToString("dd/MM/yyyy")) } catch {}
        & $kv "Numero de serie" $bios.SerialNumber
        $uefi = "BIOS Legacy"; $sb = "N/A (Legacy)"
        try { $sbv = Confirm-SecureBootUEFI -ErrorAction Stop; $uefi = "UEFI"; if ($sbv) { $sb = "Active" } else { $sb = "Desactive" } } catch { if (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State") { $uefi = "UEFI"; $sb = "Desactive" } }
        & $kv "Mode firmware" $uefi
        & $kv "Secure Boot" $sb

        & $sec "PROCESSEUR"
        $cpu = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
        & $kv "Modele" (($cpu.Name -replace '\s+', ' ').Trim())
        & $kv "Coeurs / Threads" ($cpu.NumberOfCores.ToString() + " coeurs / " + $cpu.NumberOfLogicalProcessors + " threads")
        & $kv "Frequence max" ([math]::Round($cpu.MaxClockSpeed / 1000, 2).ToString() + " GHz")
        & $kv "Socket" $cpu.SocketDesignation
        & $kv "Cache L2 / L3" (([math]::Round($cpu.L2CacheSize/1024,1)).ToString() + " Mo / " + ([math]::Round($cpu.L3CacheSize/1024,1)) + " Mo")

        & $sec "MEMOIRE (RAM)"
        if ($cs) { & $kv "RAM totale" ([math]::Round($cs.TotalPhysicalMemory / 1GB, 1).ToString() + " Go") }
        try { $arr = Get-CimInstance Win32_PhysicalMemoryArray -ErrorAction SilentlyContinue | Select-Object -First 1; if ($arr) { & $kv "Emplacements" ($arr.MemoryDevices.ToString() + " slots") } } catch {}
        $memMap = @{ 20="DDR"; 21="DDR2"; 22="DDR2 FB-DIMM"; 24="DDR3"; 26="DDR4"; 34="DDR5"; 27="LPDDR"; 28="LPDDR2"; 29="LPDDR3"; 30="LPDDR4"; 35="LPDDR5" }
        $ffMap = @{ 8="DIMM"; 12="SODIMM"; 11="Row of chips"; 13="Die (BGA)" }
        $idx = 1; $anySold = $false; $anyRem = $false
        foreach ($m in (Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue)) {
            $type = $memMap[[int]$m.SMBIOSMemoryType]; if (-not $type) { $type = "Type " + $m.SMBIOSMemoryType }
            $ffv = [int]$m.FormFactor
            $ff = $ffMap[$ffv]; if (-not $ff) { $ff = "" }
            $isLP = $type -like 'LPDDR*'
            if ($isLP -or $ffv -eq 11 -or $ffv -eq 13) { $mont = "Soudee"; $anySold = $true } elseif ($ffv -eq 8 -or $ffv -eq 12) { $mont = "Amovible"; $anyRem = $true } else { $mont = "?" }
            $cap = [math]::Round($m.Capacity / 1GB, 0)
            $slot = if ($m.DeviceLocator) { $m.DeviceLocator } else { "Slot" }
            & $kv ("Barrette " + $idx + " [" + $slot + "]") ($cap.ToString() + " Go  " + $type + " " + $ff + " @ " + $m.Speed + " MHz  [" + $mont + "]  " + ($m.Manufacturer).Trim() + "  " + ($m.PartNumber).Trim())
            $idx++
        }
        $montage = "indetermine"
        if ($anySold -and -not $anyRem) { $montage = "SOUDEE (non evolutive sans intervention atelier)" }
        elseif ($anyRem -and -not $anySold) { $montage = "Amovible (SODIMM/DIMM)" }
        elseif ($anySold -and $anyRem) { $montage = "Mixte (soudee + slot libre possible)" }
        & $kv "Montage RAM" $montage

        & $sec "CARTE GRAPHIQUE"
        foreach ($g in (Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue)) {
            $vram = if ($g.AdapterRAM -gt 0) { ([math]::Round($g.AdapterRAM / 1GB, 1)).ToString() + " Go" } else { "?" }
            & $kv "GPU" ($g.Name + "  (" + $vram + ", pilote " + $g.DriverVersion + ")")
        }

        & $sec "STOCKAGE"
        $phys = @{}
        try { foreach ($pd in (Get-PhysicalDisk -ErrorAction SilentlyContinue)) { $phys[[string]$pd.DeviceId] = $pd } } catch {}
        try {
            foreach ($d in (Get-Disk -ErrorAction SilentlyContinue | Sort-Object Number)) {
                $pd = $phys[[string]$d.Number]
                $media = if ($pd) { $pd.MediaType } else { "?" }
                $bus = if ($pd) { $pd.BusType } else { "?" }
                $health = if ($pd) { $pd.HealthStatus } else { "" }
                $szGB = [math]::Round($d.Size / 1GB, 0)
                & $kv ("Disque " + $d.Number) ($d.FriendlyName + "  " + $szGB + " Go  [" + $media + " / " + $bus + "]  " + $d.PartitionStyle + "  " + $health)
            }
        } catch {}

        & $sec "VOLUMES"
        foreach ($v in (Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction SilentlyContinue)) {
            $tot = [math]::Round($v.Size / 1GB, 1); $free = [math]::Round($v.FreeSpace / 1GB, 1)
            & $kv ($v.DeviceID + " " + $v.VolumeName) ($free.ToString() + " Go libres / " + $tot + " Go  (" + $v.FileSystem + ")")
        }

        & $sec "RESEAU"
        try {
            foreach ($a in (Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq "Up" })) {
                $ip = (Get-NetIPAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -First 1).IPAddress
                & $kv ($a.Name + " (" + $a.LinkSpeed + ")") ("IP " + $ip + "  MAC " + $a.MacAddress)
            }
        } catch {}
        try { $pub = Invoke-RestMethod -Uri "https://api.ipify.org" -TimeoutSec 5 -ErrorAction SilentlyContinue; if ($pub) { & $kv "IP publique" $pub } } catch {}

        & $sec "SECURITE"
        try { $t = Get-Tpm -ErrorAction SilentlyContinue; if ($t -and $t.TpmPresent) { $ver = (Get-CimInstance -Namespace "root\cimv2\security\microsofttpm" -Class Win32_Tpm -ErrorAction SilentlyContinue).SpecVersion; & $kv "TPM" ("present, actif=" + $t.TpmEnabled + ", version " + $ver) } else { & $kv "TPM" "absent" } } catch { & $kv "TPM" "indisponible" }
        try { $bl = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction SilentlyContinue; if ($bl) { & $kv ("BitLocker " + $env:SystemDrive) ($bl.VolumeStatus.ToString() + " / " + $bl.ProtectionStatus) } } catch {}

        & $log "" "Gray"
        & $log "Inventaire termine." "Green"
        $btnGo.Enabled = $true
    }.GetNewClosure()

    $btnRep.Add_Click({
        if ($state.rows.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show("Lancez d abord la collecte."); return }
        $h = "<html><head><meta charset='utf-8'><style>body{font-family:Segoe UI,Arial;padding:24px;color:#0f172a;background:#f8fafc} h1{color:#1e293b} h2{color:#2563eb;border-bottom:2px solid #e2e8f0;padding-bottom:4px;margin-top:22px} table{border-collapse:collapse;width:100%;max-width:860px} td{padding:5px 10px;border-bottom:1px solid #eef2f7} .k{font-weight:600;color:#475569;width:280px}</style></head><body>"
        $h += "<h1>Inventaire - " + $env:COMPUTERNAME + "</h1>"
        $cur = ""
        foreach ($r in $state.rows) {
            if ($r.Sec -ne $cur) { if ($cur) { $h += "</table>" }; $h += "<h2>" + $r.Sec + "</h2><table>"; $cur = $r.Sec }
            $h += "<tr><td class='k'>" + $r.K + "</td><td>" + ($r.V -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;') + "</td></tr>"
        }
        $h += "</table><p style='color:#64748b;font-size:12px;margin-top:18px'>Genere le " + (Get-Date -Format "dd/MM/yyyy HH:mm") + " par MultInstall</p></body></html>"
        $out = Join-Path ([Environment]::GetFolderPath("Desktop")) ("Infos_" + $env:COMPUTERNAME + "_" + (Get-Date -Format "yyyyMMdd_HHmm") + ".html")
        $h | Out-File $out -Encoding UTF8
        Start-Process $out
    }.GetNewClosure())

    $btnGo.Add_Click({ & $collect }.GetNewClosure())
    $f.Add_Shown({ $f.Activate(); & $collect }.GetNewClosure())
    [void]$f.ShowDialog()
}

###################################### Windows Update silencieux + MAJ winget ######################################
function WindowsUpdateTool
{
    $f = New-MaintWindow "Windows Update - installation silencieuse" 780 580
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 50; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Fill"; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 9); $rtb.BorderStyle = "None"; $f.Controls.Add($rtb)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Red" { [System.Drawing.Color]::FromArgb(248,113,113) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()
    $pbar = New-Object System.Windows.Forms.ProgressBar; $pbar.Location = New-Object System.Drawing.Point(400, 13); $pbar.Size = New-Object System.Drawing.Size(366, 24); $pbar.Style = "Continuous"; $pBot.Controls.Add($pbar)
    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Rechercher et installer les MAJ"; $btnGo.Location = New-Object System.Drawing.Point(12, 9); $btnGo.Size = New-Object System.Drawing.Size(280, 32)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(300, 9); $btnC.Size = New-Object System.Drawing.Size(90, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront()

    $btnGo.Add_Click({
        $btnGo.Enabled = $false; $pbar.Style = "Marquee"
        & $log "===== WINDOWS UPDATE (silencieux) =====" "Cyan"
        try {
            $session = New-Object -ComObject Microsoft.Update.Session
            $searcher = $session.CreateUpdateSearcher()
            & $log "Recherche des mises a jour (peut prendre 1-2 min)..." "Cyan"
            $res = $searcher.Search("IsInstalled=0 and IsHidden=0")
            if ($res.Updates.Count -eq 0) { & $log "Aucune mise a jour disponible. Systeme a jour." "Green"; $pbar.Style="Continuous"; $btnGo.Enabled=$true; return }
            & $log ($res.Updates.Count.ToString() + " mise(s) a jour trouvee(s) :") "Cyan"
            foreach ($u in $res.Updates) { & $log ("   - " + $u.Title) "White" }
            [System.Windows.Forms.Application]::DoEvents()
            $rebootNeeded = $false; $okCount = 0; $errCount = 0
            $dl = $session.CreateUpdateDownloader()
            $inst = $session.CreateUpdateInstaller()
            foreach ($u in $res.Updates) {
                try { if (-not $u.EulaAccepted) { $u.AcceptEula() } } catch {}
                $coll = New-Object -ComObject Microsoft.Update.UpdateColl
                $coll.Add($u) | Out-Null
                & $log ("Telechargement : " + $u.Title) "Cyan"
                $dl.Updates = $coll
                try { $dl.Download() | Out-Null } catch { & $log ("   echec telechargement : " + $_.Exception.Message) "Yellow"; $errCount++; continue }
                [System.Windows.Forms.Application]::DoEvents()
                & $log ("Installation : " + $u.Title) "Cyan"
                $inst.Updates = $coll
                try {
                    $ir = $inst.Install()
                    if ($ir.ResultCode -eq 2) { & $log "   OK - installe" "Green"; $okCount++ }
                    elseif ($ir.ResultCode -eq 3) { & $log "   installe avec avertissements" "Yellow"; $okCount++ }
                    else { & $log ("   echec (code " + $ir.ResultCode + ")") "Yellow"; $errCount++ }
                    if ($ir.RebootRequired) { $rebootNeeded = $true }
                } catch { & $log ("   echec installation : " + $_.Exception.Message) "Yellow"; $errCount++ }
                [System.Windows.Forms.Application]::DoEvents()
            }
            & $log "" "White"
            & $log ("===== TERMINE : " + $okCount + " installee(s), " + $errCount + " en erreur =====") "Green"
            if ($rebootNeeded) { & $log ">>> Un REDEMARRAGE est necessaire pour finaliser." "Yellow" }
        } catch { & $log ("Erreur Windows Update : " + $_.Exception.Message) "Red" }
        $pbar.Style = "Continuous"; $btnGo.Enabled = $true
    }.GetNewClosure())

    $f.Add_Shown({ $f.Activate(); & $log "Cliquez pour rechercher et installer toutes les MAJ Windows en silence (sans popup)." "White" }.GetNewClosure())
    [void]$f.ShowDialog()
}

function WingetUpdateTool
{
    function global:JLog($m){ try { $jd=Join-Path $env:ProgramData "MultInstall"; if(-not(Test-Path $jd)){New-Item $jd -ItemType Directory -Force -ErrorAction SilentlyContinue|Out-Null}; Add-Content -Path (Join-Path $jd "journal.txt") -Value ("["+(Get-Date -Format "dd/MM HH:mm")+"] "+$m) -Encoding UTF8 -ErrorAction SilentlyContinue } catch {} }
    $f = New-MaintWindow "MAJ logiciels (winget)" 840 640
    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 86; $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Bottom"; $rtb.Height = 130; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 8); $f.Controls.Add($rtb)
    $clb = New-Object System.Windows.Forms.CheckedListBox; $clb.Dock = "Fill"; $clb.CheckOnClick = $true; $clb.Font = New-Object System.Drawing.Font("Segoe UI", 9); $f.Controls.Add($clb)
    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Red" { [System.Drawing.Color]::FromArgb(248,113,113) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()
    $state = @{ apps = @() }

    $pbar = New-Object System.Windows.Forms.ProgressBar; $pbar.Location = New-Object System.Drawing.Point(470, 10); $pbar.Size = New-Object System.Drawing.Size(355, 24); $pbar.Style = "Continuous"; $pBot.Controls.Add($pbar)
    $mk = { param($t, $x, $y, $w, $col) $b = New-Object System.Windows.Forms.Button; $b.Text = $t; $b.Location = New-Object System.Drawing.Point($x, $y); $b.Size = New-Object System.Drawing.Size($w, 32); $b.FlatStyle = "Flat"; $b.FlatAppearance.BorderSize = 0; $b.BackColor = $col; $b.ForeColor = "White"; $b.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 8); $pBot.Controls.Add($b); return $b }.GetNewClosure()
    $btnRef = & $mk "Actualiser la liste" 8 8 180 ([System.Drawing.Color]::FromArgb(37,99,235))
    $btnAll = & $mk "Tout cocher" 196 8 120 ([System.Drawing.Color]::FromArgb(71,85,105))
    $btnNone = & $mk "Tout decocher" 324 8 130 ([System.Drawing.Color]::FromArgb(107,114,128))
    $btnUpd = & $mk "Mettre a jour la selection" 8 46 250 ([System.Drawing.Color]::FromArgb(22,163,74))
    $btnUni = & $mk "Desinstaller la selection" 266 46 240 ([System.Drawing.Color]::FromArgb(190,18,60))
    $btnC = & $mk "Fermer" 736 46 90 ([System.Drawing.Color]::FromArgb(55,65,81))
    $btnC.Add_Click({ $f.Close() })
    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront(); $clb.BringToFront()

    $checkWg = { if (Get-Command winget.exe -ErrorAction SilentlyContinue) { return $true }; [System.Windows.Forms.MessageBox]::Show("winget (App Installer) n est pas disponible sur ce poste."); return $false }.GetNewClosure()

    # Lance winget, affiche la sortie filtree, fenetre reactive
    $runWg = {
        param($a)
        $pbar.Style = "Marquee"; [System.Windows.Forms.Application]::DoEvents()
        try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
        try {
            $out = (& winget @a 2>&1 | Out-String)
            foreach ($ln in ($out -split "`r|`n")) { $t = $ln.Trim(); if ($t -and ($t -notmatch '^[█░\-\\|/ ]+$') -and $t.Length -gt 2) { & $log ("   " + $t) "Gray" } }
        } catch { & $log ("   erreur winget : " + $_.Exception.Message) "Yellow" }
        $pbar.Style = "Continuous"
    }.GetNewClosure()

    # Capture simple (sans affichage) pour parsing
    $capture = {
        param($argLine)
        $a = @($argLine -split ' ' | Where-Object { $_ })
        try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
        try { return ((& winget @a 2>&1 | Out-String)) } catch { return ("ERR:" + $_.Exception.Message) }
    }.GetNewClosure()


    $loadList = {
        if (-not (& $checkWg)) { return }
        $btnRef.Enabled = $false; $clb.Items.Clear()
        & $log "Liste des logiciels installes..." "Cyan"
        $pbar.Style = "Marquee"
        $txt = & $capture "list --accept-source-agreements"
        $pbar.Style = "Continuous"
        $state.apps = @()
        $lines = ([string]$txt) -split "`r?`n"
        $hi = -1
        for ($z = 0; $z -lt $lines.Count; $z++) { if (($lines[$z] -match '\bId\b') -and ($lines[$z] -match '\bVersion\b')) { $hi = $z; break } }
        if ($hi -ge 0) {
            $hu = ([string]$lines[$hi]).ToUpper()
            $cId = $hu.IndexOf("ID"); $cVer = $hu.IndexOf("VERSION")
            $cAv = $hu.IndexOf("DISPONIBLE"); if ($cAv -lt 0) { $cAv = $hu.IndexOf("AVAILABLE") }
            $cSrc = $hu.IndexOf("SOURCE")
            if ($cId -ge 0 -and $cVer -gt $cId -and $cAv -gt $cVer) {
                for ($z = $hi + 1; $z -lt $lines.Count; $z++) {
                    $l = [string]$lines[$z]
                    if (-not $l.Trim()) { continue }
                    if ($l -match '^\s*-{3,}\s*$') { continue }
                    if ($l.Length -le $cId) { continue }
                    $name = $l.Substring(0, [Math]::Min($cId, $l.Length)).Trim()
                    $en = [Math]::Min($cVer, $l.Length); $id = $l.Substring($cId, $en - $cId).Trim()
                    $cur = ""; if ($l.Length -gt $cVer) { $en = [Math]::Min($cAv, $l.Length); if ($en -gt $cVer) { $cur = $l.Substring($cVer, $en - $cVer).Trim() } }
                    $av = ""; if ($l.Length -gt $cAv) { $en = $l.Length; if ($cSrc -gt $cAv -and $cSrc -le $l.Length) { $en = $cSrc }; $av = $l.Substring($cAv, $en - $cAv).Trim() }
                    if ($name -and $id) { $state.apps += [PSCustomObject]@{ Name = $name; Id = $id; Cur = $cur; Avail = $av } }
                }
            }
        }
        $nMaj = 0
        foreach ($a in $state.apps) {
            if ($a.Avail) { $maj = "   [MAJ -> " + $a.Avail + "]"; $nMaj++ } else { $maj = "" }
            $clb.Items.Add($a.Name + "   (" + $a.Cur + ")" + $maj + "   [" + $a.Id + "]") | Out-Null
        }
        & $log ($state.apps.Count.ToString() + " logiciel(s) installe(s), " + $nMaj + " avec une MAJ disponible.") "Green"
        if ($state.apps.Count -eq 0) { & $log "   (winget n a rien retourne - cliquez Actualiser.)" "Gray" }
        $btnRef.Enabled = $true
    }.GetNewClosure()

    $btnRef.Add_Click({ & $loadList }.GetNewClosure())
    $btnAll.Add_Click({ for ($i=0; $i -lt $clb.Items.Count; $i++) { $clb.SetItemChecked($i, $true) } }.GetNewClosure())
    $btnNone.Add_Click({ for ($i=0; $i -lt $clb.Items.Count; $i++) { $clb.SetItemChecked($i, $false) } }.GetNewClosure())

    $btnUpd.Add_Click({
        $sel = @($clb.CheckedIndices)
        if ($sel.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show("Cochez les logiciels a mettre a jour."); return }
        $btnUpd.Enabled = $false
        & $log ("===== Mise a jour de " + $sel.Count + " logiciel(s) =====") "Cyan"
        foreach ($i in $sel) {
            $a = $state.apps[$i]
            if (-not $a.Avail) { & $log ($a.Name + " : deja a jour, ignore.") "Gray"; continue }
            & $log ("MAJ : " + $a.Name) "Cyan"
            JLog ("MAJ logiciel: " + $a.Name)
            & $runWg @("upgrade","--id",$a.Id,"--silent","--include-unknown","--accept-source-agreements","--accept-package-agreements","--disable-interactivity")
        }
        & $log "===== Mises a jour terminees =====" "Green"
        & $loadList
        $btnUpd.Enabled = $true
    }.GetNewClosure())

    $btnUni.Add_Click({
        $sel = @($clb.CheckedIndices)
        if ($sel.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show("Cochez les logiciels a desinstaller."); return }
        $r = [System.Windows.Forms.MessageBox]::Show(("Desinstaller " + $sel.Count + " logiciel(s) ?"), "Confirmation", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($r -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        $btnUni.Enabled = $false
        & $log ("===== Desinstallation de " + $sel.Count + " logiciel(s) =====") "Cyan"
        foreach ($i in $sel) {
            $a = $state.apps[$i]
            & $log ("Desinstallation : " + $a.Name) "Cyan"
            JLog ("Desinstalle (winget): " + $a.Name)
            & $runWg @("uninstall","--id",$a.Id,"--silent","--accept-source-agreements","--disable-interactivity")
        }
        & $log "===== Desinstallations terminees =====" "Green"
        & $loadList
        $btnUni.Enabled = $true
    }.GetNewClosure())

    $f.Add_Shown({ $f.Activate(); & $loadList }.GetNewClosure())
    [void]$f.ShowDialog()
}

###################################### Journal d'intervention persistant ######################################
function Get-JournalPath
{
    $dir = Join-Path $env:ProgramData "MultInstall"
    if (-not (Test-Path $dir)) { New-Item -Path $dir -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null }
    return (Join-Path $dir "journal.txt")
}

# Ajoute une ligne horodatee au journal (appelable depuis n'importe quel outil)
function Add-Journal
{
    param($Message)
    try { Add-Content -Path (Get-JournalPath) -Value ("[" + (Get-Date -Format "dd/MM HH:mm") + "] " + $Message) -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
}

# Fenetre journal ancree a droite, persistante (single-instance)
function JournalWindow
{
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $mtx = New-Object System.Threading.Mutex($false, "Global\MultInstallJournalWin")
    if (-not $mtx.WaitOne(0)) { return }
    try {
        $jp = Get-JournalPath
        $wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
        $w = 380
        $form = New-Object System.Windows.Forms.Form
        $form.Text = "Journal d'intervention"
        $form.FormBorderStyle = "FixedToolWindow"
        $form.StartPosition = "Manual"
        $form.Size = New-Object System.Drawing.Size($w, $wa.Height)
        $form.Location = New-Object System.Drawing.Point(($wa.Right - $w), $wa.Top)
        $form.TopMost = $true
        $form.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
        $form.ShowInTaskbar = $true

        $hdr = New-Object System.Windows.Forms.Panel; $hdr.Dock = "Top"; $hdr.Height = 44; $hdr.BackColor = [System.Drawing.Color]::FromArgb(2, 108, 79)
        $lbl = New-Object System.Windows.Forms.Label; $lbl.Text = "  Journal d'intervention"; $lbl.Dock = "Fill"; $lbl.ForeColor = "White"; $lbl.TextAlign = "MiddleLeft"; $lbl.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11); $hdr.Controls.Add($lbl)
        $form.Controls.Add($hdr)

        $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 132; $pBot.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59)
        $form.Controls.Add($pBot)
        $txtNote = New-Object System.Windows.Forms.TextBox; $txtNote.Location = New-Object System.Drawing.Point(8, 8); $txtNote.Size = New-Object System.Drawing.Size(($w - 100), 24); $txtNote.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $pBot.Controls.Add($txtNote)
        $btnAdd = New-Object System.Windows.Forms.Button; $btnAdd.Text = "Ajouter"; $btnAdd.Location = New-Object System.Drawing.Point(($w - 86), 7); $btnAdd.Size = New-Object System.Drawing.Size(74, 26)
        $btnAdd.FlatStyle = "Flat"; $btnAdd.FlatAppearance.BorderSize = 0; $btnAdd.BackColor = [System.Drawing.Color]::FromArgb(22, 163, 74); $btnAdd.ForeColor = "White"; $pBot.Controls.Add($btnAdd)
        $btnExport = New-Object System.Windows.Forms.Button; $btnExport.Text = "Exporter en PDF"; $btnExport.Location = New-Object System.Drawing.Point(8, 42); $btnExport.Size = New-Object System.Drawing.Size(($w - 16), 32)
        $btnExport.FlatStyle = "Flat"; $btnExport.FlatAppearance.BorderSize = 0; $btnExport.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235); $btnExport.ForeColor = "White"; $pBot.Controls.Add($btnExport)
        $btnReset = New-Object System.Windows.Forms.Button; $btnReset.Text = "Reinitialiser le journal"; $btnReset.Location = New-Object System.Drawing.Point(8, 80); $btnReset.Size = New-Object System.Drawing.Size(($w - 16), 34)
        $btnReset.FlatStyle = "Flat"; $btnReset.FlatAppearance.BorderSize = 0; $btnReset.BackColor = [System.Drawing.Color]::FromArgb(190, 18, 60); $btnReset.ForeColor = "White"; $pBot.Controls.Add($btnReset)

        $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Fill"; $rtb.ReadOnly = $true
        $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 9); $rtb.BorderStyle = "None"
        $form.Controls.Add($rtb)
        $hdr.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront()

        $lastSize = -1
        $load = {
            try {
                if (Test-Path $jp) {
                    $sz = (Get-Item $jp).Length
                    if ($sz -ne $lastSize) {
                        $script:lastSize = $sz
                        $rtb.Text = (Get-Content $jp -Raw -ErrorAction SilentlyContinue)
                        $rtb.SelectionStart = $rtb.TextLength; $rtb.ScrollToCaret()
                    }
                } elseif ($lastSize -ne 0) { $script:lastSize = 0; $rtb.Text = "(journal vide - les actions s'afficheront ici)" }
            } catch {}
        }.GetNewClosure()
        & $load

        $btnAdd.Add_Click({
            $n = $txtNote.Text.Trim()
            if ($n) { Add-Content -Path $jp -Value ("[" + (Get-Date -Format "dd/MM HH:mm") + "] (note) " + $n) -Encoding UTF8 -ErrorAction SilentlyContinue; $txtNote.Clear(); $script:lastSize = -1; & $load }
        }.GetNewClosure())
        $txtNote.Add_KeyDown({ if ($_.KeyCode -eq "Enter") { $btnAdd.PerformClick() } }.GetNewClosure())
        $btnExport.Add_Click({
            Add-Type -AssemblyName Microsoft.VisualBasic
            $client = [Microsoft.VisualBasic.Interaction]::InputBox("Nom du client :", "Export PDF du journal", "")
            if (-not $client) { $client = "Client" }
            $content = ""; if (Test-Path $jp) { $content = Get-Content $jp -Raw -ErrorAction SilentlyContinue }
            $rows = (($content -split "`r?`n") | Where-Object { $_.Trim() } | ForEach-Object { "<div class=l>" + ($_ -replace "&","&amp;" -replace "<","&lt;" -replace ">","&gt;") + "</div>" }) -join ""
            $h = "<html><head><meta charset=utf-8><style>body{font-family:Segoe UI,Arial;color:#0f172a;padding:30px} h1{color:#1e293b;margin:0 0 4px} .meta{color:#475569;margin:2px 0} .box{margin-top:18px;border-top:2px solid #e2e8f0;padding-top:10px} .l{font-family:Consolas,monospace;font-size:12px;padding:3px 0;border-bottom:1px solid #f1f5f9}</style></head><body>"
            $h += "<h1>Journal d intervention</h1>"
            $h += "<div class=meta><b>Client :</b> " + $client + "</div>"
            $h += "<div class=meta><b>Machine :</b> " + $env:COMPUTERNAME + "</div>"
            $h += "<div class=meta><b>Date :</b> " + (Get-Date -Format "dd/MM/yyyy HH:mm") + "</div>"
            $h += "<div class=box>" + $rows + "</div></body></html>"
            $base = "Journal_" + ($client -replace "[^a-zA-Z0-9]","_") + "_" + $env:COMPUTERNAME + "_" + (Get-Date -Format "yyyyMMdd_HHmm")
            $htmlF = Join-Path $env:TEMP ($base + ".html")
            $pdfF = Join-Path ([Environment]::GetFolderPath("Desktop")) ($base + ".pdf")
            $h | Out-File $htmlF -Encoding UTF8
            $edge = $null
            foreach ($pp in @("$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe", "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe")) { if (Test-Path $pp) { $edge = $pp; break } }
            if ($edge) {
                try { & $edge "--headless=new" "--disable-gpu" ("--print-to-pdf=" + $pdfF) $htmlF 2>$null | Out-Null } catch {}
                Start-Sleep -Milliseconds 1200
                if (Test-Path $pdfF) { Start-Process $pdfF; Add-Content -Path $jp -Value ("[" + (Get-Date -Format "dd/MM HH:mm") + "] (export) PDF genere : " + $pdfF) -Encoding UTF8 -ErrorAction SilentlyContinue }
                else { Start-Process $htmlF; [System.Windows.Forms.MessageBox]::Show("PDF non genere - le HTML est ouvert, utilisez Imprimer > Enregistrer en PDF.") }
            } else { Start-Process $htmlF; [System.Windows.Forms.MessageBox]::Show("Edge introuvable - le HTML est ouvert, utilisez Imprimer > Enregistrer en PDF.") }
        }.GetNewClosure())

        $btnReset.Add_Click({
            $r = [System.Windows.Forms.MessageBox]::Show("Effacer DEFINITIVEMENT tout le journal d'intervention ?`n(A faire quand l'intervention est terminee.)", "Reinitialiser", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
            if ($r -eq [System.Windows.Forms.DialogResult]::Yes) { try { Remove-Item $jp -Force -ErrorAction SilentlyContinue } catch {}; $script:lastSize = -1; & $load }
        }.GetNewClosure())

        $sig = New-Object System.Threading.EventWaitHandle($false, [System.Threading.EventResetMode]::ManualReset, "Global\MultInstallJournalClose")
        $timer = New-Object System.Windows.Forms.Timer
        $timer.Interval = 800
        $timer.Add_Tick({ try { if ($sig.WaitOne(0)) { $timer.Stop(); if (-not $form.IsDisposed) { $form.Close() }; return }; if (-not $form.IsDisposed) { & $load } } catch {} }.GetNewClosure())
        $timer.Start()
        $form.Add_FormClosing({ try { $timer.Stop(); $timer.Dispose() } catch {} }.GetNewClosure())

        [void]$form.ShowDialog()
    } finally { try { $mtx.ReleaseMutex() } catch {} }
}

# Lance la fenetre journal dans un runspace independant (ancree a droite, non bloquante)
function Show-JournalWindow
{
    $src = ${function:JournalWindow}.ToString()
    $gp = ${function:Get-JournalPath}.ToString()
    $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
    $rs.ApartmentState = "STA"; $rs.ThreadOptions = "ReuseThread"; $rs.Open()
    $ps = [System.Management.Automation.PowerShell]::Create(); $ps.Runspace = $rs
    $boot = 'param($src,$gp) Add-Type -AssemblyName System.Windows.Forms,System.Drawing; try { [System.Windows.Forms.Application]::SetUnhandledExceptionMode([System.Windows.Forms.UnhandledExceptionMode]::CatchException); [System.Windows.Forms.Application]::add_ThreadException({}) } catch {}; Invoke-Expression ("function Get-JournalPath {" + $gp + "}"); & ([ScriptBlock]::Create($src))'
    $null = $ps.AddScript($boot).AddParameter('src', $src).AddParameter('gp', $gp).BeginInvoke()
}

# ============ HUB ============
function MaintenanceHub
{
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $f = New-Object System.Windows.Forms.Form
    $f.Text = "Maintenance & Securite"; $f.Size = New-Object System.Drawing.Size(580, 590)
    $f.StartPosition = "CenterScreen"; $f.FormBorderStyle = "FixedDialog"; $f.MaximizeBox = $false; $f.MinimizeBox = $false
    $f.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $hdr = New-Object System.Windows.Forms.Panel; $hdr.Dock = "Top"; $hdr.Height = 60; $hdr.BackColor = [System.Drawing.Color]::FromArgb(2, 108, 79)
    $lb = New-Object System.Windows.Forms.Label; $lb.Text = "  Maintenance & Securite"; $lb.Dock = "Fill"; $lb.ForeColor = "White"; $lb.TextAlign = "MiddleLeft"; $lb.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 15); $hdr.Controls.Add($lb); $f.Controls.Add($hdr)

    $defs = @(
        @{ T="Point de restauration + sauvegarde registre"; C=[System.Drawing.Color]::FromArgb(22,163,74);  A={ RestorePointTool } },
        @{ T="Rapport de sante PC (HTML)";                   C=[System.Drawing.Color]::FromArgb(37,99,235);  A={ HealthReportTool } },
        @{ T="Finitions post-installation";                  C=[System.Drawing.Color]::FromArgb(79,70,229);  A={ PostInstallTool } },
        @{ T="Reparation Windows (SFC/DISM/...)";            C=[System.Drawing.Color]::FromArgb(190,18,60);  A={ RepairWindowsTool } },
        @{ T="Diagnostic materiel";                          C=[System.Drawing.Color]::FromArgb(8,145,178);  A={ HardwareDiagTool } },
        @{ T="Nettoyage disque avance";                      C=[System.Drawing.Color]::FromArgb(202,138,4);  A={ DiskCleanupTool } },
        @{ T="Fiche d intervention client (PDF/HTML)";       C=[System.Drawing.Color]::FromArgb(120,53,15);  A={ InterventionSheetTool } },
        @{ T="Securisation express";                         C=[System.Drawing.Color]::FromArgb(159,18,57);  A={ SecurityTool } },
        @{ T="Desinstalleur universel";                      C=[System.Drawing.Color]::FromArgb(124,45,18);  A={ UninstallerTool } },
        @{ T="Test qualite connexion Internet";              C=[System.Drawing.Color]::FromArgb(13,148,136); A={ NetQualityTool } },
        @{ T="Points de restauration";                       C=[System.Drawing.Color]::FromArgb(101,163,13); A={ RestoreMgrTool } },
        @{ T="Compte admin local + autologon";               C=[System.Drawing.Color]::FromArgb(2,132,199);  A={ LocalAdminTool } },
        @{ T="RDP : restrictions + raccourci";                C=[System.Drawing.Color]::FromArgb(126,34,206); A={ RdpTool } },
        @{ T="Nettoyage Bloatware (OEM + Windows)";            C=[System.Drawing.Color]::FromArgb(190,18,60);  A={ DebloatTool } },
        @{ T="Windows Update (silencieux)";                    C=[System.Drawing.Color]::FromArgb(2,132,199);  A={ WindowsUpdateTool } },
        @{ T="MAJ logiciels (winget)";                         C=[System.Drawing.Color]::FromArgb(13,148,136); A={ WingetUpdateTool } }
    )
    $i2 = 0
    foreach ($d in $defs) {
        $col = $i2 % 2; $row = [math]::Floor($i2 / 2)
        $b = New-Object System.Windows.Forms.Button
        $b.Text = $d.T; $b.Size = New-Object System.Drawing.Size(266, 42); $b.Location = New-Object System.Drawing.Point((20 + $col * 276), (70 + $row * 50))
        $b.FlatStyle = "Flat"; $b.FlatAppearance.BorderSize = 0; $b.BackColor = $d.C; $b.ForeColor = "White"
        $b.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9); $b.TextAlign = "MiddleLeft"; $b.Cursor = "Hand"
        $act = $d.A.GetNewClosure(); $tname = $d.T
        $b.Add_Click({ try { Add-Journal ("Maintenance: " + $tname); & $act } catch { [System.Windows.Forms.MessageBox]::Show("Erreur : " + $_.Exception.Message) } }.GetNewClosure())
        $f.Controls.Add($b); $i2++
    }
    $rows = [math]::Ceiling($defs.Count / 2)
    $bq = New-Object System.Windows.Forms.Button; $bq.Text = "Fermer"; $bq.Size = New-Object System.Drawing.Size(542, 32); $bq.Location = New-Object System.Drawing.Point(20, (70 + $rows * 50 + 4))
    $bq.FlatStyle = "Flat"; $bq.FlatAppearance.BorderSize = 1; $bq.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $bq.ForeColor = "White"; $bq.Add_Click({ $f.Close() }); $f.Controls.Add($bq)

    $f.Add_Shown({ $f.Activate() })
    [void]$f.ShowDialog()
}

###################################### Nettoyage Bloatware (OEM + Windows) ######################################
function DebloatTool
{
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    function global:JLog($m){ try { $jd=Join-Path $env:ProgramData "MultInstall"; if(-not(Test-Path $jd)){New-Item $jd -ItemType Directory -Force -ErrorAction SilentlyContinue|Out-Null}; Add-Content -Path (Join-Path $jd "journal.txt") -Value ("["+(Get-Date -Format "dd/MM HH:mm")+"] "+$m) -Encoding UTF8 -ErrorAction SilentlyContinue } catch {} }
    Import-Module Appx -ErrorAction SilentlyContinue
    Import-Module ScheduledTasks -ErrorAction SilentlyContinue

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Nettoyage - Bloatware constructeur & Windows"
    $form.Size = New-Object System.Drawing.Size(960, 700)
    $form.StartPosition = "CenterScreen"
    $form.BackColor = [System.Drawing.Color]::FromArgb(243, 244, 246)
    $form.MinimumSize = New-Object System.Drawing.Size(840, 560)

    $tlp = New-Object System.Windows.Forms.TableLayoutPanel
    $tlp.Dock = "Fill"; $tlp.RowCount = 2; $tlp.ColumnCount = 1
    $tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    $tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 50)))
    $tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    $form.Controls.Add($tlp)

    $hdr = New-Object System.Windows.Forms.Panel
    $hdr.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $hdr.Dock = "Fill"
    $lblH = New-Object System.Windows.Forms.Label
    $lblH.Text = "  Nettoyage du superflu - constructeur (OEM) et Windows"
    $lblH.ForeColor = [System.Drawing.Color]::White
    $lblH.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 13)
    $lblH.Dock = "Fill"; $lblH.TextAlign = "MiddleLeft"
    $hdr.Controls.Add($lblH); $tlp.Controls.Add($hdr, 0, 0)

    $split = New-Object System.Windows.Forms.SplitContainer
    $split.Dock = "Fill"; $split.SplitterWidth = 5
    $tlp.Controls.Add($split, 0, 1)
    $split.SplitterDistance = 540

    $pL = $split.Panel1; $pL.BackColor = [System.Drawing.Color]::White
    $pL.Padding = New-Object System.Windows.Forms.Padding(8)
    $tv = New-Object System.Windows.Forms.TreeView
    $tv.CheckBoxes = $true; $tv.Dock = "Fill"
    $tv.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $tv.BorderStyle = "None"
    $pL.Controls.Add($tv)
    $tv.Add_AfterCheck({ param($s, $e) if ($e.Action -eq [System.Windows.Forms.TreeViewAction]::Unknown) { return }; foreach ($c in $e.Node.Nodes) { $c.Checked = $e.Node.Checked } })

    $pR = $split.Panel2; $pR.BackColor = [System.Drawing.Color]::FromArgb(243, 244, 246)
    $pR.Padding = New-Object System.Windows.Forms.Padding(6)
    $tlpR = New-Object System.Windows.Forms.TableLayoutPanel
    $tlpR.Dock = "Fill"; $tlpR.RowCount = 2; $tlpR.ColumnCount = 1
    $tlpR.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    $tlpR.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 150)))
    $tlpR.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    $pR.Controls.Add($tlpR)
    $pAct = New-Object System.Windows.Forms.Panel; $pAct.Dock = "Fill"; $tlpR.Controls.Add($pAct, 0, 0)

    $mkBtn = {
        param($text, $x, $y, $w, $h, $color)
        $b = New-Object System.Windows.Forms.Button
        $b.Text = $text; $b.Location = New-Object System.Drawing.Point($x, $y)
        $b.Size = New-Object System.Drawing.Size($w, $h)
        $b.FlatStyle = "Flat"; $b.FlatAppearance.BorderSize = 0
        $b.BackColor = $color; $b.ForeColor = [System.Drawing.Color]::White
        $b.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)
        $b.Cursor = "Hand"; $pAct.Controls.Add($b); return $b
    }
    $btnScan = & $mkBtn "Scanner / Actualiser" 0 0 200 38 ([System.Drawing.Color]::FromArgb(37, 99, 235))
    $btnAll  = & $mkBtn "Tout cocher (sur)"    208 0 170 38 ([System.Drawing.Color]::FromArgb(71, 85, 105))
    $btnNone = & $mkBtn "Tout decocher"        382 0 130 38 ([System.Drawing.Color]::FromArgb(107, 114, 128))
    $btnDel  = & $mkBtn "Supprimer la selection" 0 46 250 42 ([System.Drawing.Color]::FromArgb(190, 18, 60))
    $btnClose= & $mkBtn "Fermer"               258 46 90 42 ([System.Drawing.Color]::FromArgb(55, 65, 81))

    $pbar = New-Object System.Windows.Forms.ProgressBar
    $pbar.Location = New-Object System.Drawing.Point(0, 96); $pbar.Size = New-Object System.Drawing.Size(512, 12)
    $pbar.Style = "Continuous"; $pAct.Controls.Add($pbar)

    $rtb = New-Object System.Windows.Forms.RichTextBox
    $rtb.ReadOnly = $true; $rtb.Dock = "Fill"
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219)
    $rtb.Font = New-Object System.Drawing.Font("Consolas", 8); $rtb.BorderStyle = "None"
    $tlpR.Controls.Add($rtb, 0, 1)

    $log = {
        param($msg, $clr = "White")
        $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionLength = 0
        $rtb.SelectionColor = switch ($clr) {
            "Green"  { [System.Drawing.Color]::FromArgb(74, 222, 128) }
            "Red"    { [System.Drawing.Color]::FromArgb(248, 113, 113) }
            "Yellow" { [System.Drawing.Color]::FromArgb(251, 191, 36) }
            "Cyan"   { [System.Drawing.Color]::FromArgb(103, 232, 249) }
            "Gray"   { [System.Drawing.Color]::FromArgb(107, 114, 128) }
            default  { [System.Drawing.Color]::FromArgb(209, 213, 219) }
        }
        $rtb.AppendText("$msg`n"); $rtb.ScrollToCaret()
        [System.Windows.Forms.Application]::DoEvents()
    }.GetNewClosure()

    # ---- Listes de reference ----
    $appxBloat = @(
        "Microsoft.BingNews","Microsoft.BingWeather","Microsoft.BingFinance","Microsoft.BingSports","Microsoft.BingSearch",
        "Microsoft.GamingApp","Microsoft.XboxApp","Microsoft.XboxGameOverlay","Microsoft.XboxGamingOverlay","Microsoft.XboxIdentityProvider","Microsoft.XboxSpeechToTextOverlay","Microsoft.Xbox.TCUI",
        "Microsoft.MicrosoftSolitaireCollection","Microsoft.ZuneMusic","Microsoft.ZuneVideo","Microsoft.WindowsMaps",
        "Microsoft.People","Microsoft.windowscommunicationsapps","Microsoft.YourPhone","Microsoft.GetHelp","Microsoft.Getstarted","Microsoft.WindowsFeedbackHub",
        "Microsoft.Microsoft3DViewer","Microsoft.MixedReality.Portal","Microsoft.MicrosoftOfficeHub","Microsoft.OneConnect","Microsoft.Print3D","Microsoft.SkypeApp",
        "Microsoft.Todos","Microsoft.PowerAutomateDesktop","Microsoft.Clipchamp","Clipchamp.Clipchamp","MicrosoftTeams","MicrosoftCorporationII.MicrosoftFamily","Microsoft.549981C3F5F10"
    )
    $oemPatterns = @(
        "*McAfee*","*Norton*","*Avast*","*AVG*","*WildTangent*","*Booking.com*","*ExpressVPN*","*Wondershare*","*CyberLink*","*WPS Office*","*Killer*Control*","*Cricut*","*HiSuite*","*DriversCloud*",
        "*HP Support*","*HP Documentation*","*HP JumpStart*","*HP Sure*","*HP Audio*","*HP System Event*","*myHP*","*HP Connection*","*HP Smart*",
        "*Dell Customer*","*Dell Digital*","*SupportAssist*","*Dell Update*","*Dell Optimizer*","*Dell Mobile*","*Dell Power*",
        "*Lenovo Vantage*","*Lenovo Now*","*Lenovo Welcome*","*Lenovo Utility*","*Lenovo Smart*","*Lenovo Voice*",
        "*ASUS GiftBox*","*ASUS Product*","*MyASUS*","*Armoury Crate*","*GlideX*",
        "*Acer Care*","*Acer Product*","*Acer Jumpstart*","*Acer Collection*","*Acer Quick*"
    )
    $teleTasks = @(
        @{ Path="\Microsoft\Windows\Application Experience\"; Name="Microsoft Compatibility Appraiser" },
        @{ Path="\Microsoft\Windows\Application Experience\"; Name="ProgramDataUpdater" },
        @{ Path="\Microsoft\Windows\Customer Experience Improvement Program\"; Name="Consolidator" },
        @{ Path="\Microsoft\Windows\Customer Experience Improvement Program\"; Name="UsbCeip" },
        @{ Path="\Microsoft\Windows\Autochk\"; Name="Proxy" },
        @{ Path="\Microsoft\Windows\Feedback\Siuf\"; Name="DmClient" },
        @{ Path="\Microsoft\Windows\Feedback\Siuf\"; Name="DmClientOnScenarioDownload" },
        @{ Path="\Microsoft\Windows\Windows Error Reporting\"; Name="QueueReporting" }
    )
    $regToggles = @(
        @{ Label="Suggestions / pubs menu Demarrer"; Path="HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name="SilentInstalledAppsEnabled"; Value=0 },
        @{ Label="Contenu suggere (338388)"; Path="HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name="SubscribedContent-338388Enabled"; Value=0 },
        @{ Label="Astuces et conseils Windows"; Path="HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name="SubscribedContent-338389Enabled"; Value=0 },
        @{ Label="Suggestions ecran de verrouillage"; Path="HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name="RotatingLockScreenOverlayEnabled"; Value=0 },
        @{ Label="Apps suggerees au demarrage"; Path="HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name="PreInstalledAppsEnabled"; Value=0 }
    )
    $promoNames = @("*Booking*","*Amazon*","*ExpressVPN*","*McAfee*","*Norton*","*WPS*","*Spotify*","*LinkedIn*","*TikTok*","*Instagram*","*Facebook*","*Get Office*","*Dropbox*","*Disney*","*Prime Video*","*Adobe*Express*")

    $addCat = { param($title) $c = New-Object System.Windows.Forms.TreeNode($title); $c.NodeFont = New-Object System.Drawing.Font("Segoe UI Semibold", 9); return $c }
    $addItem = { param($cat, $text, $tag) $n = New-Object System.Windows.Forms.TreeNode($text); $n.Tag = $tag; $cat.Nodes.Add($n) | Out-Null }

    $scan = {
        $tv.Nodes.Clear()
        & $log "Analyse en cours..." "Cyan"

        # 1) OEM
        $catOem = & $addCat "Bloatware constructeur (OEM)"
        $keys = @("HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*","HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*","HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*")
        $seen = @{}
        foreach ($k in $keys) {
            Get-ItemProperty $k -ErrorAction SilentlyContinue | ForEach-Object {
                $dn = $_.DisplayName
                if (-not $dn) { return }
                foreach ($pat in $oemPatterns) {
                    if ($dn -like $pat) {
                        if (-not $seen[$dn]) {
                            $seen[$dn] = $true
                            & $addItem $catOem $dn @{ Type="oem"; Name=$dn; Quiet=$_.QuietUninstallString; Uninst=$_.UninstallString }
                        }
                        break
                    }
                }
            }
        }
        if ($catOem.Nodes.Count -gt 0) { $tv.Nodes.Add($catOem) | Out-Null; $catOem.Expand() }

        # 2) AppX Windows
        $catApx = & $addCat "Apps Windows preinstallees"
        foreach ($id in $appxBloat) {
            $pkg = Get-AppxPackage -Name $id -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($pkg) { & $addItem $catApx $pkg.Name @{ Type="appx"; Name=$pkg.Name } }
        }
        if ($catApx.Nodes.Count -gt 0) { $tv.Nodes.Add($catApx) | Out-Null; $catApx.Expand() }

        # 3) Taches planifiees + telemetrie + toggles pubs
        $catTask = & $addCat "Taches planifiees / telemetrie / pubs"
        foreach ($t in $teleTasks) {
            $st = Get-ScheduledTask -TaskPath $t.Path -TaskName $t.Name -ErrorAction SilentlyContinue
            if ($st -and $st.State -ne "Disabled") { & $addItem $catTask ("Tache: " + $t.Name) @{ Type="task"; Path=$t.Path; Name=$t.Name } }
        }
        foreach ($r in $regToggles) {
            & $addItem $catTask $r.Label @{ Type="reg"; Path=$r.Path; Name=$r.Name; Value=$r.Value }
        }
        if ($catTask.Nodes.Count -gt 0) { $tv.Nodes.Add($catTask) | Out-Null; $catTask.Expand() }

        # 4) Raccourcis promo
        $catSc = & $addCat "Raccourcis promo / sponsorises"
        $locs = @("$env:PUBLIC\Desktop","$env:USERPROFILE\Desktop","$env:ProgramData\Microsoft\Windows\Start Menu\Programs","$env:APPDATA\Microsoft\Windows\Start Menu\Programs")
        foreach ($loc in $locs) {
            if (-not (Test-Path $loc)) { continue }
            Get-ChildItem $loc -Include *.lnk,*.url -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
                $fn = $_.Name
                foreach ($pn in $promoNames) {
                    if ($fn -like $pn) { & $addItem $catSc $fn @{ Type="shortcut"; Path=$_.FullName }; break }
                }
            }
        }
        if ($catSc.Nodes.Count -gt 0) { $tv.Nodes.Add($catSc) | Out-Null; $catSc.Expand() }

        $total = 0; foreach ($c in $tv.Nodes) { $total += $c.Nodes.Count }
        & $log "Analyse terminee : $total element(s) detecte(s)." "Green"
        if ($total -eq 0) { & $log "Rien a nettoyer (PC propre)." "Gray" }
    }.GetNewClosure()

    $doRemove = {
        $targets = @()
        foreach ($cat in $tv.Nodes) { foreach ($n in $cat.Nodes) { if ($n.Checked) { $targets += $n } } }
        if ($targets.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show("Aucun element coche.", "Rien a faire"); return }
        $r = [System.Windows.Forms.MessageBox]::Show(("Supprimer / desactiver " + $targets.Count + " element(s) ?`n`nUn point de restauration prealable est conseille."), "Confirmation", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($r -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        $btnDel.Enabled = $false; $btnScan.Enabled = $false
        $pbar.Style = "Marquee"
        & $log "========== NETTOYAGE ==========" "Yellow"
        foreach ($n in $targets) {
            $t = $n.Tag
            try {
                switch ($t.Type) {
                    "oem" {
                        $cmd = if ($t.Quiet) { $t.Quiet } else { $t.Uninst }
                        if (-not $cmd) { throw "pas de commande de desinstallation" }
                        if ($cmd -match "msiexec") {
                            $cmd = $cmd -replace "/I", "/X"
                            if ($cmd -notmatch "/quiet") { $cmd = $cmd + " /quiet /norestart" }
                            $p = Start-Process "cmd.exe" -ArgumentList "/c $cmd" -WindowStyle Hidden -PassThru
                        } elseif ($t.Quiet) {
                            $p = Start-Process "cmd.exe" -ArgumentList "/c $cmd" -WindowStyle Hidden -PassThru
                        } else {
                            $p = Start-Process "cmd.exe" -ArgumentList "/c $cmd" -PassThru
                        }
                        while (-not $p.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 200 }
                        & $log ("   Desinstalle: " + $n.Text) "Green"; JLog ("Debloat desinstalle: " + $n.Text)
                    }
                    "appx" {
                        Get-AppxPackage -Name $t.Name -AllUsers -ErrorAction SilentlyContinue | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue
                        Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -eq $t.Name } | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue | Out-Null
                        & $log ("   App supprimee: " + $n.Text) "Green"; JLog ("Debloat app supprimee: " + $n.Text)
                    }
                    "task" {
                        Disable-ScheduledTask -TaskPath $t.Path -TaskName $t.Name -ErrorAction Stop | Out-Null
                        & $log ("   Tache desactivee: " + $n.Text) "Green"
                    }
                    "reg" {
                        if (-not (Test-Path $t.Path)) { New-Item -Path $t.Path -Force | Out-Null }
                        Set-ItemProperty -Path $t.Path -Name $t.Name -Value $t.Value -Type DWord -ErrorAction Stop
                        & $log ("   Option desactivee: " + $n.Text) "Green"
                    }
                    "shortcut" {
                        Remove-Item -Path $t.Path -Force -ErrorAction Stop
                        & $log ("   Raccourci supprime: " + $n.Text) "Green"
                    }
                }
            } catch {
                & $log ("   Echec: " + $n.Text + " - " + $_.Exception.Message) "Yellow"
            }
            [System.Windows.Forms.Application]::DoEvents()
        }
        $pbar.Style = "Continuous"
        & $log "========== TERMINE ==========" "Green"
        $btnDel.Enabled = $true; $btnScan.Enabled = $true
        & $scan
    }.GetNewClosure()

    $btnScan.Add_Click({ & $scan }.GetNewClosure())
    $btnAll.Add_Click({ foreach ($c in $tv.Nodes) { $c.Checked = $true; foreach ($n in $c.Nodes) { $n.Checked = $true } } }.GetNewClosure())
    $btnNone.Add_Click({ foreach ($c in $tv.Nodes) { $c.Checked = $false; foreach ($n in $c.Nodes) { $n.Checked = $false } } }.GetNewClosure())
    $btnDel.Add_Click({ & $doRemove }.GetNewClosure())
    $btnClose.Add_Click({ $form.Close() })

    $form.Add_Shown({ $form.Activate(); & $scan }.GetNewClosure())
    [void]$form.ShowDialog()
}

#################################################### Migration Pc ################################################################################

function migrationpc
{
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing

	# Dimensions
	$sw = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Width
	$sh = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Height
	$fw = [int]([Math]::Min(1100, $sw * 0.85))
	$fh = [int]([Math]::Min(750, $sh * 0.90))

	# Polices / Couleurs
	$fs        = [Math]::Max(8, [Math]::Min(10, [int]($sh / 135)))
	$fontUI    = New-Object System.Drawing.Font("Segoe UI", $fs)
	$fontBold  = New-Object System.Drawing.Font("Segoe UI Semibold", $fs)
	$fontLarge = New-Object System.Drawing.Font("Segoe UI", ($fs + 4), [System.Drawing.FontStyle]::Bold)
	$fontMono  = New-Object System.Drawing.Font("Consolas", ($fs - 1))
	$clrTop    = [System.Drawing.Color]::FromArgb(15, 23, 42)
	$clrBg     = [System.Drawing.Color]::FromArgb(243, 244, 246)
	$clrSave   = [System.Drawing.Color]::FromArgb(37, 99, 235)
	$clrRest   = [System.Drawing.Color]::FromArgb(22, 163, 74)
	$clrClose  = [System.Drawing.Color]::FromArgb(55, 65, 81)

	# Formulaire
	$form = New-Object System.Windows.Forms.Form
	$form.Text          = "Migration PC - Sauvegarde & Restauration"
	$form.Size          = New-Object System.Drawing.Size($fw, $fh)
	$form.BackColor     = $clrBg
	$form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
	$form.MinimumSize   = New-Object System.Drawing.Size(800, 540)
	try { $form.GetType().GetProperty('DoubleBuffered',[System.Reflection.BindingFlags]'Instance,NonPublic').SetValue($form,$true,$null) } catch {}

	# TableLayoutPanel principal : header + contenu
	$tlp = New-Object System.Windows.Forms.TableLayoutPanel
	$tlp.Dock = [System.Windows.Forms.DockStyle]::Fill
	$tlp.RowCount = 2; $tlp.ColumnCount = 1
	$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
	$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52)))
	$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
	$form.Controls.Add($tlp)

	# Header
	$hdr = New-Object System.Windows.Forms.Panel
	$hdr.BackColor = $clrTop; $hdr.Dock = [System.Windows.Forms.DockStyle]::Fill
	$lblH = New-Object System.Windows.Forms.Label
	$lblH.Text = "  Migration PC - Sauvegarde & Restauration de poste (style Fab's AutoBackup+)"
	$lblH.ForeColor = [System.Drawing.Color]::White; $lblH.Font = $fontLarge
	$lblH.Dock = [System.Windows.Forms.DockStyle]::Fill
	$lblH.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
	$hdr.Controls.Add($lblH)
	$tlp.Controls.Add($hdr, 0, 0)

	# SplitContainer : gauche = selection, droite = actions + log
	$split = New-Object System.Windows.Forms.SplitContainer
	$split.Dock = [System.Windows.Forms.DockStyle]::Fill
	$split.SplitterWidth = 5
	$split.Panel1MinSize = 260
	$tlp.Controls.Add($split, 0, 1)

	# ═══════════════ PANNEAU GAUCHE : SELECTION ═══════════════
	$pL = $split.Panel1; $pL.BackColor = [System.Drawing.Color]::White
	$pL.Padding = New-Object System.Windows.Forms.Padding(8, 8, 4, 8)

	$lblSel = New-Object System.Windows.Forms.Label
	$lblSel.Text = "Elements a migrer :"
	$lblSel.Font = $fontBold; $lblSel.Height = 22; $lblSel.Dock = [System.Windows.Forms.DockStyle]::Top
	$lblSel.ForeColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
	$pL.Controls.Add($lblSel)

	$tv = New-Object System.Windows.Forms.TreeView
	$tv.CheckBoxes = $true; $tv.Font = $fontUI
	$tv.BackColor = [System.Drawing.Color]::White
	$tv.BorderStyle = [System.Windows.Forms.BorderStyle]::None
	$tv.Dock = [System.Windows.Forms.DockStyle]::Fill
	$pL.Controls.Add($tv)

	$categories = [ordered]@{
		"Donnees personnelles" = [ordered]@{
			"Documents"        = @{ Checked=$true;  Key="doc" }
			"Bureau"           = @{ Checked=$true;  Key="desk" }
			"Telechargements"  = @{ Checked=$true;  Key="dl" }
			"Images"           = @{ Checked=$true;  Key="img" }
			"Musique"          = @{ Checked=$false; Key="music" }
			"Videos"           = @{ Checked=$false; Key="video" }
			"Favoris IE/Edge"  = @{ Checked=$true;  Key="fav" }
		}
		"Navigateurs" = [ordered]@{
			"Chrome (signets+historique+exts)" = @{ Checked=$true; Key="chrome" }
			"Firefox (profil complet)"         = @{ Checked=$true; Key="firefox" }
			"Brave"                            = @{ Checked=$true; Key="brave" }
			"Edge (signets+historique+exts)"   = @{ Checked=$true; Key="edge" }
		}
		"Messagerie" = [ordered]@{
			"Outlook Signatures"    = @{ Checked=$true;  Key="outlooksig" }
			"Outlook PST (mails)"   = @{ Checked=$false; Key="outlookpst" }
			"Thunderbird (complet)" = @{ Checked=$true;  Key="thunderbird" }
		}
		"Systeme & Reseau" = [ordered]@{
			"Profils WiFi"               = @{ Checked=$true; Key="wifi" }
			"Imprimantes (liste+config)" = @{ Checked=$true; Key="printers" }
			"Lecteurs reseau mappes"     = @{ Checked=$true; Key="drives" }
			"Fichier hosts"              = @{ Checked=$true; Key="hosts" }
			"Credentials Windows"        = @{ Checked=$true; Key="creds" }
		}
		"Parametres Windows" = [ordered]@{
			"Theme + fond d ecran"         = @{ Checked=$true;  Key="theme" }
			"Parametres regional+langue"   = @{ Checked=$true;  Key="locale" }
			"Variables d environnement"    = @{ Checked=$true;  Key="envvars" }
			"Menu Demarrer + barre taches" = @{ Checked=$false; Key="startmenu" }
			"Associations de fichiers"     = @{ Checked=$false; Key="fileassoc" }
		}
		"Applications" = [ordered]@{
			"Liste Winget (reinstall auto)"  = @{ Checked=$true;  Key="winget" }
			"Parametres AppData Roaming"     = @{ Checked=$false; Key="approaming" }
		}
		"Developpement" = [ordered]@{
			"Cles SSH (~/.ssh)"              = @{ Checked=$true; Key="ssh" }
			"Profil PowerShell"              = @{ Checked=$true; Key="pshell" }
			"Configuration Git (.gitconfig)" = @{ Checked=$true; Key="git" }
		}
	}

	$nodeMap = @{}
	foreach ($catName in $categories.Keys)
	{
		$catNode = New-Object System.Windows.Forms.TreeNode($catName)
		$catNode.Checked = $true
		foreach ($itemName in $categories[$catName].Keys)
		{
			$info  = $categories[$catName][$itemName]
			$child = New-Object System.Windows.Forms.TreeNode($itemName)
			$child.Checked = $info.Checked
			$child.Tag     = $info.Key
			$catNode.Nodes.Add($child) | Out-Null
			$nodeMap[$info.Key] = $child
		}
		$tv.Nodes.Add($catNode) | Out-Null
		$catNode.Expand()
	}

	$tv.Add_AfterCheck({
		param($s, $e)
		if ($e.Action -eq [System.Windows.Forms.TreeViewAction]::Unknown) { return }
		foreach ($child in $e.Node.Nodes) { $child.Checked = $e.Node.Checked }
	})

	# ═══════════════ PANNEAU DROIT : ACTIONS + LOG ═══════════════
	$pR = $split.Panel2; $pR.BackColor = $clrBg
	$pR.Padding = New-Object System.Windows.Forms.Padding(4, 4, 4, 4)

	# TableLayoutPanel droit : zone actions (haut fixe) + log (fill)
	$tlpR = New-Object System.Windows.Forms.TableLayoutPanel
	$tlpR.Dock = [System.Windows.Forms.DockStyle]::Fill
	$tlpR.RowCount = 2; $tlpR.ColumnCount = 1
	$tlpR.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
	$tlpR.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 156)))
	$tlpR.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
	$pR.Controls.Add($tlpR)

	# Zone actions (positions absolues, resize géré par SizeChanged)
	$pAct = New-Object System.Windows.Forms.Panel
	$pAct.Dock = [System.Windows.Forms.DockStyle]::Fill
	$pAct.BackColor = $clrBg
	$tlpR.Controls.Add($pAct, 0, 0)

	$lblDest = New-Object System.Windows.Forms.Label
	$lblDest.Text = "Dossier de sauvegarde (USB, reseau...) :"
	$lblDest.Font = $fontBold; $lblDest.Height = 18
	$lblDest.Location = New-Object System.Drawing.Point(0, 0)
	$lblDest.Width = 500
	$pAct.Controls.Add($lblDest)

	$txtDest = New-Object System.Windows.Forms.TextBox
	$txtDest.Font = $fontUI; $txtDest.Height = 24
	$txtDest.Location = New-Object System.Drawing.Point(0, 20)
	$txtDest.Width = 400
	$pAct.Controls.Add($txtDest)

	$btnBrowse = New-Object System.Windows.Forms.Button
	$btnBrowse.Text = "..."; $btnBrowse.Font = $fontBold
	$btnBrowse.Size = New-Object System.Drawing.Size(36, 24)
	$btnBrowse.Location = New-Object System.Drawing.Point(404, 20)
	$btnBrowse.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
	$pAct.Controls.Add($btnBrowse)

	$btnSave = New-Object System.Windows.Forms.Button
	$btnSave.Text = "SAUVEGARDER (PC source)"
	$btnSave.Size = New-Object System.Drawing.Size(240, 44)
	$btnSave.Location = New-Object System.Drawing.Point(0, 54)
	$btnSave.Font = $fontBold
	$btnSave.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
	$btnSave.FlatAppearance.BorderSize = 0
	$btnSave.BackColor = $clrSave
	$btnSave.ForeColor = [System.Drawing.Color]::White
	$btnSave.Cursor = [System.Windows.Forms.Cursors]::Hand
	$pAct.Controls.Add($btnSave)

	$btnRestore = New-Object System.Windows.Forms.Button
	$btnRestore.Text = "RESTAURER (PC cible)"
	$btnRestore.Size = New-Object System.Drawing.Size(240, 44)
	$btnRestore.Location = New-Object System.Drawing.Point(248, 54)
	$btnRestore.Font = $fontBold
	$btnRestore.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
	$btnRestore.FlatAppearance.BorderSize = 0
	$btnRestore.BackColor = $clrRest
	$btnRestore.ForeColor = [System.Drawing.Color]::White
	$btnRestore.Cursor = [System.Windows.Forms.Cursors]::Hand
	$pAct.Controls.Add($btnRestore)

	$btnClear = New-Object System.Windows.Forms.Button
	$btnClear.Text = "Effacer log"
	$btnClear.Size = New-Object System.Drawing.Size(90, 44)
	$btnClear.Location = New-Object System.Drawing.Point(496, 54)
	$btnClear.Font = $fontUI
	$btnClear.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
	$btnClear.FlatAppearance.BorderSize = 1
	$btnClear.BackColor = $clrBg
	$btnClear.ForeColor = [System.Drawing.Color]::FromArgb(75,85,99)
	$pAct.Controls.Add($btnClear)

	$btnClose = New-Object System.Windows.Forms.Button
	$btnClose.Text = "Fermer"
	$btnClose.Size = New-Object System.Drawing.Size(70, 44)
	$btnClose.Location = New-Object System.Drawing.Point(594, 54)
	$btnClose.Font = $fontUI
	$btnClose.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
	$btnClose.FlatAppearance.BorderSize = 0
	$btnClose.BackColor = $clrClose
	$btnClose.ForeColor = [System.Drawing.Color]::White
	$btnClose.Cursor = [System.Windows.Forms.Cursors]::Hand
	$pAct.Controls.Add($btnClose)

	# Barre de progression (anti-gel: marquee pendant les copies)
	$pbar = New-Object System.Windows.Forms.ProgressBar
	$pbar.Location = New-Object System.Drawing.Point(0, 138)
	$pbar.Size = New-Object System.Drawing.Size(680, 12)
	$pbar.Style = [System.Windows.Forms.ProgressBarStyle]::Continuous
	$pAct.Controls.Add($pbar)

	# Bouton : ouvrir la page mots de passe / synchro des navigateurs (export en clair non automatisable proprement)
	$btnPwd = New-Object System.Windows.Forms.Button
	$btnPwd.Text = "Mots de passe navigateurs (export / synchro)"
	$btnPwd.Size = New-Object System.Drawing.Size(360, 28)
	$btnPwd.Location = New-Object System.Drawing.Point(0, 102)
	$btnPwd.Font = $fontUI
	$btnPwd.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
	$btnPwd.FlatAppearance.BorderSize = 1
	$btnPwd.BackColor = [System.Drawing.Color]::FromArgb(234, 179, 8)
	$btnPwd.ForeColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
	$btnPwd.Cursor = [System.Windows.Forms.Cursors]::Hand
	$pAct.Controls.Add($btnPwd)

	# Log RichTextBox
	$rtb = New-Object System.Windows.Forms.RichTextBox
	$rtb.ReadOnly = $true; $rtb.Dock = [System.Windows.Forms.DockStyle]::Fill
	$rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
	$rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219)
	$rtb.Font = $fontMono; $rtb.BorderStyle = [System.Windows.Forms.BorderStyle]::None
	$tlpR.Controls.Add($rtb, 0, 1)

	# Resize : ajuste txtDest + btnBrowse selon largeur panneau
	$pAct.Add_SizeChanged({
		$w = $pAct.ClientSize.Width
		if ($w -lt 100) { return }
		$txtDest.Width      = [Math]::Max(100, $w - 46)
		$btnBrowse.Location = New-Object System.Drawing.Point(([Math]::Max(104, $w - 42)), 20)
		$pbar.Width = [Math]::Max(100, $w)
	})

	# ══════════════════════ HELPERS ══════════════════════
	$log = {
		param($msg, $clr = "White")
		$ts = Get-Date -Format "HH:mm:ss"
		$rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionLength = 0
		$rtb.SelectionColor = switch ($clr) {
			"Green"  { [System.Drawing.Color]::FromArgb(74,222,128) }
			"Red"    { [System.Drawing.Color]::FromArgb(248,113,113) }
			"Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) }
			"Cyan"   { [System.Drawing.Color]::FromArgb(103,232,249) }
			"Gray"   { [System.Drawing.Color]::FromArgb(107,114,128) }
			default  { [System.Drawing.Color]::FromArgb(209,213,219) }
		}
		$rtb.AppendText("[$ts] $msg`n"); $rtb.ScrollToCaret()
		[System.Windows.Forms.Application]::DoEvents()
	}.GetNewClosure()

	$isChecked = { param($key) $n = $nodeMap[$key]; return ($n -ne $null -and $n.Checked) }.GetNewClosure()

	# Lance un process externe sans geler la fenetre (DoEvents)
	$runProc = {
		param($exe, $argList)
		$pr = Start-Process -FilePath $exe -ArgumentList $argList -WindowStyle Hidden -PassThru
		while (-not $pr.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 150 }
		return $pr.ExitCode
	}.GetNewClosure()

	# Copie de dossier via robocopy : robuste, multi-thread, exclut OneDrive online-only (/XA:O), fenetre reactive
	$copyDir = {
		param($src, $dst, $label)
		if (-not (Test-Path $src)) { & $log "   $label : dossier absent, ignore" "Gray"; return }
		& $log "   $label : copie en cours..." "White"
		New-Item -Path $dst -ItemType Directory -Force | Out-Null
		$pbar.Style = [System.Windows.Forms.ProgressBarStyle]::Marquee
		$code = & $runProc "robocopy.exe" @("`"$src`"", "`"$dst`"", "/E", "/R:1", "/W:1", "/XA:O", "/XJ", "/NFL", "/NDL", "/NP", "/NJH", "/NJS", "/MT:16")
		$pbar.Style = [System.Windows.Forms.ProgressBarStyle]::Continuous
		if ($code -ge 8) { & $log "   $label : termine avec erreurs (robocopy $code)" "Yellow" }
		else { & $log "   $label : OK" "Green" }
	}.GetNewClosure()

	$copyChromium = {
		param($bName, $profileSrc, $migDst)
		if (-not (Test-Path $profileSrc)) { & $log "   $bName : non installe" "Gray"; return }
		$bOut = Join-Path $migDst $bName; New-Item $bOut -ItemType Directory -Force | Out-Null
		$files = @("Bookmarks","Bookmarks.bak","Preferences","Favicons","History","Visited Links","Web Data","Shortcuts","Top Sites","Login Data")
		foreach ($f in $files) {
			$fp = Join-Path $profileSrc $f
			if (Test-Path $fp) { Copy-Item $fp $bOut -Force -ErrorAction SilentlyContinue }
		}
		$extDir = Join-Path $profileSrc "Extensions"
		if (Test-Path $extDir) {
			(Get-ChildItem $extDir -Directory -ErrorAction SilentlyContinue).Name -join "`n" |
				Out-File (Join-Path $bOut "extensions_ids.txt") -Encoding UTF8
		}
		& $log "   $bName : OK" "Green"
	}.GetNewClosure()

	# ══════════════════════ SAUVEGARDE ══════════════════════
	$doSave = {
		$dest = $txtDest.Text.Trim()
		if (-not $dest -or -not (Test-Path $dest)) {
			[System.Windows.Forms.MessageBox]::Show("Choisissez un dossier de destination valide.", "Dossier requis", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
			return
		}
		# Fermeture des navigateurs et d'Outlook (sinon fichiers verrouilles, donnees manquees)
		$toClose = @()
		if (& $isChecked "chrome")      { $toClose += "chrome" }
		if (& $isChecked "edge")        { $toClose += "msedge" }
		if (& $isChecked "brave")       { $toClose += "brave" }
		if (& $isChecked "firefox")     { $toClose += "firefox" }
		if (& $isChecked "thunderbird") { $toClose += "thunderbird" }
		if ((& $isChecked "outlooksig") -or (& $isChecked "outlookpst")) { $toClose += "outlook" }
		$running = $toClose | Where-Object { Get-Process -Name $_ -ErrorAction SilentlyContinue }
		if ($running) {
			$rep = [System.Windows.Forms.MessageBox]::Show(("Ces applications doivent etre fermees pour sauvegarder leurs donnees :`n`n" + ($running -join ", ") + "`n`nLes fermer maintenant ?"), "Fermeture requise", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
			if ($rep -ne [System.Windows.Forms.DialogResult]::Yes) { & $log "Sauvegarde annulee (applications ouvertes)." "Red"; return }
			foreach ($pn in $running) { Stop-Process -Name $pn -Force -ErrorAction SilentlyContinue }
			Start-Sleep -Milliseconds 800
		}
		$btnSave.Enabled = $false; $btnRestore.Enabled = $false
		& $log "========== DEBUT SAUVEGARDE ==========" "Yellow"
		$root = Join-Path $dest "MigrationPC_$(Get-Date -Format 'yyyyMMdd_HHmm')"
		New-Item $root -ItemType Directory -Force | Out-Null
		& $log "Dossier : $root" "Cyan"

		# -- Donnees personnelles
		$dataMap = [ordered]@{
			"doc"   = @([Environment]::GetFolderPath("MyDocuments"), "Documents")
			"desk"  = @([Environment]::GetFolderPath("Desktop"),     "Bureau")
			"dl"    = @((Join-Path $env:USERPROFILE "Downloads"),    "Telechargements")
			"img"   = @([Environment]::GetFolderPath("MyPictures"),  "Images")
			"music" = @([Environment]::GetFolderPath("MyMusic"),     "Musique")
			"video" = @([Environment]::GetFolderPath("MyVideos"),    "Videos")
			"fav"   = @([Environment]::GetFolderPath("Favorites"),   "Favoris")
		}
		foreach ($k in $dataMap.Keys) {
			if (& $isChecked $k) { & $copyDir $dataMap[$k][0] (Join-Path $root $dataMap[$k][1]) $dataMap[$k][1] }
		}

		# -- Navigateurs Chromium
		if ((& $isChecked "chrome") -or (& $isChecked "brave") -or (& $isChecked "edge")) {
			& $log "Navigateurs..." "Cyan"
			$bDir = Join-Path $root "Navigateurs"; New-Item $bDir -ItemType Directory -Force | Out-Null
			$chromePaths = [ordered]@{
				"chrome" = "$env:LOCALAPPDATA\Google\Chrome\User Data\Default"
				"brave"  = "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default"
				"edge"   = "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default"
			}
			foreach ($bk in $chromePaths.Keys) { if (& $isChecked $bk) { & $copyChromium $bk $chromePaths[$bk] $bDir } }
		}

		# -- Firefox
		if (& $isChecked "firefox") {
			& $log "Firefox..." "Cyan"
			$ffSrc = "$env:APPDATA\Mozilla\Firefox\Profiles"
			if (Test-Path $ffSrc) {
				& $copyDir $ffSrc (Join-Path $root "Firefox") "Firefox"
			}
		}

		# -- Outlook signatures
		if (& $isChecked "outlooksig") {
			& $copyDir "$env:APPDATA\Microsoft\Signatures" (Join-Path $root "Outlook_Signatures") "Outlook Signatures"
		}

		# -- Outlook PST
		if (& $isChecked "outlookpst") {
			& $log "Outlook PST (recherche)..." "Cyan"
			$pstFiles = Get-ChildItem "$env:USERPROFILE" -Filter "*.pst" -Recurse -Depth 4 -ErrorAction SilentlyContinue
			if ($pstFiles) {
				$pstDst = Join-Path $root "Outlook_PST"; New-Item $pstDst -ItemType Directory -Force | Out-Null
				foreach ($pst in $pstFiles) {
					Copy-Item $pst.FullName $pstDst -Force -ErrorAction SilentlyContinue
					& $log "   PST copie : $($pst.Name)" "Green"
				}
			} else { & $log "   Aucun fichier PST trouve" "Gray" }
		}

		# -- Thunderbird
		if (& $isChecked "thunderbird") {
			& $copyDir "$env:APPDATA\Thunderbird\Profiles" (Join-Path $root "Thunderbird") "Thunderbird"
		}

		# -- WiFi
		if (& $isChecked "wifi") {
			& $log "Profils WiFi..." "Cyan"
			$wDir = Join-Path $root "WiFi"; New-Item $wDir -ItemType Directory -Force | Out-Null
			netsh wlan export profile folder="$wDir" key=clear 2>$null | Out-Null
			& $log "   WiFi : OK" "Green"
		}

		# -- Imprimantes
		if (& $isChecked "printers") {
			& $log "Imprimantes..." "Cyan"
			Get-Printer | Select-Object Name, DriverName, PortName, Shared, Published |
				Export-Csv (Join-Path $root "Imprimantes.csv") -NoTypeInformation -Encoding UTF8
			& $log "   Imprimantes : OK" "Green"
		}

		# -- Lecteurs reseau
		if (& $isChecked "drives") {
			& $log "Lecteurs reseau..." "Cyan"
			Get-PSDrive -PSProvider FileSystem | Where-Object { $_.DisplayRoot -like "\\*" } |
				Select-Object Name, DisplayRoot |
				Export-Csv (Join-Path $root "LecteursReseau.csv") -NoTypeInformation -Encoding UTF8
			& $log "   Lecteurs reseau : OK" "Green"
		}

		# -- Hosts
		if (& $isChecked "hosts") {
			$hostsFile = "$env:SystemRoot\System32\drivers\etc\hosts"
			if (Test-Path $hostsFile) { Copy-Item $hostsFile (Join-Path $root "hosts") -Force; & $log "   Hosts : OK" "Green" }
		}

		# -- Variables d'environnement
		if (& $isChecked "envvars") {
			& $log "Variables d'environnement..." "Cyan"
			[Environment]::GetEnvironmentVariables("User") |
				ConvertTo-Json | Out-File (Join-Path $root "EnvVars_User.json") -Encoding UTF8
			& $log "   Variables : OK" "Green"
		}

		# -- Winget - liste des applis
		if (& $isChecked "winget") {
			& $log "Liste applications Winget..." "Cyan"
			try {
				$wingetList = & winget export -o (Join-Path $root "winget_apps.json") --accept-source-agreements 2>&1
				& $log "   Winget : OK" "Green"
			} catch {
				& $log "   Winget : $($_.Exception.Message)" "Red"
			}
		}

		# -- AppData Roaming (selectif)
		if (& $isChecked "approaming") {
			& $log "AppData Roaming (selectif)..." "Cyan"
			$roamingApps = @("7-Zip","WinRAR","Notepad++","Everything","VLC media player","paint.net","FileZilla","HeidiSQL","WinSCP","PuTTY")
			$roamDst = Join-Path $root "AppData_Roaming"; New-Item $roamDst -ItemType Directory -Force | Out-Null
			foreach ($app in $roamingApps) {
				$appPath = Join-Path $env:APPDATA $app
				if (Test-Path $appPath) { & $copyDir $appPath (Join-Path $roamDst $app) $app }
			}
		}

		# -- SSH
		if (& $isChecked "ssh") { & $copyDir "$env:USERPROFILE\.ssh" (Join-Path $root "SSH") "Cles SSH" }

		# -- PowerShell profile
		if (& $isChecked "pshell") {
			$psProfile = $PROFILE.CurrentUserAllHosts
			if (Test-Path $psProfile) { Copy-Item $psProfile (Join-Path $root "PowerShell_profile.ps1") -Force; & $log "   Profil PowerShell : OK" "Green" }
		}

		# -- Git config
		if (& $isChecked "git") {
			$gitConfig = "$env:USERPROFILE\.gitconfig"
			if (Test-Path $gitConfig) { Copy-Item $gitConfig (Join-Path $root ".gitconfig") -Force; & $log "   Git config : OK" "Green" }
		}

		# -- Theme + fond ecran
		if (& $isChecked "theme") {
			& $log "Theme + fond d ecran..." "Cyan"
			$thDst = Join-Path $root "Theme"; New-Item $thDst -ItemType Directory -Force | Out-Null
			$wp = (Get-ItemProperty "HKCU:\Control Panel\Desktop" -Name Wallpaper -ErrorAction SilentlyContinue).Wallpaper
			if ($wp -and (Test-Path $wp)) { Copy-Item $wp (Join-Path $thDst ("wallpaper" + [System.IO.Path]::GetExtension($wp))) -Force -ErrorAction SilentlyContinue }
			& $runProc "reg.exe" @("export", "HKCU\Control Panel\Desktop", ("`"" + (Join-Path $thDst "desktop.reg") + "`""), "/y") | Out-Null
			& $runProc "reg.exe" @("export", "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", ("`"" + (Join-Path $thDst "personalize.reg") + "`""), "/y") | Out-Null
			& $runProc "reg.exe" @("export", "HKCU\Software\Microsoft\Windows\DWM", ("`"" + (Join-Path $thDst "dwm.reg") + "`""), "/y") | Out-Null
			& $log "   Theme : OK" "Green"
		}

		# -- Parametres regionaux + langue
		if (& $isChecked "locale") {
			& $log "Parametres regionaux + langue..." "Cyan"
			$locDst = Join-Path $root "Locale"; New-Item $locDst -ItemType Directory -Force | Out-Null
			try { Get-WinUserLanguageList | Export-Clixml (Join-Path $locDst "langlist.xml") } catch {}
			$reg = [pscustomobject]@{ Culture=(Get-Culture).Name; SystemLocale=(Get-WinSystemLocale).Name; GeoId=(Get-WinHomeLocation).GeoId; TimeZone=(Get-TimeZone).Id }
			$reg | ConvertTo-Json | Out-File (Join-Path $locDst "regional.json") -Encoding UTF8
			& $log "   Locale : OK" "Green"
		}

		# -- Menu Demarrer + barre des taches
		if (& $isChecked "startmenu") {
			& $log "Menu Demarrer + barre des taches..." "Cyan"
			$smDst = Join-Path $root "StartTaskbar"; New-Item $smDst -ItemType Directory -Force | Out-Null
			$tbSrc = "$env:APPDATA\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar"
			if (Test-Path $tbSrc) { & $copyDir $tbSrc (Join-Path $smDst "TaskBar") "Barre des taches (raccourcis)" }
			& $runProc "reg.exe" @("export", "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Taskband", ("`"" + (Join-Path $smDst "taskband.reg") + "`""), "/y") | Out-Null
			$startState = "$env:LOCALAPPDATA\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState"
			if (Test-Path $startState) { & $copyDir $startState (Join-Path $smDst "StartLayout") "Disposition menu Demarrer" }
			& $log "   Menu Demarrer : OK" "Green"
		}

		# -- Associations de fichiers (DISM, systeme)
		if (& $isChecked "fileassoc") {
			& $log "Associations de fichiers (DISM)..." "Cyan"
			$faDst = Join-Path $root "FileAssoc"; New-Item $faDst -ItemType Directory -Force | Out-Null
			& $runProc "dism.exe" @("/Online", ("/Export-DefaultAppAssociations:`"" + (Join-Path $faDst "AppAssoc.xml") + "`"")) | Out-Null
			& $log "   Associations : OK" "Green"
		}

		# -- Credentials Windows (liste uniquement, mots de passe non exportables - DPAPI)
		if (& $isChecked "creds") {
			& $log "Credentials Windows (liste)..." "Cyan"
			cmdkey /list | Out-File (Join-Path $root "Credentials_liste.txt") -Encoding UTF8
			& $log "   Credentials : liste exportee (mots de passe NON transferables)" "Yellow"
		}

		& $log "" "Gray"
		& $log "========== SAUVEGARDE TERMINEE ==========" "Green"
		& $log "Dossier : $root" "Cyan"
		$btnSave.Enabled = $true; $btnRestore.Enabled = $true
	}.GetNewClosure()

	# ══════════════════════ RESTAURATION ══════════════════════
	$doRestore = {
		$src = $txtDest.Text.Trim()
		if (-not $src -or -not (Test-Path $src)) {
			[System.Windows.Forms.MessageBox]::Show("Choisissez le dossier contenant la sauvegarde.", "Dossier requis", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
			return
		}
		$confirm = [System.Windows.Forms.MessageBox]::Show("La restauration va fusionner/ecraser les donnees et parametres de CE PC avec la sauvegarde.`n`nContinuer ?", "Confirmation restauration", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
		if ($confirm -ne [System.Windows.Forms.DialogResult]::Yes) { return }
		# Chercher automatiquement le dernier dossier MigrationPC_*
		$sub = Get-ChildItem $src -Directory -Filter "MigrationPC_*" -ErrorAction SilentlyContinue |
			Sort-Object Name -Descending | Select-Object -First 1
		$root = if ($sub) { $sub.FullName } else { $src }

		$btnSave.Enabled = $false; $btnRestore.Enabled = $false
		& $log "========== DEBUT RESTAURATION ==========" "Yellow"
		& $log "Source : $root" "Cyan"

		# -- Donnees personnelles
		$dataMap = [ordered]@{
			"doc"   = @("Documents",       [Environment]::GetFolderPath("MyDocuments"))
			"desk"  = @("Bureau",          [Environment]::GetFolderPath("Desktop"))
			"dl"    = @("Telechargements", (Join-Path $env:USERPROFILE "Downloads"))
			"img"   = @("Images",          [Environment]::GetFolderPath("MyPictures"))
			"music" = @("Musique",         [Environment]::GetFolderPath("MyMusic"))
			"video" = @("Videos",          [Environment]::GetFolderPath("MyVideos"))
			"fav"   = @("Favoris",         [Environment]::GetFolderPath("Favorites"))
		}
		foreach ($k in $dataMap.Keys) {
			if (& $isChecked $k) {
				$srcDir = Join-Path $root $dataMap[$k][0]
				if (Test-Path $srcDir) { & $copyDir $srcDir $dataMap[$k][1] $dataMap[$k][0] }
			}
		}

		# -- Navigateurs
		if ((& $isChecked "chrome") -or (& $isChecked "brave") -or (& $isChecked "edge")) {
			& $log "Restauration navigateurs..." "Cyan"
			$bDir = Join-Path $root "Navigateurs"
			$chromePaths = [ordered]@{
				"chrome" = "$env:LOCALAPPDATA\Google\Chrome\User Data\Default"
				"brave"  = "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default"
				"edge"   = "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default"
			}
			foreach ($bk in $chromePaths.Keys) {
				if ((& $isChecked $bk) -and (Test-Path (Join-Path $bDir $bk))) {
					& $copyDir (Join-Path $bDir $bk) $chromePaths[$bk] $bk
				}
			}
		}

		# -- Firefox
		if (& $isChecked "firefox") {
			$ffSrc = Join-Path $root "Firefox"
			if (Test-Path $ffSrc) { & $copyDir $ffSrc "$env:APPDATA\Mozilla\Firefox\Profiles" "Firefox" }
		}

		# -- Outlook signatures
		if (& $isChecked "outlooksig") {
			$sigSrc = Join-Path $root "Outlook_Signatures"
			if (Test-Path $sigSrc) { & $copyDir $sigSrc "$env:APPDATA\Microsoft\Signatures" "Outlook Signatures" }
		}

		# -- Thunderbird
		if (& $isChecked "thunderbird") {
			$tbSrc = Join-Path $root "Thunderbird"
			if (Test-Path $tbSrc) { & $copyDir $tbSrc "$env:APPDATA\Thunderbird\Profiles" "Thunderbird" }
		}

		# -- WiFi
		if (& $isChecked "wifi") {
			& $log "Restauration WiFi..." "Cyan"
			$wDir = Join-Path $root "WiFi"
			if (Test-Path $wDir) {
				Get-ChildItem $wDir -Filter "*.xml" | ForEach-Object {
					netsh wlan add profile filename="$($_.FullName)" user=all 2>$null | Out-Null
				}
				& $log "   WiFi : OK" "Green"
			}
		}

		# -- Imprimantes (affichage liste)
		if (& $isChecked "printers") {
			$pCsv = Join-Path $root "Imprimantes.csv"
			if (Test-Path $pCsv) {
				& $log "Imprimantes sauvegardees :" "Cyan"
				Import-Csv $pCsv | ForEach-Object { & $log "   - $($_.Name) ($($_.DriverName))" "White" }
				& $log "   -> Reinstaller manuellement si necessaire" "Gray"
			}
		}

		# -- Lecteurs reseau
		if (& $isChecked "drives") {
			$dCsv = Join-Path $root "LecteursReseau.csv"
			if (Test-Path $dCsv) {
				& $log "Restauration lecteurs reseau..." "Cyan"
				Import-Csv $dCsv | ForEach-Object {
					try { New-PSDrive -Name $_.Name -PSProvider FileSystem -Root $_.DisplayRoot -Persist -ErrorAction Stop | Out-Null; & $log "   $($_.Name): -> $($_.DisplayRoot) OK" "Green" }
					catch { & $log "   $($_.Name): erreur - $($_.Exception.Message)" "Red" }
				}
			}
		}

		# -- Hosts
		if (& $isChecked "hosts") {
			$hSrc = Join-Path $root "hosts"
			if (Test-Path $hSrc) { Copy-Item $hSrc "$env:SystemRoot\System32\drivers\etc\hosts" -Force; & $log "   Hosts : OK" "Green" }
		}

		# -- Variables environnement
		if (& $isChecked "envvars") {
			$evJson = Join-Path $root "EnvVars_User.json"
			if (Test-Path $evJson) {
				& $log "Restauration variables d'environnement..." "Cyan"
				$vars = Get-Content $evJson | ConvertFrom-Json
				$vars.PSObject.Properties | ForEach-Object {
					if ($_.Name -in @('Path','PATH','Temp','TMP','TEMP')) { return }  # ne pas ecraser PATH/Temp du PC cible
					[Environment]::SetEnvironmentVariable($_.Name, $_.Value, "User")
				}
				& $log "   Variables : OK" "Green"
			}
		}

		# -- Winget reinstall
		if (& $isChecked "winget") {
			$wJson = Join-Path $root "winget_apps.json"
			if (Test-Path $wJson) {
				& $log "Reinstallation applications via Winget..." "Cyan"
				& $log "   Lancement de winget import (peut prendre plusieurs minutes)..." "White"
				try {
					$result = & winget import -i $wJson --accept-source-agreements --accept-package-agreements 2>&1
					& $log "   Winget import : termine" "Green"
				} catch {
					& $log "   Winget : $($_.Exception.Message)" "Red"
				}
			}
		}

		# -- SSH
		if (& $isChecked "ssh") {
			$sshSrc = Join-Path $root "SSH"
			if (Test-Path $sshSrc) { & $copyDir $sshSrc "$env:USERPROFILE\.ssh" "Cles SSH" }
		}

		# -- PowerShell profile
		if (& $isChecked "pshell") {
			$psSrc = Join-Path $root "PowerShell_profile.ps1"
			if (Test-Path $psSrc) {
				$psDir = Split-Path $PROFILE.CurrentUserAllHosts
				if (-not (Test-Path $psDir)) { New-Item $psDir -ItemType Directory -Force | Out-Null }
				Copy-Item $psSrc $PROFILE.CurrentUserAllHosts -Force
				& $log "   Profil PowerShell : OK" "Green"
			}
		}

		# -- Git config
		if (& $isChecked "git") {
			$gitSrc = Join-Path $root ".gitconfig"
			if (Test-Path $gitSrc) { Copy-Item $gitSrc "$env:USERPROFILE\.gitconfig" -Force; & $log "   Git config : OK" "Green" }
		}

		# -- Theme + fond ecran
		if (& $isChecked "theme") {
			$thSrc = Join-Path $root "Theme"
			if (Test-Path $thSrc) {
				& $log "Restauration theme + fond d ecran..." "Cyan"
				Get-ChildItem $thSrc -Filter *.reg -ErrorAction SilentlyContinue | ForEach-Object { & $runProc "reg.exe" @("import", ("`"" + $_.FullName + "`"")) | Out-Null }
				$wpFile = Get-ChildItem $thSrc -Filter "wallpaper.*" -ErrorAction SilentlyContinue | Select-Object -First 1
				if ($wpFile) {
					$wpDst = Join-Path $env:APPDATA ("wallpaper_migrated" + $wpFile.Extension)
					Copy-Item $wpFile.FullName $wpDst -Force -ErrorAction SilentlyContinue
					Set-ItemProperty "HKCU:\Control Panel\Desktop" -Name Wallpaper -Value $wpDst -ErrorAction SilentlyContinue
					& $runProc "rundll32.exe" @("user32.dll,UpdatePerUserSystemParameters", "1", "True") | Out-Null
				}
				& $log "   Theme : OK (deconnexion conseillee pour les couleurs)" "Green"
			}
		}

		# -- Parametres regionaux + langue
		if (& $isChecked "locale") {
			$locSrc = Join-Path $root "Locale"
			if (Test-Path $locSrc) {
				& $log "Restauration parametres regionaux..." "Cyan"
				$ll = Join-Path $locSrc "langlist.xml"
				if (Test-Path $ll) { try { Set-WinUserLanguageList (Import-Clixml $ll) -Force } catch { & $log "   Langue : $($_.Exception.Message)" "Yellow" } }
				$rj = Join-Path $locSrc "regional.json"
				if (Test-Path $rj) {
					$r = Get-Content $rj -Raw | ConvertFrom-Json
					try { Set-Culture $r.Culture } catch {}
					try { Set-WinHomeLocation -GeoId $r.GeoId } catch {}
					try { Set-TimeZone -Id $r.TimeZone } catch {}
				}
				& $log "   Locale : OK" "Green"
			}
		}

		# -- Menu Demarrer + barre des taches
		if (& $isChecked "startmenu") {
			$smSrc = Join-Path $root "StartTaskbar"
			if (Test-Path $smSrc) {
				& $log "Restauration menu Demarrer + barre..." "Cyan"
				$tb = Join-Path $smSrc "TaskBar"
				if (Test-Path $tb) { & $copyDir $tb "$env:APPDATA\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar" "Barre des taches (raccourcis)" }
				$tbr = Join-Path $smSrc "taskband.reg"
				if (Test-Path $tbr) { & $runProc "reg.exe" @("import", ("`"" + $tbr + "`"")) | Out-Null }
				$sl = Join-Path $smSrc "StartLayout"
				if (Test-Path $sl) { & $copyDir $sl "$env:LOCALAPPDATA\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState" "Disposition menu Demarrer" }
				Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 600; Start-Process explorer
				& $log "   Menu Demarrer : OK (Explorer redemarre)" "Green"
			}
		}

		# -- Associations de fichiers (DISM)
		if (& $isChecked "fileassoc") {
			$fa = Join-Path $root "FileAssoc\AppAssoc.xml"
			if (Test-Path $fa) {
				& $log "Restauration associations de fichiers..." "Cyan"
				& $runProc "dism.exe" @("/Online", ("/Import-DefaultAppAssociations:`"" + $fa + "`"")) | Out-Null
				& $log "   Associations : OK (s applique aux nouvelles sessions/comptes)" "Green"
			}
		}

		# -- Credentials Windows
		if (& $isChecked "creds") {
			$cl = Join-Path $root "Credentials_liste.txt"
			if (Test-Path $cl) { & $log "Credentials Windows : liste presente (a recreer manuellement, non transferables)" "Yellow" }
		}

		& $log "" "Gray"
		& $log "========== RESTAURATION TERMINEE ==========" "Green"
		& $log "Redemarrez le PC pour appliquer tous les changements." "Yellow"
		$btnSave.Enabled = $true; $btnRestore.Enabled = $true
	}.GetNewClosure()

	# ══════════════════════ EVENEMENTS ══════════════════════
	$btnBrowse.Add_Click({
		$fb = New-Object System.Windows.Forms.FolderBrowserDialog
		$fb.Description = "Choisissez le dossier USB ou reseau"
		if ($fb.ShowDialog() -eq "OK") {
			$txtDest.Text = $fb.SelectedPath
			& $log "Dossier : $($fb.SelectedPath)" "Cyan"
		}
	}.GetNewClosure())

	$btnSave.Add_Click({ & $doSave }.GetNewClosure())
	$btnRestore.Add_Click({ & $doRestore }.GetNewClosure())
	$btnPwd.Add_Click({
		& $log "Pages mots de passe (exporte ici, ou active la synchro par compte = recommande)..." "Cyan"
		$browsers = @(
			@{ Name="Chrome";  Key="chrome";  Cand=@("chrome","$env:ProgramFiles\Google\Chrome\Application\chrome.exe","${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe"); Url="chrome://password-manager/passwords" },
			@{ Name="Edge";    Key="edge";    Cand=@("msedge","${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe","$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"); Url="edge://settings/passwords" },
			@{ Name="Brave";   Key="brave";   Cand=@("brave","$env:ProgramFiles\BraveSoftware\Brave-Browser\Application\brave.exe","$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\Application\brave.exe"); Url="brave://settings/passwords" },
			@{ Name="Firefox"; Key="firefox"; Cand=@("firefox","$env:ProgramFiles\Mozilla Firefox\firefox.exe","${env:ProgramFiles(x86)}\Mozilla Firefox\firefox.exe"); Url="about:logins" }
		)
		$any = $false
		foreach ($b in $browsers) {
			if (-not (& $isChecked $b.Key)) { continue }
			$exe = $null
			foreach ($c in $b.Cand) { if ((Get-Command $c -ErrorAction SilentlyContinue) -or (Test-Path $c -ErrorAction SilentlyContinue)) { $exe = $c; break } }
			if ($exe) { try { Start-Process $exe $b.Url -ErrorAction Stop; & $log "   $($b.Name) : page ouverte" "Green"; $any = $true; Start-Sleep -Milliseconds 400 } catch { & $log "   $($b.Name) : echec ouverture" "Yellow" } }
			else { & $log "   $($b.Name) : non installe" "Gray" }
		}
		if (-not $any) { & $log "   Aucun navigateur coche/detecte." "Gray" }
	}.GetNewClosure())
	$btnClear.Add_Click({ $rtb.Clear() })
	$btnClose.Add_Click({ $form.Close() })

	$form.Add_Shown({ $form.Activate() })

	[void]$form.ShowDialog()
}
#4444444444444444444444444444444444444444444444444444 Nom PC plus OEM A propos   44444444444444444444444444444444444444444444444444444444444444444444
function OEMNOMPC
{
	
	$textBox.AppendText("Creation Raccourcis du bureau..." + [Environment]::NewLine)
	# Logo copie depuis assets/logo.bmp (evite d'embarquer un blob base64 dans le script)
	Add-Content -Path "$env:TEMP\logfile.txt" -Value "Racc Bur ok"
	$filePath = "C:\windows\logo.bmp"
	$logoAsset = Join-Path $PSScriptRoot "assets\logo.bmp"
	if (Test-Path $logoAsset) { Copy-Item -Path $logoAsset -Destination $filePath -Force }
	
	# Parcourir le hashtable et créer chaque raccourci
	foreach ($nom in $cheminsSpeciaux.Keys)
	{
		$raccourci = $WshShell.CreateShortcut("$cheminBureau\$nom.lnk")
		$raccourci.TargetPath = $cheminsSpeciaux[$nom]
		$raccourci.Save()
	}
	# Obtenir les informations du fabricant et du modèle
	$compInfo = Get-CimInstance -Class Win32_ComputerSystem
	
	# Définir le fabricant et le modèle en fonction des informations récupérées
	$Manufacturer = $compInfo.Manufacturer
	$Model = $compInfo.Model
	
	# Obtenir la date du jour
	$today = Get-Date
	
	# Ajouter la date du jour à la chaîne du fabricant
	$Manufacturer += " Installé le " + $today.ToString("dd/MM/yy")
	
	# Définir les nouvelles informations de support
	$SupportPhone = "Stephan Informatique 06-36-98-23-30"
	$SupportURL = "https://ticket.stephaninformatique.fr"
	$LogoPath = "C:\windows\logo.bmp" # Remplacez ceci par le chemin de votre logo
	
	
	# Définir le chemin vers la clé de registre
	$RegistryPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation"
	
	# Modifier les informations OEM
	Set-ItemProperty -Path $RegistryPath -Name "Manufacturer" -Value $Manufacturer
	Set-ItemProperty -Path $RegistryPath -Name "Model" -Value $Model
	Set-ItemProperty -Path $RegistryPath -Name "SupportPhone" -Value $SupportPhone
	Set-ItemProperty -Path $RegistryPath -Name "SupportURL" -Value $SupportURL
	Set-ItemProperty -Path $RegistryPath -Name "Logo" -Value $LogoPath
	# Ajouter la librairie nécessaire pour la boîte de dialogue
	
	Add-Type -AssemblyName System.Windows.Forms
	$textBox.AppendText("$Manufacturer." + [Environment]::NewLine)
	$textBox.AppendText("$Model." + [Environment]::NewLine)
	$textBox.AppendText("$SupportPhone." + [Environment]::NewLine)
	$textBox.AppendText("$SupportURL." + [Environment]::NewLine)
	
	Add-Content -Path "$env:TEMP\logfile.txt" -Value "Tag PC OEM ok"
	
	$textBox.AppendText("Changement du nom de l''ordinateur..." + [Environment]::NewLine)
	# Ajouter les types nécessaires
	Add-Type -AssemblyName System.Windows.Forms
	
	# Obtenir les informations actuelles du système
	$compInfo = Get-CimInstance -Class Win32_ComputerSystem
	$Model = $compInfo.Model -replace '\s', '' # Supprimer les espaces
	$CurrentName = $compInfo.Name
	
	# Obtenir les deux derniers chiffres de l'année actuelle
	$Year = (Get-Date).Year.ToString().Substring(2, 2)
	
	# Construire le nouveau nom de l'ordinateur
	$NewComputerName = $Model + $Year
	
	# S'assurer que le nom de l'ordinateur n'a pas plus de 10 caractères
	if ($NewComputerName.Length -gt 10)
	{
		$NewComputerName = $NewComputerName.Substring(0, 10)
	}
	
	# Vérifier si le nom actuel de l'ordinateur commence par "DESKTOP" ou "LAPTOP"
	if ($CurrentName.StartsWith("DESKTOP") -or $CurrentName.StartsWith("LAPTOP"))
	{
		# Renommer l'ordinateur
		Rename-Computer -NewName $NewComputerName -Force
		$textBox.AppendText("Le nouveau nom de l'ordinateur est $NewComputerName..." + [Environment]::NewLine)
		
		# Afficher une boîte de dialogue demandant à l'utilisateur s'il veut redémarrer maintenant ou plus tard
		Add-Content -Path "$env:TEMP\logfile.txt" -Value "Changement Nom Ordi ok"
		$result = [System.Windows.Forms.MessageBox]::Show("Voulez-vous redémarrer maintenant?", "Redémarrage", [System.Windows.Forms.MessageBoxButtons]::YesNo)
		
		if ($result -eq "Yes")
		{
			# Redémarrer l'ordinateur
			Restart-Computer
		}
	}
	else
	{
		$textBox.AppendText("Le nom de l'ordinateur ne commence pas par 'DESKTOP' ni 'LAPTOP'..." + [Environment]::NewLine)
		Write-Output "Le nom de l'ordinateur ne commence pas par 'DESKTOP' ou 'LAPTOP', donc il n'a pas été modifié."
		Add-Content -Path "$env:TEMP\logfile.txt" -Value "Pas de changement de Nom Ordi ok"
	}
	
	$textBox.AppendText("Configuration terminée..." + [Environment]::NewLine)
	
}

#55555555555555555555555555555555555555555555555555555 Raccourcis Programmes plus Cepc ...   55555555555555555555555555555555555555555555555555555555
function RaccProgSys
{
	$textBox.AppendText("Téléchargement raccourcis..." + [Environment]::NewLine)
	$url = "https://stephaninformatique.fr/pws/racc.zip"
	$output = "$env:TEMP\racc.zip"
	Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30
	
	$textBox.AppendText("Décompression et mise en place raccourcis..." + [Environment]::NewLine)
	$destinationPath = [Environment]::GetFolderPath('CommonDesktopDirectory')
	Expand-Archive -Path $output -DestinationPath $destinationPath -Force

	$textBox.AppendText("Installation Raccourcis Systeme..." + [Environment]::NewLine)
	$registryPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel"
	$registryValues = @{
		"{59031a47-3f72-44a7-89c5-5595fe6b30ee}" = 0
		"{20D04FE0-3AEA-1069-A2D8-08002B30309D}" = 0
		"{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}" = 0
		"{a953e9ae-dc5b-47fc-bf21-70f1a8e30b3f}" = 1
		"{018D5C66-4533-4307-9B53-224DE2ED1FE6}" = 1
	}
	$registryValues.GetEnumerator() | ForEach-Object {
		Set-ItemProperty -Path $registryPath -Name $_.Key -Value $_.Value
	}
	
	$textBox.AppendText("Installation redemarrer pour appliquer..." + [Environment]::NewLine)
	
	$textBox.AppendText("Suppression doublons..." + [Environment]::NewLine)
	$DesktopPathUser = [Environment]::GetFolderPath("Desktop")
	$DesktopPathPublic = "$env:PUBLIC\Desktop"
	$ApplicationsPath = Join-Path -Path $DesktopPathPublic -ChildPath "Applications"
	New-Item -ItemType Directory -Path $ApplicationsPath -Force | Out-Null
	
	$namesToSkip = "Chrome", "Word", "Excel"
	Get-ChildItem -Path $DesktopPathUser, $DesktopPathPublic -Filter "*.lnk" -File |
	Where-Object { $_.BaseName -notin $namesToSkip } |
	Move-Item -Destination $ApplicationsPath -Force -ErrorAction SilentlyContinue
	
	$uniqueShortcutNames = @{ }
	Get-ChildItem -Path $ApplicationsPath -Filter "*.lnk" -File | ForEach-Object {
		$shortcutName = $_.BaseName
		if ($uniqueShortcutNames.ContainsKey($shortcutName))
		{
			Write-Host "Doublon trouvé : $shortcutName"
			Remove-Item -Path $_.FullName -Force -ErrorAction SilentlyContinue
			Write-Host "Doublon supprimé : $shortcutName"
		}
		else
		{
			$uniqueShortcutNames[$shortcutName] = $true
		}
	}
	
	$textBox.AppendText("Raccoucis Bureau Ok.`r`n")
}

#66666666666666666666666666666666666666666666666666666666   Installation THEMES DU BUREAU  6666666666666666666666666666666666666666666666666666666666
function Theme
{
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing

	# ── Dimensions ───────────────────────────────────────────────────────────────
	$sw = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Width
	$sh = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Height
	$fw = [int]([Math]::Min(920, $sw * 0.70))
	$fh = [int]([Math]::Min(680, $sh * 0.82))

	# ── Polices ───────────────────────────────────────────────────────────────────
	$fs      = [Math]::Max(8, [Math]::Min(10, [int]($sh / 140)))
	$fontUI  = New-Object System.Drawing.Font("Segoe UI", $fs)
	$fontSm  = New-Object System.Drawing.Font("Segoe UI", ($fs - 1))
	$fontBold= New-Object System.Drawing.Font("Segoe UI Semibold", $fs)
	$fontTitl= New-Object System.Drawing.Font("Segoe UI", ($fs + 4), [System.Drawing.FontStyle]::Bold)
	$fontBtn = New-Object System.Drawing.Font("Segoe UI Semibold", $fs)

	# ── Couleurs ──────────────────────────────────────────────────────────────────
	$clrTop     = [System.Drawing.Color]::FromArgb(15, 23, 42)
	$clrBot     = [System.Drawing.Color]::FromArgb(248, 249, 250)
	$clrBg      = [System.Drawing.Color]::FromArgb(243, 244, 246)
	$clrCard    = [System.Drawing.Color]::White
	$clrSelCard = [System.Drawing.Color]::FromArgb(219, 234, 254)
	$clrBorder  = [System.Drawing.Color]::FromArgb(229, 231, 235)
	$clrText    = [System.Drawing.Color]::FromArgb(17, 24, 39)
	$clrMuted   = [System.Drawing.Color]::FromArgb(107, 114, 128)

	$catBadgeColors = @{
		"Paysages" = [System.Drawing.Color]::FromArgb(21, 128, 61)
		"Nature"   = [System.Drawing.Color]::FromArgb(15, 118, 110)
		"Espace"   = [System.Drawing.Color]::FromArgb(88, 28, 135)
		"Abstrait" = [System.Drawing.Color]::FromArgb(30, 64, 175)
		"Urbain"   = [System.Drawing.Color]::FromArgb(194, 65, 12)
	}

	# ── Themes ────────────────────────────────────────────────────────────────────
	$base      = "https://xwz.fr/themes"
	$tbase     = "https://themepack.me/i/c/749x467/media/g"

	$themes = @(
		@{ Name="Landscape Classic"; Cat="Paysages"; Url="https://stephaninformatique.fr/pws/landscape.deskthemepack";   Thumb="$tbase/786/landscape-thb.jpg" }
		@{ Name="Beach HD";          Cat="Paysages"; Url="$base/beach-hd-theme.deskthemepack";   Thumb="$tbase/416/beach-thb.jpg" }
		@{ Name="Japanese Autumn";   Cat="Paysages"; Url="$base/japanese-autumn.deskthemepack";  Thumb="$tbase/2157/tb.jpg" }
		@{ Name="Automne UHD";       Cat="Paysages"; Url="$base/Automne-uhd-theme.deskthemepack";Thumb="$tbase/2115/tb.jpg" }
		@{ Name="Japanese Winter";   Cat="Paysages"; Url="$base/japanese-winter.deskthemepack";  Thumb="https://themepack.me/i/c/749x467/media/g/2158/japanese-winter-theme-tg8.jpg" }
		@{ Name="Bing";              Cat="Paysages"; Url="$base/bing.deskthemepack";             Thumb="https://themepack.me/i/c/749x467/media/g/766/bing-theme-js2.jpg" }
		@{ Name="Rocky Mountains";   Cat="Paysages"; Url="$base/rocky-mountains.deskthemepack";  Thumb="$tbase/857/tb.jpg" }
		@{ Name="Norwegian Fjords";  Cat="Paysages"; Url="$base/norwegian-fjords.deskthemepack"; Thumb="$tbase/1248/tb.jpg" }
		@{ Name="Desert Sunrise";    Cat="Paysages"; Url="$base/desert-sunrise.deskthemepack";   Thumb="$tbase/703/tb.jpg" }
		@{ Name="Tropical Paradise"; Cat="Paysages"; Url="$base/tropical-paradise.deskthemepack";Thumb="$tbase/498/tb.jpg" }
		@{ Name="Reflection";        Cat="Nature";   Url="$base/reflection1.deskthemepack";      Thumb="https://themepack.me/i/c/749x467/media/g/2239/reflection-theme-tn3.jpg" }
		@{ Name="Aurora Borealis";   Cat="Nature";   Url="$base/aurora-borealis.deskthemepack";  Thumb="$tbase/1542/tb.jpg" }
		@{ Name="Forest Mist";       Cat="Nature";   Url="$base/forest-mist.deskthemepack";      Thumb="$tbase/1108/tb.jpg" }
		@{ Name="Ocean Waves";       Cat="Nature";   Url="$base/ocean-waves.deskthemepack";      Thumb="$tbase/441/tb.jpg" }
		@{ Name="Galaxy 4K";         Cat="Espace";   Url="$base/galaxy-4k.deskthemepack";        Thumb="$tbase/1891/tb.jpg" }
		@{ Name="Nebula Space";      Cat="Espace";   Url="$base/nebula-space.deskthemepack";     Thumb="$tbase/2003/tb.jpg" }
		@{ Name="3D Visual Effects"; Cat="Abstrait"; Url="$base/3d-visual-effects.deskthemepack";Thumb="$tbase/1722/3d-visual-effects.jpg" }
		@{ Name="Abstraction";       Cat="Abstrait"; Url="$base/A%20b%20s%20t%20r%20a%20c%20t%20i%20o%20n%20Male.themepack";Thumb="$tbase/643/abstract-thb.jpg" }
		@{ Name="Dark Minimal";      Cat="Abstrait"; Url="$base/dark-minimal.deskthemepack";     Thumb="$tbase/2241/tb.jpg" }
		@{ Name="Neon Geometry";     Cat="Abstrait"; Url="$base/neon-geometry.deskthemepack";    Thumb="$tbase/1975/tb.jpg" }
		@{ Name="Tokyo Neon Night";  Cat="Urbain";   Url="$base/tokyo-neon-night.deskthemepack"; Thumb="$tbase/2088/tb.jpg" }
		@{ Name="City Skyline";      Cat="Urbain";   Url="$base/city-skyline.deskthemepack";     Thumb="$tbase/1654/tb.jpg" }
	)

	# ── Etat partagé (script: accessible dans toutes les closures) ────────────────
	# Selection stockée dans $form.Tag (hashtable mutable, capturée par toutes les closures)
	$script:themeActiveCat = "Tous"
	$script:themeDlDone    = $false
	$script:themeDlError   = $null

	# ── Fenetre principale ────────────────────────────────────────────────────────
	$form = New-Object System.Windows.Forms.Form
	$form.Text          = "Themes du Bureau"
	$form.Size          = New-Object System.Drawing.Size($fw, $fh)
	$form.BackColor     = $clrBg
	$form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
	$form.MinimumSize   = New-Object System.Drawing.Size(700, 480)
	# Stockage de la sélection dans form.Tag (accessible depuis toutes les closures via $form)
	$form.Tag = @{ SelTheme = $null; SelCard = $null }
	try {
		$form.GetType().GetProperty('DoubleBuffered',
			[System.Reflection.BindingFlags]'Instance,NonPublic').SetValue($form, $true, $null)
	} catch {}

	# ── Topbar ────────────────────────────────────────────────────────────────────
	$topBarH = 52
	$topBar  = New-Object System.Windows.Forms.Panel
	$topBar.BackColor = $clrTop
	$topBar.Height    = $topBarH
	$topBar.Left = 0; $topBar.Top = 0
	$form.Controls.Add($topBar)
	$lblTitle = New-Object System.Windows.Forms.Label
	$lblTitle.Text = " Themes du Bureau"
	$lblTitle.ForeColor = [System.Drawing.Color]::White
	$lblTitle.Font = $fontTitl; $lblTitle.AutoSize = $true; $lblTitle.Left = 14
	$topBar.Controls.Add($lblTitle)

	# ── Filterbar ────────────────────────────────────────────────────────────────
	$filterH   = 40
	$filterBar = New-Object System.Windows.Forms.Panel
	$filterBar.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59)
	$filterBar.Height = $filterH; $filterBar.Left = 0
	$form.Controls.Add($filterBar)

	# ── ContentPanel ─────────────────────────────────────────────────────────────
	$contentPanel = New-Object System.Windows.Forms.Panel
	$contentPanel.BackColor = $clrBg; $contentPanel.AutoScroll = $true; $contentPanel.Left = 0
	$form.Controls.Add($contentPanel)

	# ── Constantes cartes ─────────────────────────────────────────────────────────
	$numCols    = 3
	$cardGap    = 12
	$cardPad    = 14
	$thumbRatio = 0.62
	$badgeH     = 18
	$nameH      = 30
	$botBarH    = 70

	# ── $refreshGrid : scriptblock-closure (capture contentPanel + constantes) ────
	# Doit être défini APRES contentPanel et constantes, AVANT les filtres
	$refreshGrid = {
		param([string]$cat = "Tous")
		$availW = $contentPanel.ClientSize.Width
		if ($availW -le 10) { $availW = $contentPanel.Width }
		$scrollW = [System.Windows.Forms.SystemInformation]::VerticalScrollBarWidth
		$colW    = [int](($availW - $cardPad * 2 - $cardGap * ($numCols - 1) - $scrollW) / $numCols)
		if ($colW -le 10) { return }
		$thumbH  = [int]($colW * $thumbRatio)
		$cH      = $thumbH + $badgeH + $nameH + 4

		$col = 0; $row = 0
		foreach ($card in $contentPanel.Controls) {
			if (-not ($card -is [System.Windows.Forms.Panel])) { continue }
			$visible = ($cat -eq "Tous" -or $card.Tag.Cat -eq $cat)
			$card.Visible = $visible
			if ($visible) {
				$card.Left = $cardPad + $col * ($colW + $cardGap)
				$card.Top  = $cardPad + $row * ($cH   + $cardGap)
				$card.Width = $colW; $card.Height = $cH
				foreach ($c in $card.Controls) {
					if ($c -is [System.Windows.Forms.PictureBox]) {
						$c.Left=0;$c.Top=0;$c.Width=$colW;$c.Height=$thumbH
					} elseif ($c -is [System.Windows.Forms.Label] -and -not $c.AutoSize) {
						$c.Left=0;$c.Top=$thumbH+$badgeH+2;$c.Width=$colW;$c.Height=$nameH
					} elseif ($c -is [System.Windows.Forms.Label] -and $c.AutoSize) {
						$c.Left=6;$c.Top=$thumbH+2
					}
				}
				$col++
				if ($col -ge $numCols) { $col=0; $row++ }
			}
		}
		$vis = @($contentPanel.Controls | Where-Object { $_ -is [System.Windows.Forms.Panel] -and $_.Visible }).Count
		$rows = [int][Math]::Ceiling($vis / [float]$numCols)
		$contentPanel.AutoScrollMinSize = New-Object System.Drawing.Size(0, [int]($cardPad + $rows * ($cH + $cardGap)))
	}.GetNewClosure()   # <-- capture contentPanel, numCols, cardGap, cardPad, etc.

	# ── Boutons de filtre (captures $refreshGrid via .GetNewClosure()) ─────────────
	$categories = @("Tous", "Paysages", "Nature", "Espace", "Abstrait", "Urbain")
	$filterBtns = @{}

	foreach ($cat in $categories) {
		$fb = New-Object System.Windows.Forms.Button
		$fb.Text = $cat; $fb.Font = $fontBtn; $fb.Height = 28; $fb.AutoSize = $true
		$fb.Padding = New-Object System.Windows.Forms.Padding(10, 0, 10, 0)
		$fb.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
		$fb.FlatAppearance.BorderSize = 0; $fb.Cursor = [System.Windows.Forms.Cursors]::Hand
		if ($cat -eq "Tous") {
			$fb.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235)
			$fb.ForeColor = [System.Drawing.Color]::White
		} else {
			$fb.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59)
			$fb.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
		}
		$filterBtns[$cat] = $fb
		$filterBar.Controls.Add($fb)
		$catCapture = $cat
		$fb.Add_Click({
			$script:themeActiveCat = $catCapture
			foreach ($k in $filterBtns.Keys) {
				$b = $filterBtns[$k]
				if ($k -eq $catCapture) {
					$b.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235)
					$b.ForeColor = [System.Drawing.Color]::White
				} else {
					$b.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59)
					$b.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
				}
			}
			& $refreshGrid $catCapture
		}.GetNewClosure())   # capture $catCapture, $filterBtns, $refreshGrid
	}

	# ── Cartes : handler commun ───────────────────────────────────────────────────
	# .GetNewClosure() capture $contentPanel (défini avant)
	$globalClick = {
		param($s, $e)
		$ctrl = $s
		while ($null -ne $ctrl -and -not ($ctrl -is [System.Windows.Forms.Panel] -and $ctrl.Parent -eq $contentPanel)) {
			$ctrl = $ctrl.Parent
		}
		if ($null -eq $ctrl -or $null -eq $ctrl.Tag) { return }
		$prevCard = ($form.Tag)['SelCard']
		if ($null -ne $prevCard) {
			$prevCard.BackColor = [System.Drawing.Color]::White
			foreach ($c in $prevCard.Controls) {
				if ($c.BackColor -eq [System.Drawing.Color]::FromArgb(219, 234, 254)) {
					$c.BackColor = [System.Drawing.Color]::White
				}
			}
		}
		$ctrl.BackColor = [System.Drawing.Color]::FromArgb(219, 234, 254)
		foreach ($c in $ctrl.Controls) {
			if (-not ($c -is [System.Windows.Forms.Label] -and $c.AutoSize)) {
				$c.BackColor = [System.Drawing.Color]::FromArgb(219, 234, 254)
			}
		}
		($form.Tag)['SelTheme'] = $ctrl.Tag
		($form.Tag)['SelCard']  = $ctrl
	}.GetNewClosure()

	# ── Création des cartes ───────────────────────────────────────────────────────
	foreach ($t in $themes) {
		$card = New-Object System.Windows.Forms.Panel
		$card.BackColor = [System.Drawing.Color]::White
		$card.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
		$card.Tag = $t; $card.Cursor = [System.Windows.Forms.Cursors]::Hand

		$pb = New-Object System.Windows.Forms.PictureBox
		$pb.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
		$pb.BackColor = [System.Drawing.Color]::FromArgb(209, 213, 219)
		$pb.Left = 0; $pb.Top = 0; $pb.ImageLocation = $t.Thumb
		$card.Controls.Add($pb)

		$badge = New-Object System.Windows.Forms.Label
		$badge.Text = " $($t.Cat) "; $badge.Font = $fontSm
		$badge.ForeColor = [System.Drawing.Color]::White; $badge.AutoSize = $true
		$badge.BackColor = if ($catBadgeColors.ContainsKey($t.Cat)) { $catBadgeColors[$t.Cat] } else { $clrMuted }
		$card.Controls.Add($badge)

		$lbl = New-Object System.Windows.Forms.Label
		$lbl.Text = $t.Name; $lbl.Font = $fontBold; $lbl.ForeColor = $clrText
		$lbl.BackColor = [System.Drawing.Color]::White
		$lbl.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter; $lbl.AutoSize = $false
		$card.Controls.Add($lbl)

		$card.Add_Click($globalClick); $pb.Add_Click($globalClick); $lbl.Add_Click($globalClick)
		$contentPanel.Controls.Add($card)
	}

	# ── Barre inférieure ──────────────────────────────────────────────────────────
	$botBar = New-Object System.Windows.Forms.Panel
	$botBar.BackColor = $clrBot; $botBar.Left = 0; $botBar.Height = $botBarH
	$form.Controls.Add($botBar)
	$botBar.Add_Paint({
		param($s, $e)
		$pen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(229, 231, 235))
		$e.Graphics.DrawLine($pen, 0, 0, $s.Width, 0); $pen.Dispose()
	})

	$statusLbl = New-Object System.Windows.Forms.Label
	$statusLbl.Text = "Cliquez sur un theme pour le selectionner"
	$statusLbl.Font = $fontSm; $statusLbl.ForeColor = $clrMuted
	$statusLbl.AutoSize = $true; $statusLbl.Left = 14; $statusLbl.Top = 6
	$botBar.Controls.Add($statusLbl)

	# ── Boutons ───────────────────────────────────────────────────────────────────
	function New-FlatBtn ($text, $r, $g, $b, $rh, $gh, $bh, $w = 140) {
		$nc = [System.Drawing.Color]::FromArgb($r, $g, $b)
		$hc = [System.Drawing.Color]::FromArgb($rh, $gh, $bh)
		$btn = New-Object System.Windows.Forms.Button
		$btn.Text = $text; $btn.Width = $w; $btn.Height = 36; $btn.Font = $fontBtn
		$btn.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
		$btn.FlatAppearance.BorderSize = 0
		$btn.BackColor = $nc; $btn.ForeColor = [System.Drawing.Color]::White
		$btn.Cursor = [System.Windows.Forms.Cursors]::Hand
		$btn.Tag = [PSCustomObject]@{ N=$nc; H=$hc }
		$btn.Add_MouseEnter({ param($s,$e) $s.BackColor = $s.Tag.H })
		$btn.Add_MouseLeave({ param($s,$e) $s.BackColor = $s.Tag.N })
		return $btn
	}
	$btnApply  = New-FlatBtn "Appliquer"          22  163  74   16 140  60  140
	$btnStore  = New-FlatBtn "Boutique Microsoft"   2  132 199    2 110 175  155
	$btnRain   = New-FlatBtn "Rainmeter"           88   28 135   70  20 110  118
	$btnLively = New-FlatBtn "Lively Wallpaper"   194   65  12  170  50   8  140
	$btnClose  = New-FlatBtn "Fermer"              55   65  81   40  50  65  100
	$botBar.Controls.AddRange(@($btnApply, $btnStore, $btnRain, $btnLively, $btnClose))

	# ── $layoutTheme : scriptblock-closure (capture tout ce qui est défini ici) ───
	$layoutTheme = {
		$cliW  = $form.ClientSize.Width
		$cliH  = $form.ClientSize.Height

		$topBar.Width  = $cliW
		$filterBar.Top = $topBarH; $filterBar.Width = $cliW

		# Positionner les boutons de filtre
		$x = 10
		foreach ($cat in $categories) {
			$b = $filterBtns[$cat]
			$b.Top = [int](($filterH - $b.Height) / 2); $b.Left = $x
			$x += $b.Width + 6
		}

		$botBar.Top = $cliH - $botBarH; $botBar.Width = $cliW

		# Centrer les boutons d'action
		$allBtns = @($btnApply, $btnStore, $btnRain, $btnLively, $btnClose)
		$gap = 8
		$totalW = ($allBtns | ForEach-Object { $_.Width } | Measure-Object -Sum).Sum + ($allBtns.Count - 1) * $gap
		$x = [int](($cliW - $totalW) / 2); $y = [int](($botBarH - 36) / 2) + 10
		foreach ($b in $allBtns) { $b.Left = $x; $b.Top = $y; $x += $b.Width + $gap }

		$contentPanel.Top    = $topBarH + $filterH
		$contentPanel.Width  = $cliW
		$contentPanel.Height = $botBar.Top - $contentPanel.Top

		& $refreshGrid $script:themeActiveCat
	}.GetNewClosure()   # capture $form, $topBar, $filterBar, $botBar, $contentPanel, $refreshGrid, etc.

	# ── Actions ───────────────────────────────────────────────────────────────────
	$btnApply.Add_Click({
		$selTheme = ($form.Tag)['SelTheme']
		if ($null -eq $selTheme) {
			[System.Windows.Forms.MessageBox]::Show(
				"Cliquez d'abord sur un theme dans la grille.",
				"Aucune selection",
				[System.Windows.Forms.MessageBoxButtons]::OK,
				[System.Windows.Forms.MessageBoxIcon]::Information)
			return
		}
		$btnApply.Enabled = $false; $btnApply.Text = "Telechargement..."
		$statusLbl.Text = "Telechargement de $($selTheme.Name)..."
		[System.Windows.Forms.Application]::DoEvents()

		$dest = "$env:TEMP\theme.deskthemepack"
		$url  = $selTheme.Url
		$name = $selTheme.Name
		try {
			$script:themeDlDone = $false; $script:themeDlError = $null
			$wc = New-Object System.Net.WebClient
			$wc.Add_DownloadFileCompleted({ param($s2,$ev)
				$script:themeDlDone = $true; $script:themeDlError = $ev.Error
			})
			$wc.DownloadFileAsync([uri]$url, $dest)
			$elapsed = 0
			while (-not $script:themeDlDone) {
				[System.Windows.Forms.Application]::DoEvents()
				Start-Sleep -Milliseconds 150; $elapsed += 150
				if ($elapsed % 1000 -eq 0) {
					$statusLbl.Text = "Telechargement de $name... ($([int]($elapsed/1000))s)"
					[System.Windows.Forms.Application]::DoEvents()
				}
			}
			$wc.Dispose()
			if ($null -ne $script:themeDlError) { throw $script:themeDlError }
			$statusLbl.Text = "Application du theme..."; [System.Windows.Forms.Application]::DoEvents()
			Invoke-Item $dest
			$statusLbl.Text = "Theme '$name' applique."
			Add-Content -Path "$env:TEMP\logfile.txt" -Value "Theme $name applique." -ErrorAction SilentlyContinue
			if ($null -ne $textBox) { $textBox.AppendText("Theme '$name' applique.`r`n") }
		} catch {
			[System.Windows.Forms.MessageBox]::Show(
				"Echec pour '$name'.`nURL : $url`nErreur : $($_.Exception.Message)",
				"Erreur", [System.Windows.Forms.MessageBoxButtons]::OK,
				[System.Windows.Forms.MessageBoxIcon]::Warning)
			$statusLbl.Text = "Echec — verifiez que le fichier existe sur le serveur."
		} finally {
			$btnApply.Enabled = $true; $btnApply.Text = "Appliquer"
		}
	}.GetNewClosure())

	$btnStore.Add_Click({
		Start-Process "ms-windows-store://collection/?CollectionId=DesktopThemes" -ErrorAction SilentlyContinue
	})
	$btnRain.Add_Click({
		if ([System.Windows.Forms.MessageBox]::Show(
			"Rainmeter est GRATUIT et open-source.`nSkins, widgets, horloges, visualiseurs pour le bureau.`n`nInstaller via Winget ?",
			"Rainmeter", [System.Windows.Forms.MessageBoxButtons]::YesNo,
			[System.Windows.Forms.MessageBoxIcon]::Information) -eq [System.Windows.Forms.DialogResult]::Yes) {
			$statusLbl.Text = "Installation de Rainmeter..."
			[System.Windows.Forms.Application]::DoEvents()
			Start-Process winget -ArgumentList "install --id Rainmeter.Rainmeter --silent --accept-source-agreements --accept-package-agreements" -Wait -WindowStyle Hidden
			$statusLbl.Text = "Rainmeter installe."
		}
	}.GetNewClosure())
	$btnLively.Add_Click({
		if ([System.Windows.Forms.MessageBox]::Show(
			"Lively Wallpaper est GRATUIT et open-source.`nFonds animes : video, GIF, 3D, pages web...`n`nInstaller via Winget ?",
			"Lively Wallpaper", [System.Windows.Forms.MessageBoxButtons]::YesNo,
			[System.Windows.Forms.MessageBoxIcon]::Information) -eq [System.Windows.Forms.DialogResult]::Yes) {
			$statusLbl.Text = "Installation de Lively Wallpaper..."
			[System.Windows.Forms.Application]::DoEvents()
			Start-Process winget -ArgumentList "install --id rocksdanister.LivelyWallpaper --silent --accept-source-agreements --accept-package-agreements" -Wait -WindowStyle Hidden
			$statusLbl.Text = "Lively Wallpaper installe."
		}
	}.GetNewClosure())
	$btnClose.Add_Click({ $form.Close() })

	# ── Titre centré verticalement ─────────────────────────────────────────────────
	$lblTitle.Top = [int](($topBarH - $lblTitle.PreferredHeight) / 2)

	# ── Resize / Shown — capturent $layoutTheme via .GetNewClosure() ──────────────
	$form.Add_Resize({ & $layoutTheme }.GetNewClosure())
	$form.Add_Shown({  & $layoutTheme }.GetNewClosure())

	[void]$form.ShowDialog()
	$form.Dispose()
}


#7777777777777777777777777777777777777777777777777777777   Maj Windows Winget Choco ...  7777777777777777777777777777777777777777777777777777777777777
# Fonction commune : télécharge un script PS1 depuis une URL et l'exécute


#8888888888888888888888888888888888888888888888888888888888  Choix Logiciels Supplémentaires 88888888888888888888888888888888888888888888888888888888
function ChoixLogSupp
{Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ── Dimensions ──────────────────────────────────────────────────────────────
$screenW = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Width
$screenH = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Height
$winW    = [int]($screenW * 0.82)
$winH    = [int]($screenH * 0.88)

# ── Polices (Segoe UI, l'interface moderne Windows) ─────────────────────────
$fs       = [Math]::Max(8, [Math]::Min(11, [int]($screenH / 130)))
$fontUI   = New-Object System.Drawing.Font("Segoe UI", $fs)
$fontBold = New-Object System.Drawing.Font("Segoe UI Semibold", $fs)
$fontCat  = New-Object System.Drawing.Font("Segoe UI Semibold", ($fs + 1))
$fontTitl = New-Object System.Drawing.Font("Segoe UI", ($fs + 4), [System.Drawing.FontStyle]::Bold)
$fontBtn  = New-Object System.Drawing.Font("Segoe UI Semibold", $fs)
$fontSm   = New-Object System.Drawing.Font("Segoe UI", ($fs - 1))

# ── Palette de couleurs ──────────────────────────────────────────────────────
$clrBg      = [System.Drawing.Color]::FromArgb(243, 244, 246)
$clrCard    = [System.Drawing.Color]::White
$clrTopBar  = [System.Drawing.Color]::FromArgb(15, 23, 42)
$clrBotBar  = [System.Drawing.Color]::FromArgb(248, 249, 250)
$clrText    = [System.Drawing.Color]::FromArgb(17, 24, 39)
$clrMuted   = [System.Drawing.Color]::FromArgb(107, 114, 128)
$clrBorder  = [System.Drawing.Color]::FromArgb(229, 231, 235)

# Couleurs d'en-tête par catégorie
$catColors = [ordered]@{
    "Utilitaires Système"        = [System.Drawing.Color]::FromArgb(30, 64, 175)
    "Développement"              = [System.Drawing.Color]::FromArgb(21, 128, 61)
    "Multimédia"                 = [System.Drawing.Color]::FromArgb(109, 40, 217)
    "Sécurité"                   = [System.Drawing.Color]::FromArgb(185, 28, 28)
    "Communication"              = [System.Drawing.Color]::FromArgb(194, 65, 12)
    "Navigateurs"                = [System.Drawing.Color]::FromArgb(2, 132, 199)
    "Sauvegarde et Récupération" = [System.Drawing.Color]::FromArgb(15, 118, 110)
    "Utilitaires Pilotes"        = [System.Drawing.Color]::FromArgb(124, 45, 18)
}

# ── Données logiciels ────────────────────────────────────────────────────────
$utilitairesSysteme = @{
    "QuickLook"                = "QL-Win.QuickLook"
    "Microsoft PowerToys"      = "Microsoft.PowerToys"
    "CCleaner"                 = "Piriform.CCleaner"
    "7-Zip"                    = "7zip.7zip"
    "WinRAR"                   = "RARLab.WinRAR"
    "Sysinternals Suite"       = "Microsoft.Sysinternals.Suite"
    "Geek Uninstaller"         = "GeekUninstaller.GeekUninstaller"
    "Revo Uninstaller"         = "RevoUninstaller.RevoUninstaller"
    "WinMerge"                 = "WinMerge.WinMerge"
    "CDBurnerXP"               = "Canneverbe.CDBurnerXP"
    "Defraggler"               = "Piriform.Defraggler"
    "Speccy"                   = "Piriform.Speccy"
    "Glary Utilities"          = "Glarysoft.GlaryUtilities"
    "Advanced SystemCare"      = "IObit.AdvancedSystemCare"
    "Process Explorer"         = "Microsoft.Sysinternals.ProcessExplorer"
    "CPU-Z"                    = "CPUID.CPU-Z"
    "GPU-Z"                    = "TechPowerUp.GPU-Z"
    "CrystalDiskInfo"          = "CrystalDewWorld.CrystalDiskInfo"
    "CrystalDiskMark"          = "CrystalDewWorld.CrystalDiskMark"
    "Driver Booster"           = "IObit.DriverBooster"
    "IObit Uninstaller"        = "IObit.Uninstaller"
    "HWMonitor"                = "CPUID.HWMonitor"
    "Everything"               = "voidtools.Everything"
    "Total Commander"          = "Ghisler.TotalCommander"
    "FreeCommander XE"         = "MarekJasinski.FreeCommanderXE"
    "Directory Opus"           = "GPSoftware.DirectoryOpus"
    "UniGetUI"                 = "MartiCliment.UniGetUI"
    "Evernote"                 = "Evernote.Evernote"
    "Nextcloud"                = "Nextcloud.NextcloudDesktop"
    "LibreOffice"              = "TheDocumentFoundation.LibreOffice"
    "Notion"                   = "Notion.Notion"
    "Todoist"                  = "Doist.Todoist"
    "OneNote"                  = "Microsoft.Office.OneNote"
    "Xodo PDF Reader & Editor" = "Apryse.XodoPDFReader"
    "Hekasoft Backup&Rest."    = "Hekasoft.Backup-Restore"
}

$securite = @{
    "Malwarebytes"    = "Malwarebytes.Malwarebytes"
    "ESET Security"   = "ESET.Security"
    "Kaspersky"       = "Kaspersky.SecurityCloud"
    "VeraCrypt"       = "IDRIX.VeraCrypt"
    "KeePassXC"       = "KeePassXCTeam.KeePassXC"
    "Bitdefender"     = "Bitdefender.Bitdefender"
    "Avast Antivirus" = "Avast.Avast"
    "AVG Antivirus"   = "AVG.AVG"
    "1Password"       = "AgileBits.1Password"
    "Dashlane"        = "Dashlane.Dashlane"
    "LastPass"        = "LogMeIn.LastPass"
    "KeeWeb"          = "KeeWeb.KeeWeb"
    "Tailscale"       = "Tailscale.Tailscale"
    "OpenVPN"         = "OpenVPNTechnologies.OpenVPN"
}

$navigateurs = @{
    "Brave"          = "Brave.Brave"
    "Cyberduck"      = "Iterate.Cyberduck"
    "Google Chrome"  = "Google.Chrome"
    "Microsoft Edge" = "Microsoft.Edge"
    "Mozilla Firefox"= "Mozilla.Firefox"
    "Opera GX"       = "Opera.OperaGX"
    "Tor Browser"    = "TorProject.TorBrowser"
}

$developpement = @{
    "Visual Studio Code"       = "Microsoft.VisualStudioCode"
    "JetBrains Toolbox"        = "JetBrains.Toolbox"
    "Python"                   = "Python.Python.3"
    "Git"                      = "Git.Git"
    "Docker Desktop"           = "Docker.DockerDesktop"
    "GitHub Desktop"           = "GitHub.GitHubDesktop"
    "Node.js"                  = "OpenJS.NodeJS"
    "Java Runtime Environment" = "Oracle.JavaRuntimeEnvironment"
    "Postman"                  = "Postman.Postman"
    "Anaconda"                 = "Anaconda.Anaconda3"
    "Sublime Text"             = "SublimeHQ.SublimeText.4"
    "IntelliJ IDEA"            = "JetBrains.IntelliJ.IDEA.Ultimate"
    "PyCharm"                  = "JetBrains.PyCharm.Professional"
    "WebStorm"                 = "JetBrains.WebStorm"
    "Rider"                    = "JetBrains.Rider"
    "CLion"                    = "JetBrains.CLion"
    "RubyMine"                 = "JetBrains.RubyMine"
    "PhpStorm"                 = "JetBrains.PhpStorm"
    "Eclipse IDE"              = "EclipseFoundation.Eclipse.Java"
    "NetBeans IDE"             = "Apache.NetBeans"
    "Android Studio"           = "Google.AndroidStudio"
    "Vagrant"                  = "HashiCorp.Vagrant"
    "XAMPP"                    = "ApacheFriends.Xampp"
    "MAMP"                     = "MAMP.MAMP"
}

$multimedia = @{
    "VLC media player"   = "VideoLAN.VLC"
    "GIMP"               = "GIMP.GIMP"
    "Audacity"           = "Audacity.Audacity"
    "OBS Studio"         = "OBSProject.OBSStudio"
    "HandBrake"          = "HandBrake.HandBrake"
    "Shotcut"            = "Meltytech.Shotcut"
    "Krita"              = "KDE.Krita"
    "Inkscape"           = "Inkscape.Inkscape"
    "Blender"            = "BlenderFoundation.Blender"
    "Paint.NET"          = "dotPDNLLC.Paint.NET"
    "Adobe Reader"       = "Adobe.Acrobat.Reader.64-bit"
    "Foxit Reader"       = "Foxit.FoxitReader"
    "PDF-XChange Editor" = "TrackerSoftware.PDF-XChangeEditor"
    "SumatraPDF"         = "SumatraPDF.SumatraPDF"
    "WinZip"             = "Corel.WinZip"
}

$communication = @{
    "Discord"            = "Discord.Discord"
    "Slack"              = "SlackTechnologies.Slack"
    "Telegram Desktop"   = "Telegram.TelegramDesktop"
    "Skype"              = "Microsoft.Skype"
    "TeamViewer"         = "TeamViewer.TeamViewer"
    "TightVNC"           = "GlavSoft.TightVNC"
    "AnyDesk"            = "AnyDeskSoftwareGmbH.AnyDesk"
    "Remote Desktop Mgr" = "Devolutions.RemoteDesktopManager"
    "RealVNC"            = "RealVNC.VNCViewer"
    "TeamSpeak"          = "TeamSpeakSystems.TeamSpeakClient"
}

$sauvegardeRecuperation = @{
    "Recuva"                    = "Piriform.Recuva"
    "AOMEI Backupper"           = "AOMEI.Backupper"
    "MiniTool Partition Wizard" = "MiniTool.PartitionWizard.Free"
}

$utilitairesPilotes = @{
    "Driver Booster"          = "IObit.DriverBooster"
    "Driver Easy"             = "Easeware.DriverEasy"
    "Driver Store Explorer"   = "lostindark.DriverStoreExplorer"
    "Snappy Driver Installer" = "samlab-ws.SnappyDriverInstaller"
}

$logiciels = [ordered]@{
    "Utilitaires Système"        = $utilitairesSysteme
    "Développement"              = $developpement
    "Multimédia"                 = $multimedia
    "Sécurité"                   = $securite
    "Communication"              = $communication
    "Navigateurs"                = $navigateurs
    "Sauvegarde et Récupération" = $sauvegardeRecuperation
    "Utilitaires Pilotes"        = $utilitairesPilotes
}

# Répartition équilibrée (~36 items / colonne)
$colCategories = @(
    @("Utilitaires Système", "Sauvegarde et Récupération"),
    @("Développement", "Communication", "Utilitaires Pilotes"),
    @("Multimédia", "Sécurité", "Navigateurs")
)

# ── Fenêtre principale ────────────────────────────────────────────────────────
$fenetre = New-Object System.Windows.Forms.Form
$fenetre.Text            = "Gestionnaire de Logiciels"
$fenetre.Size            = New-Object System.Drawing.Size($winW, $winH)
$fenetre.BackColor       = $clrBg
$fenetre.StartPosition   = [System.Windows.Forms.FormStartPosition]::CenterScreen
$fenetre.MinimumSize     = New-Object System.Drawing.Size(860, 540)

# Double-buffering via réflexion (réduit le scintillement)
try {
    $fenetre.GetType().GetProperty('DoubleBuffered',
        [System.Reflection.BindingFlags]'Instance,NonPublic').SetValue($fenetre, $true, $null)
} catch {}

# ── Helper : tous les CheckBox d'un container (récursif) ─────────────────────
function Get-AllCheckBoxes {
    param ([System.Windows.Forms.Control]$container)
    $list = New-Object System.Collections.Generic.List[System.Windows.Forms.CheckBox]
    foreach ($ctrl in $container.Controls) {
        if ($ctrl -is [System.Windows.Forms.CheckBox]) { $list.Add($ctrl) }
        elseif ($ctrl.Controls.Count -gt 0) {
            foreach ($sub in (Get-AllCheckBoxes -container $ctrl)) { $list.Add($sub) }
        }
    }
    return $list
}

# ── Helper : mise à jour du compteur de sélection (Optimisée) ────────────────
function Update-Counter {
    if ($script:bulkOp) { return }
    $n = 0
    foreach ($cb in $script:allCheckBoxes) {
        if ($cb.Checked) { $n++ }
    }
    $script:lblCounter.Text = if ($n -eq 0) { "Aucune sélection" } else { "$n logiciel(s) sélectionné(s)" }
}

# ── Barre de menu ─────────────────────────────────────────────────────────────
$menuStrip = New-Object System.Windows.Forms.MenuStrip

$fileMenu = New-Object System.Windows.Forms.ToolStripMenuItem
$fileMenu.Text = "Fichier"
$exportMenuItem = New-Object System.Windows.Forms.ToolStripMenuItem
$exportMenuItem.Text = "Exporter la sélection"
$fileMenu.DropDownItems.Add($exportMenuItem) | Out-Null
$exitMenuItem = New-Object System.Windows.Forms.ToolStripMenuItem
$exitMenuItem.Text = "Quitter"
$exitMenuItem.Add_Click({ $fenetre.Close() })
$fileMenu.DropDownItems.Add($exitMenuItem) | Out-Null

$toolsMenu = New-Object System.Windows.Forms.ToolStripMenuItem
$toolsMenu.Text = "Outils"
$verifyIdsMenuItem = New-Object System.Windows.Forms.ToolStripMenuItem
$verifyIdsMenuItem.Text = "Vérifier les IDs Winget"
$toolsMenu.DropDownItems.Add($verifyIdsMenuItem) | Out-Null

$menuStrip.Items.Add($fileMenu)  | Out-Null
$menuStrip.Items.Add($toolsMenu) | Out-Null
$fenetre.MainMenuStrip = $menuStrip
$fenetre.Controls.Add($menuStrip)

# ── Barre supérieure (titre + recherche + compteur) ───────────────────────────
$topBarH = 54
$topBar  = New-Object System.Windows.Forms.Panel
$topBar.BackColor = $clrTopBar
$topBar.Height    = $topBarH
$topBar.Left      = 0
$fenetre.Controls.Add($topBar)

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text      = " Gestionnaire de Logiciels Supplémentaires"
$lblTitle.ForeColor = [System.Drawing.Color]::White
$lblTitle.Font      = $fontTitl
$lblTitle.AutoSize  = $true
$lblTitle.Left      = 14
$topBar.Controls.Add($lblTitle)

$lblCounter = New-Object System.Windows.Forms.Label
$lblCounter.Text      = "Aucune sélection"
$lblCounter.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
$lblCounter.Font      = $fontBold
$lblCounter.AutoSize  = $true
$topBar.Controls.Add($lblCounter)

# Renseignement du Label Compteur dans le scope script
$script:lblCounter = $lblCounter

$searchBox = New-Object System.Windows.Forms.TextBox
$searchBox.Width       = 220
$searchBox.Height      = 26
$searchBox.Font        = $fontUI
$searchBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$topBar.Controls.Add($searchBox)

$searchHint = New-Object System.Windows.Forms.Label
$searchHint.Text      = "  Rechercher un logiciel..."
$searchHint.ForeColor = $clrMuted
$searchHint.BackColor = [System.Drawing.Color]::White
$searchHint.Font      = $fontUI
$searchHint.AutoSize  = $false
$searchHint.Size      = New-Object System.Drawing.Size(220, 26)
$searchHint.Add_Click({ $searchHint.Visible = $false; $searchBox.Focus() })
$searchBox.Add_GotFocus({  $searchHint.Visible = $false })
$searchBox.Add_LostFocus({ if ($searchBox.Text -eq "") { $searchHint.Visible = $true } })
$topBar.Controls.Add($searchHint)

# ── Panel de contenu défilant ─────────────────────────────────────────────────
$contentPanel = New-Object System.Windows.Forms.Panel
$contentPanel.BackColor  = $clrBg
$contentPanel.AutoScroll = $true
$contentPanel.Left       = 0
$fenetre.Controls.Add($contentPanel)

# ── Barre d'actions (boutons) ─────────────────────────────────────────────────
$botBarH = 60
$botBar  = New-Object System.Windows.Forms.Panel
$botBar.BackColor = $clrBotBar
$botBar.Left      = 0
$botBar.Height    = $botBarH
$fenetre.Controls.Add($botBar)

$botBar.Add_Paint({
    param($s, $e)
    $pen = New-Object System.Drawing.Pen($clrBorder, 1)
    $e.Graphics.DrawLine($pen, 0, 0, $s.Width, 0)
    $pen.Dispose()
})

function New-ActionBtn ($label, $r, $g, $b, $rh, $gh, $bh) {
    $nc  = [System.Drawing.Color]::FromArgb($r, $g, $b)
    $hc  = [System.Drawing.Color]::FromArgb($rh, $gh, $bh)
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text      = $label
    $btn.Width     = 132
    $btn.Height    = 38
    $btn.Font      = $fontBtn
    $btn.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $btn.FlatAppearance.BorderSize          = 0
    $btn.FlatAppearance.MouseOverBackColor  = $hc
    $btn.BackColor = $nc
    $btn.ForeColor = [System.Drawing.Color]::White
    $btn.Cursor    = [System.Windows.Forms.Cursors]::Hand
    $btn.Tag       = [PSCustomObject]@{ N = $nc; H = $hc }
    $btn.Add_MouseEnter({ param($s, $e) $s.BackColor = $s.Tag.H })
    $btn.Add_MouseLeave({ param($s, $e) $s.BackColor = $s.Tag.N })
    return $btn
}

$btnInstall  = New-ActionBtn "[ Installer ]"      22  163  74    16  140  60
$btnDesinst  = New-ActionBtn "[ Desinstaller ]"   220  38  38   200   30  30
$btnSelAll   = New-ActionBtn "[ Tout cocher ]"     37  99 235    29   78 216
$btnDeselAll = New-ActionBtn "[ Tout decocher ]"  107 114 128    85   90 103
$btnClose    = New-ActionBtn "[ Fermer ]"          55  65  81    40   50  65

$botBar.Controls.AddRange(@($btnInstall, $btnDesinst, $btnSelAll, $btnDeselAll, $btnClose))

# ── Barre de statut ───────────────────────────────────────────────────────────
$statusStrip = New-Object System.Windows.Forms.StatusStrip
$statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$statusLabel.Text = "Prêt"
$statusStrip.Items.Add($statusLabel) | Out-Null
$fenetre.Controls.Add($statusStrip)

# ── Constantes de disposition des colonnes ────────────────────────────────────
$numCols    = 3
$pad        = 12
$colGap     = 10
$rowGap     = 12
$catHeaderH = 34
$cbRowH     = 24
$cbPadLeft  = 12
$catPadBot  = 8

# ── Création des cartes de catégories ─────────────────────────────────────────
foreach ($colIdx in 0..($numCols - 1)) {
    $currentY = $pad
    foreach ($catName in $colCategories[$colIdx]) {
        $catItems = $logiciels[$catName]
        if ($null -eq $catItems) { continue }

        $sortedItems = $catItems.GetEnumerator() | Sort-Object Name
        $itemCount   = @($sortedItems).Count
        $cardH       = $catHeaderH + ($itemCount * $cbRowH) + $catPadBot

        $card             = New-Object System.Windows.Forms.Panel
        $card.BackColor   = $clrCard
        $card.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
        $card.Top         = $currentY
        $card.Left        = $pad
        $card.Width       = 200
        $card.Height      = $cardH
        $card.Tag         = [int]$colIdx
        $contentPanel.Controls.Add($card)

        $hdrPanel             = New-Object System.Windows.Forms.Panel
        $hdrPanel.BackColor   = $catColors[$catName]
        $hdrPanel.Left        = 0
        $hdrPanel.Top         = 0
        $hdrPanel.Height      = $catHeaderH
        $hdrPanel.Width       = 200
        $hdrPanel.Anchor      = [System.Windows.Forms.AnchorStyles]::Left `
                            -bor [System.Windows.Forms.AnchorStyles]::Top `
                            -bor [System.Windows.Forms.AnchorStyles]::Right
        $card.Controls.Add($hdrPanel)

        $lblCat           = New-Object System.Windows.Forms.Label
        $lblCat.Text      = "  $catName"
        $lblCat.ForeColor = [System.Drawing.Color]::White
        $lblCat.Font      = $fontCat
        $lblCat.AutoSize  = $false
        $lblCat.Dock      = [System.Windows.Forms.DockStyle]::Fill
        $lblCat.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
        $hdrPanel.Controls.Add($lblCat)

        $itemY = $catHeaderH + 4
        foreach ($item in $sortedItems) {
            $cb           = New-Object System.Windows.Forms.CheckBox
            $cb.Text      = $item.Name
            $cb.Tag       = $item.Value
            $cb.Font      = $fontUI
            $cb.ForeColor = $clrText
            $cb.BackColor = $clrCard
            $cb.AutoSize  = $true
            $cb.Left      = $cbPadLeft
            $cb.Top       = $itemY
            $cb.Add_CheckedChanged({ Update-Counter })
            $card.Controls.Add($cb)
            $itemY += $cbRowH
        }

        $currentY += $cardH + $rowGap
    }
}

# ── Cache plat en portée script (Placé ici APRÈS la création des cartes) ──────
$script:allCheckBoxes = @(Get-AllCheckBoxes -container $contentPanel)
$script:bulkOp = $false

# ── Fonction de mise en page (appelée au Show et Resize) ─────────────────────
function Layout-All {
    $menuH = $menuStrip.Height
    $statH = $statusStrip.Height
    $cliW  = $fenetre.ClientSize.Width
    $cliH  = $fenetre.ClientSize.Height

    $topBar.Top   = $menuH
    $topBar.Width = $cliW

    $lblTitle.Top   = [int](($topBarH - $lblTitle.PreferredHeight) / 2)
    $searchBox.Top  = [int](($topBarH - $searchBox.Height) / 2)
    $searchBox.Left = $cliW - $searchBox.Width - 14
    $searchHint.Top  = $searchBox.Top
    $searchHint.Left = $searchBox.Left
    $lblCounter.Top  = [int](($topBarH - $lblCounter.PreferredHeight) / 2)
    $lblCounter.Left = $searchBox.Left - $lblCounter.PreferredWidth - 20

    $botBar.Top   = $cliH - $botBarH - $statH
    $botBar.Width = $cliW

    $btnList = @($btnInstall, $btnDesinst, $btnSelAll, $btnDeselAll, $btnClose)
    $gap     = 8
    $totalW  = ($btnList.Count * 132) + (($btnList.Count - 1) * $gap)
    $startX  = [int](($cliW - $totalW) / 2)
    $btnY    = [int](($botBarH - 38) / 2)
    $xPos    = $startX
    foreach ($b in $btnList) {
        $b.Left = $xPos; $b.Top = $btnY
        $xPos += 132 + $gap
    }

    $contentPanel.Top    = $topBar.Bottom
    $contentPanel.Width  = $cliW
    $contentPanel.Height = $botBar.Top - $topBar.Bottom

    $scrollW = [System.Windows.Forms.SystemInformation]::VerticalScrollBarWidth
    $availW  = $contentPanel.ClientSize.Width
    if ($availW -le 10) { $availW = $cliW - $scrollW }
    $colW = [int](($availW - $pad * 2 - $colGap * ($numCols - 1)) / $numCols)

    foreach ($ctrl in $contentPanel.Controls) {
        if ($ctrl -is [System.Windows.Forms.Panel] -and $ctrl.Tag -is [int]) {
            $ci        = [int]$ctrl.Tag
            $ctrl.Left  = $pad + $ci * ($colW + $colGap)
            $ctrl.Width = $colW
            foreach ($child in $ctrl.Controls) {
                if ($child -is [System.Windows.Forms.Panel]) {
                    $child.Width = $colW - 2
                }
            }
        }
    }
}

# ── Recherche en temps réel ───────────────────────────────────────────────────
$searchBox.Add_TextChanged({
    $q = $searchBox.Text.ToLower().Trim()
    foreach ($cb in $script:allCheckBoxes) {
        $cb.Visible = ($q -eq "" -or $cb.Text.ToLower().Contains($q))
    }
})

# ── Fonctions d'installation / désinstallation (Corrigées, non bloquantes) ────
function Install-Software {
    param ([string]$softwareName, [string]$wingetID)
    try {
        $cmdArgs = if ($wingetID -match "^(.+?)(\s+--\S+.*)$") {
            "install --id $($matches[1]) $($matches[2]) --silent --accept-source-agreements --accept-package-agreements"
        } else {
            "install --id $wingetID --silent --accept-source-agreements --accept-package-agreements"
        }
        $proc = Start-Process winget -ArgumentList $cmdArgs -PassThru -WindowStyle Hidden -ErrorAction Stop
        while (-not $proc.HasExited) {
            [System.Windows.Forms.Application]::DoEvents()
            [System.Threading.Thread]::Sleep(100)
        }
        return ($proc.ExitCode -eq 0)
    } catch { return $false }
}

function Uninstall-Software {
    param ([string]$softwareName, [string]$wingetID)
    try {
        $proc = Start-Process winget -ArgumentList "uninstall --id $wingetID --silent --accept-source-agreements" -PassThru -WindowStyle Hidden -ErrorAction Stop
        while (-not $proc.HasExited) {
            [System.Windows.Forms.Application]::DoEvents()
            [System.Threading.Thread]::Sleep(100)
        }
        return ($proc.ExitCode -eq 0)
    } catch { return $false }
}

# ── Opération en lot avec fenêtre de progression (Sécurisée) ───────────────────
function Run-BulkOperation {
    param ([string]$mode)   # "install" ou "uninstall"
    $opLabel  = if ($mode -eq "install") { "Installation" } else { "Désinstallation" }
    
    $selected = @()
    foreach ($cb in $script:allCheckBoxes) {
        if ($cb.Checked) { $selected += $cb }
    }
    $total = $selected.Count

    if ($total -eq 0) {
        [System.Windows.Forms.MessageBox]::Show($fenetre,
            "Aucun logiciel sélectionné.", "Information",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information)
        return
    }

    # Désactiver les boutons pendant l'opération (évite re-entrancy dans DoEvents)
    $btnInstall.Enabled = $false
    $btnDesinst.Enabled = $false
    $btnSelAll.Enabled  = $false
    $btnDeselAll.Enabled = $false

    try {

    $pForm = New-Object System.Windows.Forms.Form
    $pForm.Text            = "$opLabel en cours..."
    $pForm.Size            = New-Object System.Drawing.Size(460, 175)
    $pForm.StartPosition   = [System.Windows.Forms.FormStartPosition]::CenterScreen
    $pForm.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $pForm.MaximizeBox = $false; $pForm.MinimizeBox = $false
    $pForm.BackColor = [System.Drawing.Color]::White

    $pLabel = New-Object System.Windows.Forms.Label
    $pLabel.Location = New-Object System.Drawing.Point(14, 16)
    $pLabel.Size     = New-Object System.Drawing.Size(420, 22)
    $pLabel.Font     = $fontBold
    $pLabel.Text     = "Préparation..."
    $pForm.Controls.Add($pLabel)

    $pBar = New-Object System.Windows.Forms.ProgressBar
    $pBar.Location  = New-Object System.Drawing.Point(14, 48)
    $pBar.Size      = New-Object System.Drawing.Size(420, 22)
    $pBar.Minimum = 0; $pBar.Maximum = $total; $pBar.Value = 0
    $pBar.Style = [System.Windows.Forms.ProgressBarStyle]::Continuous
    $pForm.Controls.Add($pBar)

    $pSub = New-Object System.Windows.Forms.Label
    $pSub.Location  = New-Object System.Drawing.Point(14, 80)
    $pSub.Size      = New-Object System.Drawing.Size(420, 20)
    $pSub.Font      = $fontSm
    $pSub.ForeColor = $clrMuted
    $pSub.Text      = ""
    $pForm.Controls.Add($pSub)

    $pPct = New-Object System.Windows.Forms.Label
    $pPct.Location  = New-Object System.Drawing.Point(14, 106)
    $pPct.Size      = New-Object System.Drawing.Size(420, 20)
    $pPct.Font      = $fontSm
    $pPct.ForeColor = $clrMuted
    $pPct.Text      = "0 / $total"
    $pForm.Controls.Add($pPct)

    $pForm.Show($fenetre); $pForm.Refresh()

    $ok = 0; $ko = 0; $cur = 0

    try {
        foreach ($cb in $selected) {
            $cur++
            $pLabel.Text = "$opLabel de $($cb.Text)..."
            $pSub.Text   = "ID : $($cb.Tag)"
            $pPct.Text   = "$cur / $total"

            # Marquee avant le lancement (animation = winget est en cours)
            $pBar.Style = [System.Windows.Forms.ProgressBarStyle]::Marquee
            $pBar.MarqueeAnimationSpeed = 25
            $pForm.Refresh()

            if ($mode -eq "install") {
                $r = Install-Software   -softwareName $cb.Text -wingetID $cb.Tag
            } else {
                $r = Uninstall-Software -softwareName $cb.Text -wingetID $cb.Tag
            }
            if ($r) { $ok++ } else { $ko++ }
            try { $jd=Join-Path $env:ProgramData "MultInstall"; if(-not(Test-Path $jd)){New-Item $jd -ItemType Directory -Force -ErrorAction SilentlyContinue|Out-Null}; $act=$(if($mode -eq "install"){"Installe (supp): "}else{"Desinstalle (supp): "}); $st=$(if($r){""}else{" [ECHEC]"}); Add-Content -Path (Join-Path $jd "journal.txt") -Value ("["+(Get-Date -Format "dd/MM HH:mm")+"] "+$act+$cb.Text+$st) -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}

            # Barre de progression normale après chaque install
            $pBar.Style = [System.Windows.Forms.ProgressBarStyle]::Continuous
            $pBar.Value = $cur
            $pLabel.Text = if ($r) { "✓  $($cb.Text)" } else { "✗  $($cb.Text) (échec)" }
            $pForm.Refresh()
        }
    } finally {
        $pForm.Close()
    }

    [System.Windows.Forms.MessageBox]::Show($fenetre,
        "$opLabel terminée`n`n  Réussies : $ok`n  Échouées : $ko",
        "Résultat", [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information)

    } finally {
        # Réactiver les boutons dans tous les cas (y compris si exception)
        $btnInstall.Enabled  = $true
        $btnDesinst.Enabled  = $true
        $btnSelAll.Enabled   = $true
        $btnDeselAll.Enabled = $true
    }
}

# ── Branchement des boutons ───────────────────────────────────────────────────
$btnInstall.Add_Click({  Run-BulkOperation "install"   })
$btnDesinst.Add_Click({  Run-BulkOperation "uninstall" })
$btnSelAll.Add_Click({
    $script:bulkOp = $true
    foreach ($cb in $script:allCheckBoxes) {
        if ($cb.Visible) { $cb.Checked = $true }
    }
    $script:bulkOp = $false
    Update-Counter
})
$btnDeselAll.Add_Click({
    $script:bulkOp = $true
    foreach ($cb in $script:allCheckBoxes) { $cb.Checked = $false }
    $script:bulkOp = $false
    Update-Counter
})
$btnClose.Add_Click({ $fenetre.Close() })

# ── Export ───────────────────────────────────────────────────────────────────
$exportMenuItem.Add_Click({
    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    $dlg.Filter = "Fichier texte (*.txt)|*.txt"
    $dlg.FileName = "logiciels_selectionnes.txt"
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $lines = @("# Logiciels sélectionnés — $(Get-Date -Format 'yyyy-MM-dd HH:mm')", "")
        foreach ($cb in $script:allCheckBoxes) {
            if ($cb.Checked) {
                $lines += "$($cb.Text) : winget install --id $($cb.Tag)"
            }
        }
        $lines | Out-File -FilePath $dlg.FileName -Encoding utf8
        [System.Windows.Forms.MessageBox]::Show($fenetre, "Export réussi.", "OK",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information)
    }
})

# ── Vérification des IDs Winget ───────────────────────────────────────────────
$verifyIdsMenuItem.Add_Click({
    $statusLabel.Text = "Vérification des IDs en cours..."
    $fenetre.Refresh()
    $invalid = @()
    foreach ($cat in $logiciels.Keys) {
        foreach ($entry in $logiciels[$cat].GetEnumerator()) {
            $out = & winget search --id $entry.Value --exact 2>&1
            if (-not ($out -match $entry.Value)) { $invalid += "$($entry.Name) : $($entry.Value)" }
        }
    }
    if ($invalid.Count -gt 0) {
        [System.Windows.Forms.MessageBox]::Show($fenetre,
            "IDs potentiellement invalides :`n`n" + ($invalid -join "`n"),
            "Vérification", [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning)
    } else {
        [System.Windows.Forms.MessageBox]::Show($fenetre, "Tous les IDs sont valides.", "OK",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information)
    }
    $statusLabel.Text = "Vérification terminée."
})

# ── Événements Resize et Shown ────────────────────────────────────────────────
$fenetre.Add_Resize({ Layout-All })
$fenetre.Add_Shown({
    Layout-All
    $lblTitle.Top = [int](($topBarH - $lblTitle.PreferredHeight) / 2)

    # Vérification de winget (Get-Command = instantané, pas de lancement de process)
    $wg = Get-Command winget -ErrorAction SilentlyContinue
    if ($null -eq $wg) {
        [System.Windows.Forms.MessageBox]::Show($fenetre,
            "Winget n'est pas installé sur ce système.", "Erreur",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error)
        $fenetre.Close(); return
    }
    $statusLabel.Text = "Prêt — winget disponible"

    # Avertissement si non-admin
    if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        $statusLabel.Text = "⚠ Non-administrateur — certaines installations peuvent échouer"
    }
})

# ── Afficher la fenêtre ───────────────────────────────────────────────────────
[void]$fenetre.ShowDialog()
}
#9999999999999999999999999999999999999999999999999999999999 onedrive degage   9999999999999999999999999999999999999999999999999999999999999999999
function onedriveoff
{
	# Désinstallation complète de OneDrive pour Windows 10/11
	function Log-OD { param($msg) $textBox.AppendText("$msg`r`n"); [System.Windows.Forms.Application]::DoEvents() }

	# Vérification préalable
	$odRunning = Get-Process -Name "OneDrive" -ErrorAction SilentlyContinue
	if (-not $odRunning -and -not (Test-Path "$env:LocalAppData\Microsoft\OneDrive")) {
		$textBox.AppendText("OneDrive ne semble pas installé sur ce poste.`r`n")
		return
	}

	# 1. Arrêter tous les processus OneDrive
	Log-OD "1/9 — Arrêt des processus OneDrive..."
	foreach ($proc in @("OneDrive", "OneDriveSetup", "FileCoAuth"))
	{
		Get-Process -Name $proc -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
	}
	Stop-Process -Name "explorer" -Force -ErrorAction SilentlyContinue
	Start-Sleep -Milliseconds 800

	# 2. Désinstaller OneDrive via le setup natif
	Log-OD "2/9 — Désinstallation de OneDrive..."
	$setupFound = $false
	foreach ($setup in @("$env:SystemRoot\SysWOW64\OneDriveSetup.exe", "$env:SystemRoot\System32\OneDriveSetup.exe"))
	{
		if (Test-Path $setup)
		{
			$proc = Start-Process -FilePath $setup -ArgumentList "/uninstall" -PassThru -NoNewWindow
			while (-not $proc.HasExited) {
				[System.Windows.Forms.Application]::DoEvents()
				Start-Sleep -Milliseconds 200
			}
			$setupFound = $true
			break
		}
	}

	# 3. Fallback : désinstallation via winget
	if (-not $setupFound)
	{
		Log-OD "3/9 — Setup natif introuvable, tentative via winget..."
		if (Get-Command winget -ErrorAction SilentlyContinue)
		{
			$proc = Start-Process winget -ArgumentList "uninstall --id Microsoft.OneDrive --silent --accept-source-agreements" -PassThru -WindowStyle Hidden
			while (-not $proc.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 200 }
		}
	} else { Log-OD "   Désinstallation terminée." }

	# 4. Supprimer les fichiers résiduels
	Log-OD "4/9 — Suppression des fichiers résiduels..."
	foreach ($path in @(
		"$env:LocalAppData\Microsoft\OneDrive",
		"$env:ProgramData\Microsoft OneDrive",
		"$env:SystemDrive\OneDriveTemp"
	))
	{
		if (Test-Path $path) {
			Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue
			Log-OD "   Supprimé : $path"
		}
	}
	# Dossier OneDrive utilisateur — uniquement si vide
	if ((Get-ChildItem "$env:UserProfile\OneDrive" -Recurse -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0)
	{
		Remove-Item -Path "$env:UserProfile\OneDrive" -Recurse -Force -ErrorAction SilentlyContinue
	}

	# 5. Bloquer OneDrive via stratégies de groupe
	Log-OD "5/9 — Blocage via stratégies de groupe..."
	foreach ($gpPath in @(
		"HKLM:\SOFTWARE\Policies\Microsoft\Windows\OneDrive",
		"HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\OneDrive"
	))
	{
		New-Item -Path $gpPath -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path $gpPath -Name "DisableFileSyncNGSC" -Value 1 -Type DWord -ErrorAction SilentlyContinue
	}

	# 6. Retirer OneDrive de la barre latérale de l'Explorateur (via HKCU, pas besoin de HKCR/admin)
	Write-Output "Suppression de OneDrive dans l'Explorateur..."
	$clsid = "{018D5C66-4533-4307-9B53-224DE2ED1FE6}"
	foreach ($rp in @(
		"HKCU:\SOFTWARE\Classes\CLSID\$clsid",
		"HKCU:\SOFTWARE\Classes\Wow6432Node\CLSID\$clsid"
	))
	{
		New-Item -Path $rp -Force -ErrorAction SilentlyContinue | Out-Null
		Set-ItemProperty -Path $rp -Name "System.IsPinnedToNameSpaceTree" -Value 0 -Type DWord -ErrorAction SilentlyContinue
	}

	# 7. Supprimer les entrées de démarrage automatique
	Log-OD "7/9 — Suppression des entrées de démarrage..."
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -Name "OneDrive" -ErrorAction SilentlyContinue
	try
	{
		reg load "hku\Default" "C:\Users\Default\NTUSER.DAT" 2>$null
		reg delete "HKEY_USERS\Default\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "OneDriveSetup" /f 2>$null
	}
	finally
	{
		reg unload "hku\Default" 2>$null
	}

	# 8. Supprimer les tâches planifiées OneDrive
	Log-OD "8/9 — Suppression des tâches planifiées..."
	Get-ScheduledTask -TaskPath '\' -TaskName 'OneDrive*' -ErrorAction SilentlyContinue | Unregister-ScheduledTask -Confirm:$false

	# 9. Raccourci menu Démarrer + redémarrage Explorateur
	Remove-Item -Path "$env:AppData\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk" -Force -ErrorAction SilentlyContinue
	Log-OD "9/9 — Redémarrage de l'Explorateur..."
	Start-Process "explorer.exe"

	$textBox.AppendText("`r`n✅ OneDrive désinstallé avec succès.`r`n")
	[System.Windows.Forms.Application]::DoEvents()
	Add-Content -Path "$env:TEMP\logfile.txt" -Value "OneDrive desinstalle." -ErrorAction SilentlyContinue
}

#1010101010101010101010101010101010101010101010101010101010  Menu QuickBoost 1010101010101010101010101010101010101010101010101010101010101010101010101
function MenuQuickBoost
{
	$url = "https://stephaninformatique.fr/pws/QB.exe" # URL du fichier à télécharger
	$output = "$env:MultInstall\QB.exe" # Emplacement où le fichier sera sauvegardé
	
	# Vérifier si le fichier existe déjà
	if (-Not (Test-Path -Path $output))
	{
		# Télécharger le fichier seulement s'il n'existe pas déjà
		Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30
		
		# Vérifier si le fichier a été correctement téléchargé
		if (Test-Path -Path $output)
		{
			$textBox.AppendText("Le fichier a été téléchargé avec succès." + [Environment]::NewLine)
		}
		else
		{
			$textBox.AppendText("Échec du téléchargement du fichier." + [Environment]::NewLine)
			return
		}
	}
	
	# QB.exe est un SFX 7-Zip → extraction silencieuse dans %TEMP%
	$textBox.AppendText("Extraction de QuickBoost..." + [Environment]::NewLine)
	Start-Process -FilePath $output -ArgumentList "-o`"$env:TEMP`" -y" -Wait -WindowStyle Hidden

	# QuickBoost.exe peut être dans %TEMP% ou dans un sous-dossier
	$found = Get-ChildItem -Path $env:TEMP -Filter "QuickBoost.exe" -Recurse -ErrorAction SilentlyContinue |
			 Select-Object -First 1

	if ($found)
	{
		$textBox.AppendText("Lancement de QuickBoost..." + [Environment]::NewLine)
		Start-Process -FilePath $found.FullName
	}
	else
	{
		$textBox.AppendText("QuickBoost.exe introuvable après extraction." + [Environment]::NewLine)
	}
}

#111111111111111111111111111111111111111111111111111111111  QuickRepairWindows 1111111111111111111111111111111111111111111111111111111111111111111111&
function WinRepairQuick
{
	
	Add-Type -AssemblyName System.Windows.Forms
	
	function Repair-Windows
	{
		# Obtenir la taille de l'écran
		$screenWidth = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Width
		$screenHeight = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Height
		
		# Créer la fenêtre principale
		$mainForm = New-Object System.Windows.Forms.Form
		$mainForm.Text = "Options de réparation"
		$mainForm.Width = $screenWidth * 0.4
		$mainForm.Height = $screenHeight * 0.4
		$mainForm.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
		
		# Calculer la taille de la police en fonction de la taille de l'écran
		$fontSize = [int]($screenHeight / 120)
		$font = New-Object System.Drawing.Font("Arial", $fontSize)
		
		# Ajouter une ListBox pour les options
		$listBox = New-Object System.Windows.Forms.ListBox
		$listBox.Width = $mainForm.Width - 40
		$listBox.Height = $mainForm.Height - 60
		$listBox.Location = New-Object System.Drawing.Point(20, 20)
		$listBox.Font = $font
		$listBox.Items.AddRange(@(
				"Réparer Windows avec l'image courante",
				"Réparer Windows avec une image ISO spécifique",
				"Vérification des fichiers système",
				"Réinitialiser le cache de Windows Update",
				"Réinitialiser les composants de Windows Update",
				"Vérifier le disque",
				"Réinitialiser les cartes réseau",
				"Quitter"
			))
		
		$listBox.Add_DoubleClick({
				switch ($listBox.SelectedItem)
				{
					"Réparer Windows avec l'image courante" {
						Start-Process -FilePath "cmd.exe" -ArgumentList "/k dism /online /cleanup-image /restorehealth && pause" -Wait
					}
					"Réparer Windows avec une image ISO spécifique" {
						$openFileDialog = New-Object System.Windows.Forms.OpenFileDialog
						$openFileDialog.Filter = "Fichiers ISO (*.iso)|*.iso"
						$openFileDialog.Title = "Sélectionnez le fichier ISO de Windows"
						
						if ($openFileDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK)
						{
							$isoPath = $openFileDialog.FileName
							if (Test-Path $isoPath)
							{
								Mount-DiskImage -ImagePath $isoPath
								$driveLetter = (Get-DiskImage -ImagePath $isoPath | Get-Volume).DriveLetter + ":"
								Start-Process -FilePath "cmd.exe" -ArgumentList "/k dism /online /cleanup-image /restorehealth /source:$driveLetter\sources\install.wim /limitaccess && pause" -Wait
								Dismount-DiskImage -ImagePath $isoPath
							}
							else
							{
								[System.Windows.Forms.MessageBox]::Show("Chemin d'ISO non valide.")
							}
						}
					}
					"Vérification des fichiers système" {
						Start-Process -FilePath "cmd.exe" -ArgumentList "/k sfc /scannow && pause" -Wait
					}
					"Réinitialiser le cache de Windows Update" {
						# Au lieu de supprimer directement
						if ((Get-Service -Name wuauserv).Status -eq 'Running')
						{
							Write-Warning "Arrêt du service Windows Update"
							Stop-Service -Name wuauserv -Confirm
						}
					}
					"Réinitialiser les composants de Windows Update" {
						$services = @('wuauserv', 'cryptSvc', 'bits', 'msiserver')
						try
						{
							$services | ForEach-Object { Stop-Service -Name $_ -ErrorAction SilentlyContinue }
							Remove-Item -Path "C:\Windows\SoftwareDistribution\*" -Recurse -Force -ErrorAction SilentlyContinue
							Remove-Item -Path "C:\Windows\System32\catroot2\*" -Recurse -Force -ErrorAction SilentlyContinue
						}
						finally
						{
							$services | ForEach-Object { Start-Service -Name $_ -ErrorAction SilentlyContinue }
						}
					}
					"Vérifier le disque" {
						$drive = $env:SystemDrive
						Start-Process -FilePath "cmd.exe" -ArgumentList "/k chkdsk $drive /f && pause" -Wait
					}
					"Réinitialiser les cartes réseau" {
						Start-Process -FilePath "cmd.exe" -ArgumentList "/k ipconfig /release && ipconfig /flushdns && ipconfig /renew && netsh int ip reset && pause" -Wait
					}
					"Quitter" {
						$mainForm.Close()
					}
				}
			})
		
		$mainForm.Controls.Add($listBox)
		$mainForm.ShowDialog()
	}
	
	Repair-Windows
	
}
#_____________________________12_________________________  Audit de securite (local) ________________________________12_______________________________________
function AuditSecurite
{
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $f = New-MaintWindow "Audit de securite" 880 680

    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 84; $pBot.BackColor = [System.Drawing.Color]::FromArgb(243, 244, 246); $f.Controls.Add($pBot)
    $clb = New-Object System.Windows.Forms.CheckedListBox; $clb.Dock = "Left"; $clb.Width = 250; $clb.CheckOnClick = $true
    $clb.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59); $clb.ForeColor = [System.Drawing.Color]::FromArgb(226, 232, 240); $clb.BorderStyle = "None"; $clb.Font = New-Object System.Drawing.Font("Segoe UI", 9); $f.Controls.Add($clb)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Fill"; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 9); $rtb.BorderStyle = "None"; $f.Controls.Add($rtb)

    $cats = @(
        "Pare-feu", "UAC", "Antivirus / Defender", "Secure Boot", "TPM", "BitLocker",
        "Comptes & administrateurs", "Politique mot de passe", "Bureau a distance (RDP)",
        "Protocole SMBv1", "Ports en ecoute", "Partages reseau", "Programmes au demarrage",
        "Taches planifiees (tierces)", "Services tiers", "Mises a jour Windows",
        "Connexions echouees", "Autologon", "Journalisation PowerShell",
        "Espace disque", "Temps d activite", "BIOS / UEFI"
    )
    foreach ($c in $cats) { [void]$clb.Items.Add($c, $true) }

    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Lancer l audit"; $btnGo.Location = New-Object System.Drawing.Point(12, 9); $btnGo.Size = New-Object System.Drawing.Size(180, 30)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(22, 163, 74); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnAll = New-Object System.Windows.Forms.Button; $btnAll.Text = "Tout cocher / decocher"; $btnAll.Location = New-Object System.Drawing.Point(200, 9); $btnAll.Size = New-Object System.Drawing.Size(170, 30)
    $btnAll.FlatStyle = "Flat"; $btnAll.FlatAppearance.BorderSize = 0; $btnAll.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnAll.ForeColor = "White"; $pBot.Controls.Add($btnAll)
    $btnRep = New-Object System.Windows.Forms.Button; $btnRep.Text = "Rapport HTML"; $btnRep.Location = New-Object System.Drawing.Point(378, 9); $btnRep.Size = New-Object System.Drawing.Size(140, 30)
    $btnRep.FlatStyle = "Flat"; $btnRep.FlatAppearance.BorderSize = 0; $btnRep.BackColor = [System.Drawing.Color]::FromArgb(79, 70, 229); $btnRep.ForeColor = "White"; $pBot.Controls.Add($btnRep)
    $btnCopy = New-Object System.Windows.Forms.Button; $btnCopy.Text = "Copier"; $btnCopy.Location = New-Object System.Drawing.Point(524, 9); $btnCopy.Size = New-Object System.Drawing.Size(100, 30)
    $btnCopy.FlatStyle = "Flat"; $btnCopy.FlatAppearance.BorderSize = 0; $btnCopy.BackColor = [System.Drawing.Color]::FromArgb(2, 132, 199); $btnCopy.ForeColor = "White"; $pBot.Controls.Add($btnCopy)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(630, 9); $btnC.Size = New-Object System.Drawing.Size(90, 30)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(120, 53, 15); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $btnAll.Add_Click({ $any = $false; for ($k=0;$k -lt $clb.Items.Count;$k++){ if (-not $clb.GetItemChecked($k)){ $any=$true; break } }; for ($k=0;$k -lt $clb.Items.Count;$k++){ $clb.SetItemChecked($k, $any) } }.GetNewClosure())

    $f.Tag.SendToBack(); $pBot.BringToFront(); $clb.BringToFront(); $rtb.BringToFront()

    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Red" { [System.Drawing.Color]::FromArgb(248,113,113) } "Gray" { [System.Drawing.Color]::FromArgb(148,163,184) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()
    $state = @{ rows = @(); nOk = 0; nWarn = 0; nRisk = 0; nInfo = 0 }
    $sevCol = @{ "OK"="Green"; "WARN"="Yellow"; "RISK"="Red"; "INFO"="Gray" }
    $add = { param($cat, $sev, $detail)
        $state.rows += [PSCustomObject]@{ Cat = $cat; Sev = $sev; Detail = [string]$detail }
        switch ($sev) { "OK" { $state.nOk++ } "WARN" { $state.nWarn++ } "RISK" { $state.nRisk++ } default { $state.nInfo++ } }
        $tag = switch ($sev) { "OK" { "[OK]  " } "WARN" { "[!]   " } "RISK" { "[RISK]" } default { "[i]   " } }
        & $log ($tag + " " + $cat + " : " + (([string]$detail) -replace "`r?`n", " | ")) ($sevCol[$sev])
    }.GetNewClosure()
    $want = { param($n) return ($clb.CheckedItems -contains $n) }.GetNewClosure()

    $btnGo.Add_Click({
        $btnGo.Enabled = $false; $state.rows = @(); $state.nOk = 0; $state.nWarn = 0; $state.nRisk = 0; $state.nInfo = 0; $rtb.Clear()
        & $log "===== AUDIT DE SECURITE =====" "Cyan"
        & $log ("Machine : " + $env:COMPUTERNAME + "   Utilisateur : " + $env:USERNAME + "   Date : " + (Get-Date -Format "dd/MM/yyyy HH:mm")) "Gray"
        & $log "" "Gray"

        if (& $want "Pare-feu") { try {
            $pf = Get-NetFirewallProfile -ErrorAction Stop
            $off = @($pf | Where-Object { -not $_.Enabled })
            if ($off.Count -eq 0) { & $add "Pare-feu" "OK" "Tous les profils actifs (Domain, Private, Public)" }
            else { & $add "Pare-feu" "RISK" ("Profils desactives : " + (($off | ForEach-Object { $_.Name }) -join ", ")) }
        } catch { & $add "Pare-feu" "INFO" ("Non evalue : " + $_.Exception.Message) } }

        if (& $want "UAC") { try {
            $lua = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ErrorAction Stop).EnableLUA
            if ($lua -eq 1) { & $add "UAC" "OK" "Controle de compte d utilisateur active" } else { & $add "UAC" "RISK" "UAC DESACTIVE" }
        } catch { & $add "UAC" "INFO" ("Non evalue : " + $_.Exception.Message) } }

        if (& $want "Antivirus / Defender") { try {
            $mp = Get-MpComputerStatus -ErrorAction Stop
            $det = @()
            if ($mp.AntivirusEnabled) { $det += "Antivirus actif" } else { $det += "Antivirus inactif" }
            if ($mp.RealTimeProtectionEnabled) { $det += "Temps reel ON" } else { $det += "Temps reel OFF" }
            if ($mp.IsTamperProtected) { $det += "Tamper Protection ON" }
            $age = $null; try { $age = ((Get-Date) - $mp.AntivirusSignatureLastUpdated).Days } catch {}
            if ($age -ne $null) { $det += ("Signatures: " + $age + "j") }
            $sev = "OK"
            if (-not $mp.AntivirusEnabled -or -not $mp.RealTimeProtectionEnabled) { $sev = "RISK" }
            elseif ($age -ne $null -and $age -gt 3) { $sev = "WARN" }
            & $add "Antivirus / Defender" $sev ($det -join " | ")
            $third = Get-Service -Name "MBAMService","WRSVC","avast*","AVP*","ekrn","McAfee*" -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq "Running" }
            if ($third) { & $add "Antivirus tiers" "INFO" (($third | ForEach-Object { $_.Name }) -join ", ") }
        } catch { & $add "Antivirus / Defender" "INFO" ("Non evalue : " + $_.Exception.Message) } }

        if (& $want "Secure Boot") { try {
            $sb = Confirm-SecureBootUEFI -ErrorAction Stop
            if ($sb) { & $add "Secure Boot" "OK" "Active" } else { & $add "Secure Boot" "WARN" "Desactive" }
        } catch { & $add "Secure Boot" "INFO" "Indeterminable (BIOS Legacy ou non supporte)" } }

        if (& $want "TPM") { try {
            $tpm = Get-Tpm -ErrorAction Stop
            if ($tpm.TpmPresent -and $tpm.TpmReady) { & $add "TPM" "OK" "Present et pret" }
            elseif ($tpm.TpmPresent) { & $add "TPM" "WARN" "Present mais non pret" }
            else { & $add "TPM" "WARN" "Aucun TPM detecte" }
        } catch { & $add "TPM" "INFO" "Indeterminable" } }

        if (& $want "BitLocker") { try {
            if (Get-Command Get-BitLockerVolume -ErrorAction SilentlyContinue) {
                $sys = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
                if ($sys.ProtectionStatus -eq "On") { & $add "BitLocker" "OK" ($env:SystemDrive + " chiffre (" + $sys.VolumeStatus + ")") }
                else { & $add "BitLocker" "WARN" ($env:SystemDrive + " non protege (" + $sys.VolumeStatus + ")") }
            } else { & $add "BitLocker" "INFO" "Module BitLocker indisponible (edition Familiale)" }
        } catch { & $add "BitLocker" "INFO" ("Non evalue : " + $_.Exception.Message) } }

        if (& $want "Comptes & administrateurs") { try {
            $admGrp = (Get-LocalGroup -ErrorAction SilentlyContinue | Where-Object { $_.SID -like "*-544" }).Name
            if (-not $admGrp) { $admGrp = "Administrators" }
            $admins = Get-LocalGroupMember -Group $admGrp -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }
            & $add "Administrateurs" "INFO" ("Membres : " + (($admins) -join ", "))
            $builtin = Get-LocalUser -ErrorAction SilentlyContinue | Where-Object { $_.SID -like "*-500" }
            if ($builtin -and $builtin.Enabled) { & $add "Compte Administrateur integre" "WARN" "Active (a desactiver si non utilise)" }
            elseif ($builtin) { & $add "Compte Administrateur integre" "OK" "Desactive" }
            $guest = Get-LocalUser -ErrorAction SilentlyContinue | Where-Object { $_.SID -like "*-501" }
            if ($guest -and $guest.Enabled) { & $add "Compte Invite" "RISK" "Active" } elseif ($guest) { & $add "Compte Invite" "OK" "Desactive" }
        } catch { & $add "Comptes & administrateurs" "INFO" ("Non evalue : " + $_.Exception.Message) } }

        if (& $want "Politique mot de passe") { try {
            $na = (& net accounts) 2>$null | Out-String
            $minLen = ([regex]::Match($na, "(?im)minimum.*?:\s*(\d+)")).Groups[1].Value
            $maxAge = ([regex]::Match($na, "(?im)Maximum.*?:\s*(\d+)")).Groups[1].Value
            $d = "Longueur min : " + $(if ($minLen) { $minLen } else { "?" }) + " | Age max : " + $(if ($maxAge) { $maxAge } else { "?" })
            $sev = "OK"; if ($minLen -and [int]$minLen -lt 8) { $sev = "WARN" }; if (-not $minLen -or $minLen -eq "0") { $sev = "WARN" }
            & $add "Politique mot de passe" $sev $d
        } catch { & $add "Politique mot de passe" "INFO" "Non evalue" } }

        if (& $want "Bureau a distance (RDP)") { try {
            $deny = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" -ErrorAction Stop).fDenyTSConnections
            if ($deny -eq 0) {
                $nla = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -ErrorAction SilentlyContinue).UserAuthentication
                $d = "RDP ACTIVE" + $(if ($nla -eq 1) { " (NLA active)" } else { " (NLA desactive)" })
                & $add "Bureau a distance (RDP)" "WARN" $d
            } else { & $add "Bureau a distance (RDP)" "OK" "Desactive" }
        } catch { & $add "Bureau a distance (RDP)" "INFO" "Non evalue" } }

        if (& $want "Protocole SMBv1") { try {
            $smb1 = $null
            try { $smb1 = (Get-SmbServerConfiguration -ErrorAction Stop).EnableSMB1Protocol } catch {}
            if ($smb1 -eq $true) { & $add "Protocole SMBv1" "RISK" "Active (vulnerable - a desactiver)" }
            elseif ($smb1 -eq $false) { & $add "Protocole SMBv1" "OK" "Desactive" }
            else { & $add "Protocole SMBv1" "INFO" "Indeterminable" }
        } catch { & $add "Protocole SMBv1" "INFO" "Non evalue" } }

        if (& $want "Ports en ecoute") { try {
            $listen = Get-NetTCPConnection -State Listen -ErrorAction Stop | Select-Object -ExpandProperty LocalPort | Sort-Object -Unique
            $susp = @(135,139,445,3389,5900,23) | Where-Object { $listen -contains $_ }
            & $add "Ports en ecoute" "INFO" ("Total : " + @($listen).Count + " ports")
            if ($susp.Count -gt 0) { & $add "Ports sensibles ouverts" "WARN" ($susp -join ", ") }
            else { & $add "Ports sensibles" "OK" "Aucun port sensible en ecoute" }
        } catch { & $add "Ports en ecoute" "INFO" "Non evalue" } }

        if (& $want "Partages reseau") { try {
            $sh = Get-CimInstance Win32_Share -ErrorAction Stop | Where-Object { $_.Name -notmatch '\$$' }
            if ($sh) { & $add "Partages reseau" "WARN" (($sh | ForEach-Object { $_.Name + " -> " + $_.Path }) -join " ; ") }
            else { & $add "Partages reseau" "OK" "Aucun partage personnalise" }
        } catch { & $add "Partages reseau" "INFO" "Non evalue" } }

        if (& $want "Programmes au demarrage") { try {
            $su = Get-CimInstance Win32_StartupCommand -ErrorAction Stop
            & $add "Programmes au demarrage" "INFO" ("" + @($su).Count + " entree(s) : " + (($su | Select-Object -First 12 | ForEach-Object { $_.Name }) -join ", "))
        } catch { & $add "Programmes au demarrage" "INFO" "Non evalue" } }

        if (& $want "Taches planifiees (tierces)") { try {
            $tk = Get-ScheduledTask -ErrorAction Stop | Where-Object { $_.State -ne "Disabled" -and $_.TaskPath -notlike "\Microsoft\*" }
            & $add "Taches planifiees (tierces)" "INFO" ("" + @($tk).Count + " active(s) : " + (($tk | Select-Object -First 12 | ForEach-Object { $_.TaskName }) -join ", "))
        } catch { & $add "Taches planifiees (tierces)" "INFO" "Non evalue" } }

        if (& $want "Services tiers") { try {
            $sv = Get-CimInstance Win32_Service -ErrorAction Stop | Where-Object { $_.StartMode -eq "Auto" -and $_.State -eq "Running" -and $_.PathName -notlike "*\Windows\*" }
            & $add "Services tiers" "INFO" ("" + @($sv).Count + " en cours : " + (($sv | Select-Object -First 12 | ForEach-Object { $_.Name }) -join ", "))
        } catch { & $add "Services tiers" "INFO" "Non evalue" } }

        if (& $want "Mises a jour Windows") { try {
            $last = (Get-CimInstance Win32_QuickFixEngineering -ErrorAction SilentlyContinue | Sort-Object InstalledOn -Descending | Select-Object -First 1).InstalledOn
            $cnt = "?"
            try { $us = New-Object -ComObject Microsoft.Update.Session; $se = $us.CreateUpdateSearcher(); $cnt = $se.Search("IsInstalled=0 and Type='Software'").Updates.Count } catch {}
            $d = "En attente : " + $cnt + " | Derniere : " + $(if ($last) { (Get-Date $last -Format "dd/MM/yyyy") } else { "?" })
            $sev = "OK"; if ($cnt -ne "?" -and [int]$cnt -gt 0) { $sev = "WARN" }
            & $add "Mises a jour Windows" $sev $d
        } catch { & $add "Mises a jour Windows" "INFO" "Non evalue" } }

        if (& $want "Connexions echouees") { try {
            $fl = Get-WinEvent -FilterHashtable @{ LogName = "Security"; ID = 4625; StartTime = (Get-Date).AddDays(-7) } -ErrorAction SilentlyContinue
            $n = @($fl).Count
            if ($n -eq 0) { & $add "Connexions echouees (7j)" "OK" "Aucune" }
            elseif ($n -lt 10) { & $add "Connexions echouees (7j)" "INFO" ("" + $n + " tentative(s)") }
            else { & $add "Connexions echouees (7j)" "WARN" ("" + $n + " tentatives (possible attaque par force brute)") }
        } catch { & $add "Connexions echouees (7j)" "INFO" "Non evalue (journal Securite)" } }

        if (& $want "Autologon") { try {
            $wl = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -ErrorAction Stop
            if ($wl.AutoAdminLogon -eq "1" -and $wl.DefaultPassword) { & $add "Autologon" "RISK" ("Active avec mot de passe en clair (utilisateur : " + $wl.DefaultUserName + ")") }
            elseif ($wl.AutoAdminLogon -eq "1") { & $add "Autologon" "WARN" ("Active (utilisateur : " + $wl.DefaultUserName + ")") }
            else { & $add "Autologon" "OK" "Desactive" }
        } catch { & $add "Autologon" "INFO" "Non evalue" } }

        if (& $want "Journalisation PowerShell") { try {
            $sbl = (Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging" -ErrorAction SilentlyContinue).EnableScriptBlockLogging
            $tr = (Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription" -ErrorAction SilentlyContinue).EnableTranscripting
            & $add "Journalisation PowerShell" "INFO" ("Blocs de script : " + $(if ($sbl -eq 1) { "ON" } else { "OFF" }) + " | Transcription : " + $(if ($tr -eq 1) { "ON" } else { "OFF" }))
        } catch { & $add "Journalisation PowerShell" "INFO" "Non evalue" } }

        if (& $want "Espace disque") { try {
            $dk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$($env:SystemDrive)'" -ErrorAction Stop
            $free = [math]::Round($dk.FreeSpace / 1GB, 1); $tot = [math]::Round($dk.Size / 1GB, 1)
            $pct = if ($tot -gt 0) { [math]::Round(($free / $tot) * 100, 0) } else { 0 }
            $d = $free.ToString() + " Go libres sur " + $tot.ToString() + " Go (" + $pct + "%)"
            $sev = "OK"; if ($pct -lt 10) { $sev = "RISK" } elseif ($pct -lt 20) { $sev = "WARN" }
            & $add "Espace disque" $sev $d
        } catch { & $add "Espace disque" "INFO" "Non evalue" } }

        if (& $want "Temps d activite") { try {
            $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
            $up = (Get-Date) - $os.LastBootUpTime
            $d = "" + $up.Days + "j " + $up.Hours + "h (demarrage : " + (Get-Date $os.LastBootUpTime -Format "dd/MM HH:mm") + ")"
            $sev = if ($up.Days -gt 30) { "WARN" } else { "INFO" }
            & $add "Temps d activite" $sev $d
        } catch { & $add "Temps d activite" "INFO" "Non evalue" } }

        if (& $want "BIOS / UEFI") { try {
            $b = Get-CimInstance Win32_BIOS -ErrorAction Stop
            & $add "BIOS / UEFI" "INFO" ($b.Manufacturer + " v" + $b.SMBIOSBIOSVersion)
        } catch { & $add "BIOS / UEFI" "INFO" "Non evalue" } }

        & $log "" "Gray"
        & $log ("===== RESUME : " + $state.nOk + " OK, " + $state.nWarn + " avertissement(s), " + $state.nRisk + " risque(s), " + $state.nInfo + " info(s) =====") "Cyan"
        if ($state.nRisk -gt 0) { & $log "Des risques de securite ont ete detectes - voir lignes [RISK]." "Red" }
        $btnGo.Enabled = $true
        try { Add-Journal ("Audit securite : " + $state.nRisk + " risque(s), " + $state.nWarn + " avertissement(s)") } catch {}
    }.GetNewClosure())

    $btnCopy.Add_Click({ try { [System.Windows.Forms.Clipboard]::SetText($rtb.Text) } catch {} }.GetNewClosure())

    $btnRep.Add_Click({
        if ($state.rows.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show("Lancez d abord l audit."); return }
        Add-Type -AssemblyName Microsoft.VisualBasic
        $client = [Microsoft.VisualBasic.Interaction]::InputBox("Nom du client :", "Rapport d audit", "")
        if (-not $client) { $client = "Client" }
        $css = "body{font-family:Segoe UI,Arial;color:#0f172a;padding:28px} h1{margin:0 0 4px} .meta{color:#475569;margin:1px 0} table{border-collapse:collapse;width:100%;margin-top:16px} th,td{border:1px solid #e2e8f0;padding:7px 9px;text-align:left;font-size:13px;vertical-align:top} th{background:#1e293b;color:#fff} .OK{color:#15803d;font-weight:bold} .WARN{color:#b45309;font-weight:bold} .RISK{color:#b91c1c;font-weight:bold} .INFO{color:#475569} .sum span{display:inline-block;margin-right:14px;font-weight:bold}"
        $h = "<html><head><meta charset=utf-8><style>" + $css + "</style></head><body>"
        $h += "<h1>Rapport d audit de securite</h1>"
        $h += "<div class=meta><b>Client :</b> " + $client + "</div>"
        $h += "<div class=meta><b>Machine :</b> " + $env:COMPUTERNAME + "   <b>Utilisateur :</b> " + $env:USERNAME + "</div>"
        $h += "<div class=meta><b>Date :</b> " + (Get-Date -Format "dd/MM/yyyy HH:mm") + "</div>"
        $h += "<div class=sum><span class=OK>" + $state.nOk + " OK</span><span class=WARN>" + $state.nWarn + " avertissements</span><span class=RISK>" + $state.nRisk + " risques</span><span class=INFO>" + $state.nInfo + " infos</span></div>"
        $h += "<table><tr><th>Etat</th><th>Verification</th><th>Detail</th></tr>"
        foreach ($r in $state.rows) {
            $det = ([string]$r.Detail) -replace "&","&amp;" -replace "<","&lt;" -replace ">","&gt;" -replace "`r?`n","<br>"
            $h += "<tr><td class=" + $r.Sev + ">" + $r.Sev + "</td><td>" + ($r.Cat -replace "<","&lt;") + "</td><td>" + $det + "</td></tr>"
        }
        $h += "</table></body></html>"
        $base = "Audit_" + ($client -replace "[^a-zA-Z0-9]","_") + "_" + $env:COMPUTERNAME + "_" + (Get-Date -Format "yyyyMMdd_HHmm")
        $htmlF = Join-Path ([Environment]::GetFolderPath("Desktop")) ($base + ".html")
        $h | Out-File $htmlF -Encoding UTF8
        $pdfF = Join-Path ([Environment]::GetFolderPath("Desktop")) ($base + ".pdf")
        $edge = $null
        foreach ($pp in @("$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe", "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe")) { if (Test-Path $pp) { $edge = $pp; break } }
        if ($edge) { try { & $edge "--headless=new" "--disable-gpu" ("--print-to-pdf=" + $pdfF) $htmlF 2>$null | Out-Null } catch {}; Start-Sleep -Milliseconds 1200 }
        if (Test-Path $pdfF) { Start-Process $pdfF } else { Start-Process $htmlF }
        try { Add-Journal ("Audit securite : rapport genere pour " + $client) } catch {}
    }.GetNewClosure())

    $f.Add_Shown({ $f.Activate(); & $log "Selectionnez les verifications puis cliquez sur 'Lancer l audit'." "Gray" }.GetNewClosure())
    [void]$f.ShowDialog()
}
#__________________32_______________Activation Windows Et Plus______________________32____________________________________________________

function ActivationWindows
{
	Add-Type -AssemblyName System.Windows.Forms
	
	# Fonction pour vérifier l'édition de Windows
	function Get-WindowsEdition
	{
		$osEdition = "Inconnu"
		try
		{
			$osEdition = (Get-CimInstance -ClassName Win32_OperatingSystem).Caption
		}
		catch
		{
			$osEdition = "Erreur : Impossible de déterminer l'édition de Windows."
		}
		return $osEdition
	}
	
	# Fonction pour vérifier si Windows est activé
	function Is-WindowsActivated
	{
		$status = "Inconnu"
		$keyStatus = ""
		try
		{
			$productKeyPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SoftwareProtectionPlatform"
			$key = Get-ItemProperty -Path $productKeyPath
			$keyStatus = $key.BackupProductKeyDefault
			if ($keyStatus -ne $null -and $keyStatus -ne "")
			{
				$status = "Vrai"
			}
			else
			{
				$status = "Faux"
			}
		}
		catch
		{
			$status = "Erreur : Impossible de déterminer le statut de l'activation."
		}
		return @{ Status = $status; KeyStatus = $keyStatus }
	}
	
	# Fonction pour activer Windows
	function Activate-Windows
	{
		param (
			[Parameter(Mandatory = $true)]
			[string]$ProductKey
		)
		try
		{
			slmgr.vbs /ipk $ProductKey
			slmgr.vbs /ato
			return "Commande d'activation envoyée."
		}
		catch
		{
			return "Erreur : Activation échouée."
		}
	}
	
	# Fonction pour upgrader Windows de Home à Pro
	function Upgrade-Windows
	{
		param (
			[Parameter(Mandatory = $true)]
			[string]$GenericProductKey
		)
		try
		{
			$confirmation = [System.Windows.Forms.MessageBox]::Show(
				"Cette opération va tenter de mettre à niveau Windows Home vers Pro.`nVoulez-vous continuer ?",
				"Confirmation",
				[System.Windows.Forms.MessageBoxButtons]::YesNo,
				[System.Windows.Forms.MessageBoxIcon]::Question)
			
			if ($confirmation -eq 'Yes')
			{
				# Changement de clé de produit
				$changePK = Start-Process "changepk.exe" -ArgumentList "/ProductKey $GenericProductKey" -Wait -PassThru
				Start-Sleep -Seconds 5
				
				# Activer Windows avec la nouvelle clé
				$activate = Start-Process "slmgr.vbs" -ArgumentList "/ato" -Wait -PassThru
				Start-Sleep -Seconds 5
				
				# Vérifier si l'édition a changé
				$newEdition = (Get-CimInstance -ClassName Win32_OperatingSystem).Caption
				
				if ($newEdition -like "*Pro*")
				{
					return "Mise à niveau réussie ! Windows est maintenant en version Pro.`nNouvelle édition : $newEdition"
				}
				else
				{
					# Si la mise à niveau automatique échoue, proposer la méthode manuelle
					$manualUpgrade = [System.Windows.Forms.MessageBox]::Show(
						"La mise à niveau automatique n'a pas réussi. Voulez-vous ouvrir les Paramètres Windows pour une mise à niveau manuelle ?",
						"Mise à niveau manuelle",
						[System.Windows.Forms.MessageBoxButtons]::YesNo)
					
					if ($manualUpgrade -eq 'Yes')
					{
						Start-Process "ms-settings:activation"
						return "Les paramètres d'activation de Windows ont été ouverts. Veuillez suivre les instructions pour la mise à niveau."
					}
				}
			}
			else
			{
				return "Opération annulée par l'utilisateur."
			}
		}
		catch
		{
			return "Erreur lors de la mise à niveau : $_"
		}
	}
	
	# Fonction pour afficher une boîte de dialogue d'entrée
	function Show-InputBox
	{
		param (
			[string]$message,
			[string]$title,
			[string]$default
		)
		$form = New-Object Windows.Forms.Form
		$form.Width = 400
		$form.Height = 200
		$form.Text = $title
		
		$label = New-Object Windows.Forms.Label
		$label.Text = $message
		$label.Left = 10
		$label.Top = 20
		$form.Controls.Add($label)
		
		$textBox = New-Object Windows.Forms.TextBox
		$textBox.Left = 10
		$textBox.Top = 50
		$textBox.Width = 360
		$textBox.Text = $default
		$form.Controls.Add($textBox)
		
		$buttonOk = New-Object Windows.Forms.Button
		$buttonOk.Text = "OK"
		$buttonOk.Left = 250
		$buttonOk.Top = 100
		$buttonOk.Add_Click({
				$form.DialogResult = [System.Windows.Forms.DialogResult]::OK
				$form.Close()
			})
		$form.Controls.Add($buttonOk)
		
		$buttonCancel = New-Object Windows.Forms.Button
		$buttonCancel.Text = "Annuler"
		$buttonCancel.Left = 150
		$buttonCancel.Top = 100
		$buttonCancel.Add_Click({
				$form.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
				$form.Close()
			})
		$form.Controls.Add($buttonCancel)
		
		$form.AcceptButton = $buttonOk
		$form.CancelButton = $buttonCancel
		$form.ShowDialog()
		
		if ($form.DialogResult -eq [System.Windows.Forms.DialogResult]::OK)
		{
			return $textBox.Text
		}
		else
		{
			return $null
		}
	}
	
	# Créer la fenêtre principale
	$form = New-Object Windows.Forms.Form
	$form.Text = "Gestion de l'activation de Windows"
	$form.Width = 400
	$form.Height = 300
	
	# Bouton pour vérifier l'activation et l'édition
	$checkButton = New-Object Windows.Forms.Button
	$checkButton.Text = "Vérifier l'activation et l'édition"
	$checkButton.Width = 350
	$checkButton.Height = 40
	$checkButton.Top = 20
	$checkButton.Left = 20
	$checkButton.Add_Click({
			$windowsEdition = Get-WindowsEdition
			$activationInfo = Is-WindowsActivated
			$isActivated = $activationInfo.Status
			$keyStatus = $activationInfo.KeyStatus
			
			$messages = @()
			$messages += "Vérification de l'édition de Windows..."
			$messages += "Édition du système : $windowsEdition"
			$messages += "Vérification si Windows est activé..."
			$messages += "Statut de la clé de produit : $keyStatus"
			$messages += "Windows est-il activé : $isActivated"
			
			if ($isActivated -eq "Vrai")
			{
				$messages += "Windows est déjà activé."
			}
			else
			{
				$messages += "Windows n'est pas activé."
			}
			
			$messages += "Vérification terminée."
			[System.Windows.Forms.MessageBox]::Show([string]::Join("`r`n", $messages), "Résultat de la vérification")
		})
	
	# Bouton pour activer Windows
	$activateButton = New-Object Windows.Forms.Button
	$activateButton.Text = "Activer Windows"
	$activateButton.Width = 350
	$activateButton.Height = 40
	$activateButton.Top = 80
	$activateButton.Left = 20
	$activateButton.Add_Click({
			slui 3
		})
	
	# Bouton pour upgrader Windows de Home à Pro
	$upgradeButton = New-Object Windows.Forms.Button
	$upgradeButton.Text = "Mise à niveau Windows Home à Pro"
	$upgradeButton.Width = 350
	$upgradeButton.Height = 40
	$upgradeButton.Top = 140
	$upgradeButton.Left = 20
	$upgradeButton.Add_Click({
			$windowsEdition = Get-WindowsEdition
			
			if ($windowsEdition -like "*Home*")
			{
				if ($windowsEdition -like "*10*")
				{
					$genericProductKey = "VK7JG-NPHTM-C97JM-9MPGT-3V66T"
				}
				elseif ($windowsEdition -like "*11*")
				{
					$genericProductKey = "W269N-WFGWX-YVC9B-4J6C9-T83GX"
				}
				else
				{
					[System.Windows.Forms.MessageBox]::Show("Version de Windows non reconnue.", "Erreur")
					return
				}
				
				$upgradeResult = Upgrade-Windows -GenericProductKey $genericProductKey
				[System.Windows.Forms.MessageBox]::Show($upgradeResult, "Résultat de la mise à niveau")
			}
			else
			{
				[System.Windows.Forms.MessageBox]::Show("Ce système n'est pas en version Home. La mise à niveau n'est pas nécessaire.", "Information")
			}
		})
	
	# Ajouter les boutons à la fenêtre
	$form.Controls.Add($checkButton)
	$form.Controls.Add($activateButton)
	$form.Controls.Add($upgradeButton)
	
	# Afficher la fenêtre
	$form.ShowDialog()
}
#333333333333333333333333333333333333333333333333 Installation Infos diversses et Activation Office 333333333333333333333333333333333333333333333333333
function ActivationOffice
{
	Set-ExecutionPolicy Unrestricted -Force -Scope Process
	function global:JLog($m){ try { $jd=Join-Path $env:ProgramData "MultInstall"; if(-not(Test-Path $jd)){New-Item $jd -ItemType Directory -Force -ErrorAction SilentlyContinue|Out-Null}; Add-Content -Path (Join-Path $jd "journal.txt") -Value ("["+(Get-Date -Format "dd/MM HH:mm")+"] "+$m) -Encoding UTF8 -ErrorAction SilentlyContinue } catch {} }
	
	# Fonction Show-InputBox pour les dialogues de saisie
	function Show-InputBox
	{
		param (
			[string]$Prompt,
			[string]$Title = "Entrée",
			[string]$DefaultValue = ""
		)
		
		Add-Type -AssemblyName Microsoft.VisualBasic
		return [Microsoft.VisualBasic.Interaction]::InputBox($Prompt, $Title, $DefaultValue)
	}

	# Menu graphique cliquable (remplace la saisie clavier)
	function Show-OfficeMenu
	{
		Add-Type -AssemblyName System.Windows.Forms, System.Drawing
		$m = New-Object System.Windows.Forms.Form
		$m.Text = "Activation & Gestion Office"
		$m.Size = New-Object System.Drawing.Size(470, 580)
		$m.StartPosition = "CenterScreen"
		$m.FormBorderStyle = "FixedDialog"
		$m.MaximizeBox = $false; $m.MinimizeBox = $false
		$m.BackColor = [System.Drawing.Color]::FromArgb(243, 244, 246)

		$hdr = New-Object System.Windows.Forms.Panel
		$hdr.Dock = "Top"; $hdr.Height = 70
		$hdr.BackColor = [System.Drawing.Color]::FromArgb(2, 108, 79)
		$lbl = New-Object System.Windows.Forms.Label
		$lbl.Text = "Microsoft Office"
		$lbl.ForeColor = [System.Drawing.Color]::White
		$lbl.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 16)
		$lbl.AutoSize = $true
		$lbl.Location = New-Object System.Drawing.Point(22, 12)
		$sub = New-Object System.Windows.Forms.Label
		$sub.Text = "Activation et gestion de la licence"
		$sub.ForeColor = [System.Drawing.Color]::FromArgb(209, 250, 229)
		$sub.Font = New-Object System.Drawing.Font("Segoe UI", 9)
		$sub.AutoSize = $true
		$sub.Location = New-Object System.Drawing.Point(24, 44)
		$hdr.Controls.Add($lbl); $hdr.Controls.Add($sub)
		$m.Controls.Add($hdr)

		$script:officeChoice = "7"
		$defs = @(
			@{ n = "1"; t = "Afficher le statut d'activation"; c = [System.Drawing.Color]::FromArgb(37, 99, 235) },
			@{ n = "3"; t = "Activer une nouvelle cle"; c = [System.Drawing.Color]::FromArgb(22, 163, 74) },
			@{ n = "2"; t = "Supprimer une cle"; c = [System.Drawing.Color]::FromArgb(234, 88, 12) },
			@{ n = "6"; t = "Installer Office 2019 / 2024"; c = [System.Drawing.Color]::FromArgb(79, 70, 229) },
			@{ n = "5"; t = "Installer Comcom"; c = [System.Drawing.Color]::FromArgb(13, 148, 136) },
			@{ n = "4"; t = "Desinstaller Office (complet)"; c = [System.Drawing.Color]::FromArgb(220, 38, 38) }
		)
		$y = 88
		foreach ($d in $defs)
		{
			$b = New-Object System.Windows.Forms.Button
			$b.Text = "   " + $d.t
			$b.Tag = $d.n
			$b.Size = New-Object System.Drawing.Size(418, 54)
			$b.Location = New-Object System.Drawing.Point(20, $y)
			$b.FlatStyle = "Flat"; $b.FlatAppearance.BorderSize = 0
			$b.BackColor = $d.c; $b.ForeColor = [System.Drawing.Color]::White
			$b.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
			$b.TextAlign = "MiddleLeft"
			$b.Cursor = "Hand"
			$b.Add_Click({ $script:officeChoice = $this.Tag; $m.Close() })
			$m.Controls.Add($b)
			$y += 64
		}
		$bq = New-Object System.Windows.Forms.Button
		$bq.Text = "Fermer"
		$bq.Size = New-Object System.Drawing.Size(418, 40)
		$bq.Location = New-Object System.Drawing.Point(20, ($y + 6))
		$bq.FlatStyle = "Flat"; $bq.FlatAppearance.BorderSize = 1
		$bq.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(209, 213, 219)
		$bq.BackColor = [System.Drawing.Color]::FromArgb(229, 231, 235)
		$bq.ForeColor = [System.Drawing.Color]::FromArgb(31, 41, 55)
		$bq.Font = New-Object System.Drawing.Font("Segoe UI", 10)
		$bq.Cursor = "Hand"
		$bq.Add_Click({ $script:officeChoice = "7"; $m.Close() })
		$m.Controls.Add($bq)

		[void]$m.ShowDialog()
		return $script:officeChoice
	}
	
	# Déterminer le chemin vers ospp.vbs
	$path = if ([System.Environment]::Is64BitOperatingSystem)
	{
		"C:\Program Files\Microsoft Office\Office16\ospp.vbs"
	}
	else
	{
		"C:\Program Files (x86)\Microsoft Office\Office16\ospp.vbs"
	}
	
	while ($true)
	{
		$selection = Show-OfficeMenu
		
		switch ($selection)
		{
			1 {
				if (Test-Path -Path $path)
				{
					$output = & cscript.exe $path "/dstatus"
					[System.Windows.Forms.MessageBox]::Show($output)
					Add-Content -Path "$env:TEMP\logfile.txt" -Value "Statut Office Ok ok"; JLog "Office: statut d activation consulte"
				}
				else
				{
					[System.Windows.Forms.MessageBox]::Show("Office n'est pas installé.")
				}
			}
			2 {
				if (Test-Path -Path $path)
				{
					$key = Show-InputBox "Veuillez entrer la clé à supprimer" "Suppression de clé" ""
					$output = & cscript.exe $path "/unpkey:$key"
					Add-Content -Path "$env:TEMP\logfile.txt" -Value "Suppression clé Office Ok ok"; JLog ("Office: cle supprimee (" + $key + ")")
					[System.Windows.Forms.MessageBox]::Show($output)
				}
				else
				{
					[System.Windows.Forms.MessageBox]::Show("Office n'est pas installé.")
				}
			}
			3 {
				if (Test-Path -Path $path)
				{
					Start-Process -FilePath "msedge.exe" -ArgumentList "-inprivate", "http://licence.xwz.fr"
					$newKey = Show-InputBox "Veuillez entrer la nouvelle clé à activer" "Activation de clé" ""
					$output = & cscript.exe $path "/inpkey:$newKey"
					Add-Content -Path "$env:TEMP\logfile.txt" -Value "Activation Office Ok ok"; JLog ("Office: nouvelle cle activee (" + $newKey + ")")
					[System.Windows.Forms.MessageBox]::Show($output)
				}
				else
				{
					[System.Windows.Forms.MessageBox]::Show("Office n'est pas installé.")
				}
			}
			4 {
				# Vérifier les privilèges administrateur
				if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
				{
					Write-Host "Ce script doit être exécuté en tant qu'administrateur. Relancement..." -ForegroundColor Red
					Start-Process PowerShell.exe -Verb RunAs -ArgumentList ('-ExecutionPolicy Bypass -File "{0}"' -f $MyInvocation.MyCommand.Path)
					exit
				}
				
				Add-Type -AssemblyName System.Windows.Forms
				Add-Type -AssemblyName System.Drawing
				
				# Création de la fenêtre principale
				$formUninstall = New-Object System.Windows.Forms.Form
				$formUninstall.Text = "Désinstallation de Microsoft Office"
				$formUninstall.Size = New-Object System.Drawing.Size(600, 500)
				$formUninstall.StartPosition = "CenterScreen"
				$formUninstall.Font = New-Object System.Drawing.Font("Segoe UI", 10)
				
				# Zone de texte pour les logs
				$logBox = New-Object System.Windows.Forms.RichTextBox
				$logBox.Location = New-Object System.Drawing.Point(10, 10)
				$logBox.Size = New-Object System.Drawing.Size(565, 350)
				$logBox.ReadOnly = $true
				$logBox.BackColor = [System.Drawing.Color]::White
				$logBox.Font = New-Object System.Drawing.Font("Consolas", 10)
				$formUninstall.Controls.Add($logBox)
				
				# Bouton Analyser
				$analyzeButton = New-Object System.Windows.Forms.Button
				$analyzeButton.Location = New-Object System.Drawing.Point(10, 370)
				$analyzeButton.Size = New-Object System.Drawing.Size(200, 35)
				$analyzeButton.Text = "Analyser les installations"
				$formUninstall.Controls.Add($analyzeButton)
				
				# Bouton Désinstaller
				$uninstallButton = New-Object System.Windows.Forms.Button
				$uninstallButton.Location = New-Object System.Drawing.Point(220, 370)
				$uninstallButton.Size = New-Object System.Drawing.Size(200, 35)
				$uninstallButton.Text = "Désinstaller Office"
				$uninstallButton.Enabled = $false
				$formUninstall.Controls.Add($uninstallButton)
				
				# Bouton Fermer
				$closeButton = New-Object System.Windows.Forms.Button
				$closeButton.Location = New-Object System.Drawing.Point(430, 370)
				$closeButton.Size = New-Object System.Drawing.Size(145, 35)
				$closeButton.Text = "Fermer"
				$formUninstall.Controls.Add($closeButton)
				
				# Barre de progression
				$progressBar = New-Object System.Windows.Forms.ProgressBar
				$progressBar.Location = New-Object System.Drawing.Point(10, 420)
				$progressBar.Size = New-Object System.Drawing.Size(565, 23)
				$formUninstall.Controls.Add($progressBar)
				
				# Variable pour stocker les produits Office
				$script:officeProducts = $null
				
				# Fonction pour ajouter du texte
				function Add-LogText
				{
					param ($text,
						$type = "info")
					
					$logBox.SelectionStart = $logBox.TextLength
					$logBox.SelectionLength = 0
					
					switch ($type)
					{
						"info"    { $logBox.AppendText("$text`r`n") }
						"success" { $logBox.AppendText("✓ $text`r`n") }
						"warning" { $logBox.AppendText("⚠ $text`r`n") }
						"error"   { $logBox.AppendText("❌ $text`r`n") }
						default   { $logBox.AppendText("$text`r`n") }
					}
					
					$logBox.ScrollToCaret()
					[System.Windows.Forms.Application]::DoEvents()
				}
				
				# Fonction améliorée pour désinstaller Office 365
				function Uninstall-Office365
				{
					try
					{
						# Créer un dossier temporaire pour l'ODT
						$odtFolder = Join-Path $env:TEMP "ODT_$(Get-Random)"
						New-Item -ItemType Directory -Path $odtFolder -Force | Out-Null
						
						# URL mise à jour pour l'ODT
						$odtUrl = "https://www.microsoft.com/en-us/download/confirmation.aspx?id=49117"
						$odtPath = Join-Path $odtFolder "officedeploymenttool.exe"
						
						Add-LogText "Téléchargement de l'Office Deployment Tool..."
						
						# Télécharger l'ODT (méthode alternative)
						try
						{
							# Essayer de télécharger depuis l'URL directe
							$directUrl = "https://download.microsoft.com/download/2/7/A/27AF1BE6-DD20-4CB4-B154-EBAB8A7D4A7E/officedeploymenttool_17130-20162.exe"
							Invoke-WebRequest -Uri $directUrl -OutFile $odtPath -UseBasicParsing -TimeoutSec 30
						}
						catch
						{
							Add-LogText "Impossible de télécharger l'ODT. Essai avec SaRACmd..." "warning"
							
							# Alternative : utiliser SaRACmd si disponible
							$saraUrl = "https://aka.ms/SaRA_CommandLineVersionFiles"
							$saraPath = Join-Path $odtFolder "SaRACmd.exe"
							
							try
							{
								Invoke-WebRequest -Uri $saraUrl -OutFile $saraPath -UseBasicParsing -TimeoutSec 30
								
								Add-LogText "Utilisation de SaRACmd pour désinstaller Office..."
								$process = Start-Process -FilePath $saraPath -ArgumentList "-S OfficeScrubScenario -AcceptEula" -Wait -PassThru -NoNewWindow
								
								if ($process.ExitCode -eq 0)
								{
									Add-LogText "Office a été désinstallé avec succès via SaRACmd" "success"
									return $true
								}
							}
							catch
							{
								Add-LogText "Impossible d'utiliser SaRACmd" "error"
							}
						}
						
						if (Test-Path $odtPath)
						{
							Add-LogText "Extraction de l'outil..."
							Start-Process -FilePath $odtPath -ArgumentList "/quiet /extract:`"$odtFolder`"" -Wait
							
							# Créer un fichier XML de configuration plus complet
							$XMLPath = Join-Path $odtFolder "uninstall.xml"
							@"
<Configuration>
  <Remove All="TRUE">
    <Product ID="O365ProPlusRetail"/>
    <Product ID="O365BusinessRetail"/>
    <Product ID="O365HomePremRetail"/>
    <Product ID="VisioProRetail"/>
    <Product ID="ProjectProRetail"/>
  </Remove>
  <Display Level="None" AcceptEULA="TRUE"/>
  <Property Name="FORCEAPPSHUTDOWN" Value="TRUE"/>
  <Logging Level="Standard" Path="%temp%"/>
</Configuration>
"@ | Out-File -FilePath $XMLPath -Encoding UTF8
							
							$setupPath = Join-Path $odtFolder "setup.exe"
							
							if (Test-Path $setupPath)
							{
								Add-LogText "Désinstallation d'Office 365..."
								$process = Start-Process -FilePath $setupPath -ArgumentList "/configure `"$XMLPath`"" -Wait -PassThru -NoNewWindow
								
								if ($process.ExitCode -eq 0 -or $process.ExitCode -eq 3010)
								{
									Add-LogText "Office 365 a été désinstallé avec succès" "success"
									return $true
								}
								else
								{
									Add-LogText "Code de retour: $($process.ExitCode)" "warning"
									
									# Essayer avec l'outil de suppression forcée
									Add-LogText "Tentative de suppression forcée..."
									$process = Start-Process -FilePath $setupPath -ArgumentList "/uninstall O365ProPlusRetail /force" -Wait -PassThru -NoNewWindow
									
									if ($process.ExitCode -eq 0 -or $process.ExitCode -eq 3010)
									{
										Add-LogText "Office 365 a été désinstallé avec succès (forcé)" "success"
										return $true
									}
								}
							}
						}
						
						return $false
					}
					catch
					{
						Add-LogText "Erreur lors de la désinstallation d'Office 365: $_" "error"
						return $false
					}
					finally
					{
						if (Test-Path $odtFolder)
						{
							Remove-Item $odtFolder -Recurse -Force -ErrorAction SilentlyContinue
						}
					}
				}
				
				# Fonction pour nettoyer les résidus d'Office
				function Clean-OfficeResiduals
				{
					Add-LogText "Nettoyage des résidus d'Office..."
					
					# Arrêter les processus Office
					$officeProcesses = @("WINWORD", "EXCEL", "POWERPNT", "OUTLOOK", "ONENOTE", "MSACCESS", "MSPUB", "VISIO", "WINPROJ", "Teams")
					foreach ($process in $officeProcesses)
					{
						Get-Process -Name $process -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
					}
					
					# Nettoyer les clés de registre
					$registryPaths = @(
						"HKLM:\SOFTWARE\Microsoft\Office",
						"HKLM:\SOFTWARE\Wow6432Node\Microsoft\Office",
						"HKCU:\SOFTWARE\Microsoft\Office"
					)
					
					foreach ($path in $registryPaths)
					{
						if (Test-Path $path)
						{
							try
							{
								Remove-Item -Path "$path\ClickToRun" -Recurse -Force -ErrorAction SilentlyContinue
								Add-LogText "Nettoyage du registre: $path" "success"
							}
							catch
							{
								Add-LogText "Impossible de nettoyer: $path" "warning"
							}
						}
					}
					
					# Nettoyer les dossiers Office
					$folderPaths = @(
						"$env:ProgramFiles\Microsoft Office",
						"$env:ProgramFiles(x86)\Microsoft Office",
						"$env:ProgramData\Microsoft\Office"
					)
					
					foreach ($folder in $folderPaths)
					{
						if (Test-Path $folder)
						{
							try
							{
								Remove-Item -Path $folder -Recurse -Force -ErrorAction SilentlyContinue
								Add-LogText "Suppression du dossier: $folder" "success"
							}
							catch
							{
								Add-LogText "Impossible de supprimer: $folder" "warning"
							}
						}
					}
				}
				
				# Événement du bouton Analyser
				$analyzeButton.Add_Click({
						$logBox.Clear()
						$progressBar.Value = 0
						$progressBar.Style = "Marquee"
						
						Add-LogText "Recherche des produits Microsoft Office installés..."
						$script:officeProducts = @()
						
						# Vérifier Office 365/Microsoft 365
						$c2rConfig = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration' -ErrorAction SilentlyContinue
						if ($c2rConfig)
						{
							Add-LogText "Installation Office 365/Click-to-Run détectée" "warning"
							$script:officeProducts += @{
								DisplayName = "Microsoft 365 (Click-to-Run)"
								IsO365	    = $true
								Version	    = $c2rConfig.VersionToReport
								Platform    = $c2rConfig.Platform
							}
						}
						
						# Rechercher dans le registre
						$uninstallKeys = @(
							'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
							'HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
							'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*'
						)
						
						foreach ($keyPath in $uninstallKeys)
						{
							try
							{
								Get-ItemProperty -Path $keyPath -ErrorAction SilentlyContinue | ForEach-Object {
									if ($_.DisplayName -and $_.DisplayName -match 'Microsoft (Office|365)' -and $_.DisplayName -notmatch 'Viewer|Plugin|Service|Update')
									{
										$script:officeProducts += @{
											DisplayName	    = $_.DisplayName
											UninstallString = $_.UninstallString
											Version		    = $_.DisplayVersion
											Publisher	    = $_.Publisher
											IsO365		    = $false
										}
									}
								}
							}
							catch
							{
								Add-LogText "Erreur lors de la lecture de $keyPath : $_" "error"
							}
						}
						
						# Éliminer les doublons
						$script:officeProducts = $script:officeProducts | Sort-Object -Property DisplayName -Unique
						
						if ($script:officeProducts.Count -eq 0)
						{
							Add-LogText "Aucun produit Microsoft Office n'a été trouvé." "warning"
							$uninstallButton.Enabled = $false
						}
						else
						{
							Add-LogText "Produits Microsoft Office trouvés :"
							foreach ($product in $script:officeProducts)
							{
								Add-LogText "► $($product.DisplayName)"
								if ($product.Version)
								{
									Add-LogText "  Version: $($product.Version)"
								}
								if ($product.IsO365)
								{
									Add-LogText "  Type: Click-to-Run (Microsoft 365)"
									if ($product.Platform)
									{
										Add-LogText "  Plateforme: $($product.Platform)"
									}
								}
								Add-LogText ""
							}
							$uninstallButton.Enabled = $true
						}
						
						$progressBar.Style = "Continuous"
						$progressBar.Value = 100
					})
				
				# Événement du bouton Désinstaller
				$uninstallButton.Add_Click({
						$result = [System.Windows.Forms.MessageBox]::Show(
							"Voulez-vous vraiment désinstaller tous les produits Microsoft Office ?`n`nCette action est irréversible.",
							"Confirmation",
							[System.Windows.Forms.MessageBoxButtons]::YesNo,
							[System.Windows.Forms.MessageBoxIcon]::Warning)
						
						if ($result -eq [System.Windows.Forms.DialogResult]::Yes)
						{
							$logBox.Clear()
							$progressBar.Value = 0
							$uninstallButton.Enabled = $false
							$analyzeButton.Enabled = $false
							
							# Créer le dossier de log s'il n'existe pas
							if (-not (Test-Path "$env:TEMP"))
							{
								New-Item -ItemType Directory -Path "$env:TEMP" -Force | Out-Null
							}
							
							$logFile = "$env:TEMP\Office_Uninstall_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
							Add-LogText "Début de la désinstallation. Log enregistré dans: $logFile"
							
							$totalProducts = $script:officeProducts.Count
							$currentProduct = 0
							$hasErrors = $false
							
							# Désinstaller Office 365 en premier
							$office365Products = $script:officeProducts | Where-Object { $_.IsO365 }
							if ($office365Products)
							{
								Add-LogText "Début de la désinstallation de Microsoft 365..."
								$progressBar.Value = 10
								
								$success = Uninstall-Office365
								if (-not $success)
								{
									Add-LogText "La désinstallation de Microsoft 365 a échoué" "error"
									$hasErrors = $true
									
									# Proposer le nettoyage forcé
									$cleanResult = [System.Windows.Forms.MessageBox]::Show(
										"La désinstallation standard a échoué. Voulez-vous effectuer un nettoyage forcé ?",
										"Nettoyage forcé",
										[System.Windows.Forms.MessageBoxButtons]::YesNo,
										[System.Windows.Forms.MessageBoxIcon]::Question)
									
									if ($cleanResult -eq [System.Windows.Forms.DialogResult]::Yes)
									{
										Clean-OfficeResiduals
									}
								}
								else
								{
									Add-Content -Path $logFile -Value "$(Get-Date) - Microsoft 365 désinstallé avec succès"
								}
							}
							
							# Désinstaller les autres versions d'Office
							$standardProducts = $script:officeProducts | Where-Object { -not $_.IsO365 }
							foreach ($product in $standardProducts)
							{
								$currentProduct++
								$progressBar.Value = 50 + (($currentProduct / $totalProducts) * 40)
								
								Add-LogText "Désinstallation de $($product.DisplayName)..."
								
								try
								{
									$uninstallString = $product.UninstallString
									if ($uninstallString)
									{
										# Extraire le GUID si présent
										if ($uninstallString -match '{([0-9A-F-]+)}')
										{
											$productCode = $matches[0]
											$process = Start-Process "msiexec.exe" -ArgumentList "/x $productCode /qn REBOOT=ReallySuppress" -Wait -NoNewWindow -PassThru
											
											if ($process.ExitCode -eq 0 -or $process.ExitCode -eq 3010)
											{
												Add-LogText "Désinstallation réussie de $($product.DisplayName)" "success"
												Add-Content -Path $logFile -Value "$(Get-Date) - Désinstallation réussie : $($product.DisplayName)"
											}
											else
											{
												Add-LogText "Échec de la désinstallation avec le code : $($process.ExitCode)" "error"
												Add-Content -Path $logFile -Value "$(Get-Date) - Échec désinstallation : $($product.DisplayName) - Code $($process.ExitCode)"
												$hasErrors = $true
											}
										}
										elseif ($uninstallString -match '\.exe')
										{
											# Exécuter directement la commande de désinstallation
											$process = Start-Process -FilePath "cmd.exe" -ArgumentList "/c `"$uninstallString`" /quiet /norestart" -Wait -NoNewWindow -PassThru
											
											if ($process.ExitCode -eq 0 -or $process.ExitCode -eq 3010)
											{
												Add-LogText "Désinstallation réussie de $($product.DisplayName)" "success"
											}
											else
											{
												Add-LogText "Échec avec le code : $($process.ExitCode)" "error"
												$hasErrors = $true
											}
										}
									}
									else
									{
										Add-LogText "Aucune chaîne de désinstallation trouvée pour $($product.DisplayName)" "warning"
									}
								}
								catch
								{
									Add-LogText "Erreur lors de la désinstallation : $_" "error"
									Add-Content -Path $logFile -Value "$(Get-Date) - Erreur désinstallation : $($product.DisplayName) - $_"
									$hasErrors = $true
								}
							}
							
							$progressBar.Value = 100
							
							if ($hasErrors)
							{
								Add-LogText "`r`nDésinstallation terminée avec des erreurs. Consultez le log pour plus de détails." "warning"
								Add-LogText "Un redémarrage est recommandé."; JLog "Office: desinstallation complete (avec erreurs)"
							}
							else
							{
								Add-LogText "`r`nDésinstallation terminée avec succès !" "success"
								Add-LogText "Veuillez redémarrer votre ordinateur pour finaliser la désinstallation."; JLog "Office: desinstallation complete reussie"
							}
							
							Add-LogText "`r`nLog complet enregistré dans : $logFile"
							
							$analyzeButton.Enabled = $true
						}
					})
				
				# Événement du bouton Fermer
				$closeButton.Add_Click({
						$formUninstall.Close()
					})
				
				# Affichage de la fenêtre
				Add-LogText "Bienvenue dans l'outil de désinstallation Microsoft Office" "info"
				Add-LogText "Cliquez sur 'Analyser les installations' pour commencer" "info"
				$formUninstall.ShowDialog()
			}
			5 {
				Add-Type -AssemblyName System.Windows.Forms
				Add-Type -AssemblyName System.Drawing
				
				# Configuration
				$global:baseDir = "$env:TEMP\ODT"
				$global:configDir = "$baseDir\Configs"
				$global:setupPath = "$baseDir\setup.exe"
				
				# Création des répertoires
				New-Item -ItemType Directory -Force -Path $baseDir | Out-Null
				New-Item -ItemType Directory -Force -Path $configDir | Out-Null
				
				# Déterminer l'architecture du système
				$arch = if ([Environment]::Is64BitOperatingSystem) { "x64" }
				else { "x86" }
				$downloadUrl = "https://download.microsoft.com/download/2/7/A/27AF1BE6-DD20-4CB4-B154-EBAB8A7D4A7E/officedeploymenttool_18129-20030.exe"
				
				# Fonction de configuration XML pour Office
				function Create-ConfigurationXML
				{
					param ($Version,
						$LicenseType)
					
					$channel = if ($Version -eq "2019")
					{
						if ($LicenseType -eq "Retail") { "Perpetual2019" }
						else { "PerpetualVL2019" }
					}
					
					$productID = if ($Version -eq "2019")
					{
						if ($LicenseType -eq "Retail") { "ProPlus2019Retail" }
						else { "ProPlus2019Volume" }
					}
					
					$configPath = "$configDir\config-$Version-$LicenseType.xml"
					@"
<Configuration>
    <Add OfficeClientEdition="64" Channel="$channel">
        <Product ID="$productID">
            <Language ID="fr-fr" />
        </Product>
    </Add>
    <Display Level="Full" AcceptEULA="TRUE" />
</Configuration>
"@ | Out-File -FilePath $configPath -Encoding UTF8
					return $configPath
				}
				
				# Fonction d'installation Office
				function Install-Office
				{
					param ($Version,
						$LicenseType)
					
					try
					{
						Write-Host "Préparation de l'installation d'Office..."
						
						# Télécharger ODT si nécessaire
						if (-not (Test-Path $setupPath))
						{
							Write-Host "Téléchargement de l'outil de déploiement d'Office..."
							Invoke-WebRequest -Uri $downloadUrl -OutFile "$baseDir\ODT.exe" -UseBasicParsing -TimeoutSec 30
							Start-Process -FilePath "$baseDir\ODT.exe" -ArgumentList "/quiet /extract:$baseDir" -Wait -NoNewWindow
							
							if (-not (Test-Path $setupPath))
							{
								throw "Erreur : Impossible de trouver setup.exe après l'extraction."
							}
						}
						
						$configPath = Create-ConfigurationXML -Version $Version -LicenseType $LicenseType
						
						# Lancer l'installation
						Write-Host "Installation d'Office en cours..."
						$arguments = "/configure `"$configPath`""
						$process = Start-Process -FilePath $setupPath -ArgumentList $arguments -NoNewWindow -PassThru
						
						while (!$process.HasExited)
						{
							Start-Sleep -Seconds 5
						}
						
						if ($process.ExitCode -ne 0)
						{
							throw "Erreur lors de l'installation d'Office. Code de sortie : $($process.ExitCode)"
						}
						
						Write-Host "Office a été installé avec succès!"
						
						# Activation d'Office
						Write-Host "Activation de la licence Office..."
						$officeKey = Get-MultInstallKey -Name "OfficeVolumeKey" -Prompt "Clé de licence Office (volume)"
						cscript "C:\Program Files\Microsoft Office\Office16\OSPP.VBS" /inpkey:$officeKey
						cscript "C:\Program Files\Microsoft Office\Office16\OSPP.VBS" /act
					}
					catch
					{
						Write-Host "Erreur : $_"
					}
				}
				
				# Fonction d'installation ESET Endpoint Security
				function Install-ESET
				{
					try
					{
						Write-Host "Installation d'ESET Endpoint Security..."
						winget install "ESET.EndpointSecurity" -e -h
						
						Write-Host "Copie de la clé de licence ESET dans le presse-papier..."
						$licenseKey = Get-MultInstallKey -Name "ESETLicenseKey" -Prompt "Clé de licence ESET Endpoint Security"
						Set-Clipboard -Value $licenseKey
						Write-Host "La clé de licence a été copiée dans le presse-papier - Utilisez Ctrl+V pour la coller dans ESET"
					}
					catch
					{
						Write-Host "Erreur lors de l'installation d'ESET : $_"
					}
					
				}
				
				# Installation complète pour un client particulier
				Write-Host "Démarrage de l'installation complète pour le client particulier..."; JLog "Comcom: demarrage installation complete (Office + ESET)"
				Install-Office -Version "2019" -LicenseType "Volume"
				
				# S'assurer qu'Office est bien installé avant de continuer
				if ($?)
				{
					Install-ESET
				}
				
				Write-Host "Installation complète terminée."; JLog "Comcom: installation complete terminee"
				
				
			}
			6 {
				Add-Type -AssemblyName System.Windows.Forms
				Add-Type -AssemblyName System.Drawing
				
				# Configuration
				$global:baseDir = "$env:TEMP\ODT"
				$global:configDir = "$baseDir\Configs"
				$global:setupPath = "$baseDir\setup.exe"
				
				# Création des répertoires
				New-Item -ItemType Directory -Force -Path $baseDir | Out-Null
				New-Item -ItemType Directory -Force -Path $configDir | Out-Null
				
				# Déterminer l'architecture du système
				$arch = if ([Environment]::Is64BitOperatingSystem) { "x64" }
				else { "x86" }
				$downloadUrl = "https://download.microsoft.com/download/2/7/A/27AF1BE6-DD20-4CB4-B154-EBAB8A7D4A7E/officedeploymenttool_18129-20030.exe"
				
				# Interface principale
				$form = New-Object System.Windows.Forms.Form
				$form.Text = 'Installation Microsoft Office'
				$form.Size = New-Object System.Drawing.Size(400, 550) # Augmenté pour les nouveaux boutons
				$form.StartPosition = 'CenterScreen'
				
				# Label de statut
				$statusLabel = New-Object System.Windows.Forms.Label
				$statusLabel.Location = New-Object System.Drawing.Point(50, 470) # Déplacé vers le bas
				$statusLabel.Size = New-Object System.Drawing.Size(280, 20)
				$statusLabel.Text = "Prêt pour l'installation..."
				$form.Controls.Add($statusLabel)
				
				# Fonction de configuration XML
				function Create-ConfigurationXML
				{
					param ($Version,
						$LicenseType,
						$LTSC = $false)
					
					$channel = if ($Version -eq "2019")
					{
						if ($LicenseType -eq "Retail") { "Perpetual2019" }
						else { "PerpetualVL2019" }
					}
					elseif ($Version -eq "2021")
					{
						if ($LicenseType -eq "Retail") { "Perpetual2021" }
						else { "PerpetualVL2021" }
					}
					elseif ($Version -eq "2024")
					{
						if ($LTSC)
						{
							"PerpetualVL2024LTSC"
						}
						elseif ($LicenseType -eq "Retail") { "Perpetual2024" }
						else { "PerpetualVL2024" }
					}
					elseif ($Version -eq "365")
					{
						"Current" # Canal pour Office 365
					}
					
					$productID = if ($Version -eq "2019")
					{
						if ($LicenseType -eq "Retail") { "ProPlus2019Retail" }
						else { "ProPlus2019Volume" }
					}
					elseif ($Version -eq "2021")
					{
						if ($LicenseType -eq "Retail") { "ProPlus2021Retail" }
						else { "ProPlus2021Volume" }
					}
					elseif ($Version -eq "2024")
					{
						if ($LTSC)
						{
							"ProPlus2024Volume"
						}
						elseif ($LicenseType -eq "Retail") { "ProPlus2024Retail" }
						else { "ProPlus2024Volume" }
					}
					elseif ($Version -eq "365")
					{
						"O365ProPlusRetail"
					}
					
					$configSuffix = if ($LTSC)
					{
						"$Version-$LicenseType-LTSC"
					}
					else
					{
						"$Version-$LicenseType"
					}
					
					$configPath = "$configDir\config-$configSuffix.xml"
					@"
<Configuration>
    <Add OfficeClientEdition="64" Channel="$channel">
        <Product ID="$productID">
            <Language ID="fr-fr" />
        </Product>
    </Add>
    <Display Level="Full" AcceptEULA="TRUE" />
</Configuration>
"@ | Out-File -FilePath $configPath -Encoding UTF8
					return $configPath
				}
				
				# Fonction d'installation
				function Install-Office
				{
					param ($Version,
						$LicenseType,
						$LTSC = $false)
					
					try
					{
						$statusLabel.Text = "Préparation..."
						$form.Refresh()
						
						# Télécharger ODT si nécessaire
						if (-not (Test-Path $setupPath))
						{
							$statusLabel.Text = "Téléchargement ODT..."
							$form.Refresh()
							Invoke-WebRequest -Uri $downloadUrl -OutFile "$baseDir\ODT.exe" -UseBasicParsing -TimeoutSec 30
							Start-Process -FilePath "$baseDir\ODT.exe" -ArgumentList "/quiet /extract:$baseDir" -Wait -NoNewWindow
							
							if (-not (Test-Path $setupPath))
							{
								throw "Erreur : Impossible de trouver setup.exe après l'extraction."
							}
						}
						
						$configPath = Create-ConfigurationXML -Version $Version -LicenseType $LicenseType -LTSC $LTSC
						
						# Lancer l'installation
						$statusLabel.Text = "Installation d'Office en cours..."
						$form.Refresh()
						
						$arguments = "/configure `"$configPath`""
						$process = Start-Process -FilePath $setupPath -ArgumentList $arguments -NoNewWindow -PassThru
						
						while (!$process.HasExited)
						{
							Start-Sleep -Seconds 5
							$statusLabel.Text = "Installation en cours... Veuillez patienter."
							$form.Refresh()
						}
						
						if ($process.ExitCode -ne 0)
						{
							throw "Erreur lors de l'installation d'Office. Code de sortie : $($process.ExitCode)"
						}
						
						$statusLabel.Text = "Installation terminée!"; JLog "Office: installation Office 2019/2024 terminee"
						[System.Windows.Forms.MessageBox]::Show("Office a été installé avec succès!", "Installation terminée")
					}
					catch
					{
						$statusLabel.Text = "Erreur : $_"
						[System.Windows.Forms.MessageBox]::Show("Une erreur est survenue : $($_.Exception.Message)", "Erreur")
					}
				}
				
				# Création des boutons
				$buttonOffice2019Retail = New-Object System.Windows.Forms.Button
				$buttonOffice2019Retail.Location = New-Object System.Drawing.Point(50, 20)
				$buttonOffice2019Retail.Size = New-Object System.Drawing.Size(280, 40)
				$buttonOffice2019Retail.Text = "Office 2019 Retail"
				$buttonOffice2019Retail.Add_Click({ Install-Office -Version "2019" -LicenseType "Retail" })
				$form.Controls.Add($buttonOffice2019Retail)
				
				$buttonOffice2019Volume = New-Object System.Windows.Forms.Button
				$buttonOffice2019Volume.Location = New-Object System.Drawing.Point(50, 70)
				$buttonOffice2019Volume.Size = New-Object System.Drawing.Size(280, 40)
				$buttonOffice2019Volume.Text = "Office 2019 Volume"
				$buttonOffice2019Volume.Add_Click({ Install-Office -Version "2019" -LicenseType "Volume" })
				$form.Controls.Add($buttonOffice2019Volume)
				
				$buttonOffice2021Retail = New-Object System.Windows.Forms.Button
				$buttonOffice2021Retail.Location = New-Object System.Drawing.Point(50, 120)
				$buttonOffice2021Retail.Size = New-Object System.Drawing.Size(280, 40)
				$buttonOffice2021Retail.Text = "Office 2021 Retail"
				$buttonOffice2021Retail.Add_Click({ Install-Office -Version "2021" -LicenseType "Retail" })
				$form.Controls.Add($buttonOffice2021Retail)
				
				$buttonOffice2021Volume = New-Object System.Windows.Forms.Button
				$buttonOffice2021Volume.Location = New-Object System.Drawing.Point(50, 170)
				$buttonOffice2021Volume.Size = New-Object System.Drawing.Size(280, 40)
				$buttonOffice2021Volume.Text = "Office 2021 Volume"
				$buttonOffice2021Volume.Add_Click({ Install-Office -Version "2021" -LicenseType "Volume" })
				$form.Controls.Add($buttonOffice2021Volume)
				
				$buttonOffice2024Retail = New-Object System.Windows.Forms.Button
				$buttonOffice2024Retail.Location = New-Object System.Drawing.Point(50, 220)
				$buttonOffice2024Retail.Size = New-Object System.Drawing.Size(280, 40)
				$buttonOffice2024Retail.Text = "Office 2024 Retail"
				$buttonOffice2024Retail.Add_Click({ Install-Office -Version "2024" -LicenseType "Retail" })
				$form.Controls.Add($buttonOffice2024Retail)
				
				$buttonOffice2024Volume = New-Object System.Windows.Forms.Button
				$buttonOffice2024Volume.Location = New-Object System.Drawing.Point(50, 270)
				$buttonOffice2024Volume.Size = New-Object System.Drawing.Size(280, 40)
				$buttonOffice2024Volume.Text = "Office 2024 Volume"
				$buttonOffice2024Volume.Add_Click({ Install-Office -Version "2024" -LicenseType "Volume" })
				$form.Controls.Add($buttonOffice2024Volume)
				
				$buttonOffice2024LTSC = New-Object System.Windows.Forms.Button
				$buttonOffice2024LTSC.Location = New-Object System.Drawing.Point(50, 320)
				$buttonOffice2024LTSC.Size = New-Object System.Drawing.Size(280, 40)
				$buttonOffice2024LTSC.Text = "Office 2024 LTSC"
				$buttonOffice2024LTSC.Add_Click({ Install-Office -Version "2024" -LicenseType "Volume" -LTSC $true })
				$form.Controls.Add($buttonOffice2024LTSC)
				
				$buttonOffice365 = New-Object System.Windows.Forms.Button
				$buttonOffice365.Location = New-Object System.Drawing.Point(50, 370)
				$buttonOffice365.Size = New-Object System.Drawing.Size(280, 40)
				$buttonOffice365.Text = "Office 365"
				$buttonOffice365.Add_Click({ Install-Office -Version "365" -LicenseType "Retail" })
				$form.Controls.Add($buttonOffice365)
				
				# Bouton Quitter
				$quitButton = New-Object System.Windows.Forms.Button
				$quitButton.Location = New-Object System.Drawing.Point(50, 420)
				$quitButton.Size = New-Object System.Drawing.Size(280, 30)
				$quitButton.Text = 'Quitter'
				$quitButton.Add_Click({ $form.Close() })
				$form.Controls.Add($quitButton)
				
				# Lancement de l'interface
				$form.ShowDialog()
			}
			7 {
				return
			}
			default {
				[System.Windows.Forms.MessageBox]::Show("Vous avez quitté.")
				return
			}
		}
	}
}

#3939393939393939393939393939393939393939393939393939393939 Choix Fonctions à Executer 3939393939393939393939393939393939393939393939393939393939393939
function AlaChaine
{
	# Obtenir la taille de l'écran
	$screenWidth = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Width
	$screenHeight = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Height
	
	# Définir la taille de la fenêtre en fonction de la taille de l'écran
	$windowWidth = [int]($screenWidth * 0.3)
	$windowHeight = [int]($screenHeight * 0.3)
	
	# Créer une fenêtre pour afficher les fonctions à sélectionner
	$fenetre = New-Object System.Windows.Forms.Form
	$fenetre.Text = 'Choix des fonctions à exécuter'
	$fenetre.Size = New-Object System.Drawing.Size($windowWidth, $windowHeight)
	$fenetre.BackColor = [System.Drawing.Color]::white
	$fenetre.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
	
	$font = New-Object System.Drawing.Font("Times New Roman", 11)
	
	# Créer une liste de fonctions à choisir
	$fonctions = @(
		@{ Nom = "ProgBase" },
		@{ Nom = "OEMNOMPC" },
		@{ Nom = "RaccProgSys" }
	)
	
	# Parcourir la liste des fonctions et créer une case à cocher pour chacune
	for ($i = 0; $i -lt $fonctions.Length; $i++)
	{
		$checkBox = New-Object System.Windows.Forms.CheckBox
		$checkBox.Text = $fonctions[$i].Nom
		$checkBox.Top = 30 * $i
		$checkBox.Left = 30
		$checkBox.AutoSize = $true
		$checkBox.ForeColor = [System.Drawing.Color]::black
		$checkBox.BackColor = [System.Drawing.Color]::white
		$checkBox.Font = $font
		$fenetre.Controls.Add($checkBox)
	}
	
	# Créer un bouton "Exécuter"
	$button = New-Object System.Windows.Forms.Button
	$button.Text = 'Exécuter'
	$button.AutoSize = $true
	$button.BackColor = [System.Drawing.Color]::gray
	$button.ForeColor = [System.Drawing.Color]::White
	$button.Font = $font
	$button.Add_Click({
			$fenetre.Controls | Where-Object { $_ -is [System.Windows.Forms.CheckBox] -and $_.Checked } | ForEach-Object {
				$nomFonction = $_.Text
				& $nomFonction
			}
		})
	
	# Ajuster la position du bouton en fonction de la taille de la fenêtre
	$buttonTop = $fenetre.Height - 60
	$buttonLeft = ($fenetre.Width - $button.Width) / 2
	$button.Top = $buttonTop-40
	$button.Left = $buttonLeft
	
	$fenetre.Controls.Add($button)
	
	# Afficher la fenêtre
	$fenetre.ShowDialog()
}
#----------------------------------------------------------44------------------- Supression Fichiers --------------------------------44-------------------------
function Supression
{ Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	
	# Fonction pour calculer les dimensions en pourcentage de la taille de l'écran
	function Get-ScaledSize
	{
		param ($widthPercentage,
			$heightPercentage)
		$screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
		return New-Object System.Drawing.Size(
			[math]::Round($screen.Width * $widthPercentage),
			[math]::Round($screen.Height * $heightPercentage)
		)
	}
	
	$form = New-Object System.Windows.Forms.Form
	$form.Text = "Suppression de fichiers"
	$form.Size = Get-ScaledSize 0.25 0.20
	$form.MinimumSize = Get-ScaledSize 0.2 0.22
	$form.StartPosition = "CenterScreen"
	$form.Font = New-Object System.Drawing.Font("Segoe UI", 9)
	
	# Création d'un TableLayoutPanel pour une mise en page responsive
	$layout = New-Object System.Windows.Forms.TableLayoutPanel
	$layout.Dock = [System.Windows.Forms.DockStyle]::Fill
	$layout.ColumnCount = 3
	$layout.RowCount = 5
	$layout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 30)))
	$layout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 55)))
	$layout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 15)))
	for ($i = 0; $i -lt 4; $i++)
	{
		$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 22.5)))
	}
	$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 10))) # Pour le copyright
	$form.Controls.Add($layout)
	
	# Fonction pour créer et ajouter des contrôles au layout
	function Add-Control
	{
		param ($control,
			$row,
			$column,
			$columnSpan = 1)
		$control.Anchor = [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
		$control.Dock = [System.Windows.Forms.DockStyle]::Fill
		$layout.Controls.Add($control, $column, $row)
		$layout.SetColumnSpan($control, $columnSpan)
	}
	
	$sourceLabel = New-Object System.Windows.Forms.Label
	$sourceLabel.Text = "Dossier source :"
	$sourceLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
	Add-Control $sourceLabel 0 0
	
	$sourceTextBox = New-Object System.Windows.Forms.TextBox
	$sourceTextBox.Anchor = [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
	Add-Control $sourceTextBox 0 1
	
	$sourceBrowseButton = New-Object System.Windows.Forms.Button
	$sourceBrowseButton.Text = "Parcourir"
	$sourceBrowseButton.Add_Click({
			$folderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog
			if ($folderBrowser.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK)
			{
				$sourceTextBox.Text = $folderBrowser.SelectedPath
			}
		})
	Add-Control $sourceBrowseButton 0 2
	
	$dateLabel = New-Object System.Windows.Forms.Label
	$dateLabel.Text = "Date limite :"
	$dateLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
	Add-Control $dateLabel 1 0
	
	$dateTimePicker = New-Object System.Windows.Forms.DateTimePicker
	$dateTimePicker.Format = [System.Windows.Forms.DateTimePickerFormat]::Short
	$dateTimePicker.Anchor = [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
	Add-Control $dateTimePicker 1 1 2
	
	$startButton = New-Object System.Windows.Forms.Button
	$startButton.Text = "Démarrer la suppression"
	$startButton.Add_Click({
			$sourcePath = $sourceTextBox.Text
			$dateLimit = $dateTimePicker.Value.ToString("dd/MM/yyyy")
			$dateLimitObj = [datetime]::ParseExact($dateLimit, "dd/MM/yyyy", $null)
			
			if (-not (Test-Path $sourcePath))
			{
				[System.Windows.Forms.MessageBox]::Show("Le chemin source doit être valide.", "Erreur", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
				return
			}
			
			$logFile = Join-Path $sourcePath "suppression.log"
			"Début de la suppression: $(Get-Date)" | Set-Content $logFile
			
			function Remove-OldFiles
			{
				param ([string]$sourcePath)
				
				Get-ChildItem $sourcePath -Recurse | ForEach-Object {
					if (-not $_.PSIsContainer -and $_.LastWriteTime -lt $dateLimitObj)
					{
						Remove-Item $_.FullName -Force
						Add-Content $logFile "Suppression du fichier: $($_.FullName)"
					}
				}
			}
			
			Remove-OldFiles $sourcePath
			
			# Suppression des dossiers vides
			Get-ChildItem $sourcePath -Recurse -Directory | Where-Object { (Get-ChildItem $_.FullName).Count -eq 0 } | ForEach-Object {
				Remove-Item $_.FullName -Force
				Add-Content $logFile "Suppression du dossier vide: $($_.FullName)"
			}
			
			Add-Content $logFile "Fin de la suppression: $(Get-Date)"
			[System.Windows.Forms.MessageBox]::Show("La suppression est terminée. Consultez le fichier $logFile pour plus de détails.", "Suppression terminée", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
		})
	Add-Control $startButton 2 0 3
	
	# Ajout du label de copyright
	$copyrightLabel = New-Object System.Windows.Forms.Label
	$copyrightLabel.Text = "© 2024 StephanInformatique & C 3.5"
	$copyrightLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
	$copyrightLabel.Font = New-Object System.Drawing.Font("Segoe UI", 8, [System.Drawing.FontStyle]::Italic)
	Add-Control $copyrightLabel 4 0 3
	
	$form.Add_Closing({
			$result = [System.Windows.Forms.MessageBox]::Show("Êtes-vous sûr de vouloir quitter ?", "Confirmation", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
			if ($result -eq [System.Windows.Forms.DialogResult]::No)
			{
				$_.Cancel = $true
			}
		})
	
	$form.ShowDialog()
	
}

#----------------------------------------------------------45------------------- Archive Fichiers --------------------------------45-------------------------
function Archive
{
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	
	# Fonction pour calculer les dimensions en pourcentage de la taille de l'écran
	function Get-ScaledSize
	{
		param ($widthPercentage,
			$heightPercentage)
		$screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
		return New-Object System.Drawing.Size(
			[math]::Round($screen.Width * $widthPercentage),
			[math]::Round($screen.Height * $heightPercentage)
		)
	}
	
	$form = New-Object System.Windows.Forms.Form
	$form.Text = "Archivage de fichiers"
	$form.Size = Get-ScaledSize 0.25 0.20 # Légèrement augmenté pour accueillir le copyright
	$form.MinimumSize = Get-ScaledSize 0.2 0.22
	$form.StartPosition = "CenterScreen"
	$form.Font = New-Object System.Drawing.Font("Segoe UI", 9)
	
	# Création d'un TableLayoutPanel pour une mise en page responsive
	$layout = New-Object System.Windows.Forms.TableLayoutPanel
	$layout.Dock = [System.Windows.Forms.DockStyle]::Fill
	$layout.ColumnCount = 3
	$layout.RowCount = 6 # Augmenté à 6 pour inclure le copyright
	$layout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 30)))
	$layout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 55)))
	$layout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 15)))
	for ($i = 0; $i -lt 5; $i++)
	{
		$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 18)))
	}
	$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 10))) # Pour le copyright
	$form.Controls.Add($layout)
	
	# Fonction pour créer et ajouter des contrôles au layout
	function Add-Control
	{
		param ($control,
			$row,
			$column,
			$columnSpan = 1)
		$control.Anchor = [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
		$control.Dock = [System.Windows.Forms.DockStyle]::Fill
		$layout.Controls.Add($control, $column, $row)
		$layout.SetColumnSpan($control, $columnSpan)
	}
	
	$sourceLabel = New-Object System.Windows.Forms.Label
	$sourceLabel.Text = "Dossier source :"
	$sourceLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
	Add-Control $sourceLabel 0 0
	
	$sourceTextBox = New-Object System.Windows.Forms.TextBox
	$sourceTextBox.Anchor = [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
	Add-Control $sourceTextBox 0 1
	
	$sourceBrowseButton = New-Object System.Windows.Forms.Button
	$sourceBrowseButton.Text = "Parcourir"
	$sourceBrowseButton.Add_Click({
			$folderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog
			if ($folderBrowser.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK)
			{
				$sourceTextBox.Text = $folderBrowser.SelectedPath
			}
		})
	Add-Control $sourceBrowseButton 0 2
	
	$archiveLabel = New-Object System.Windows.Forms.Label
	$archiveLabel.Text = "Dossier archive :"
	$archiveLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
	Add-Control $archiveLabel 1 0
	
	$archiveTextBox = New-Object System.Windows.Forms.TextBox
	$archiveTextBox.Anchor = [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
	Add-Control $archiveTextBox 1 1
	
	$archiveBrowseButton = New-Object System.Windows.Forms.Button
	$archiveBrowseButton.Text = "Parcourir"
	$archiveBrowseButton.Add_Click({
			$folderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog
			if ($folderBrowser.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK)
			{
				$archiveTextBox.Text = $folderBrowser.SelectedPath
			}
		})
	Add-Control $archiveBrowseButton 1 2
	
	$dateLabel = New-Object System.Windows.Forms.Label
	$dateLabel.Text = "Date limite :"
	$dateLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
	Add-Control $dateLabel 2 0
	
	$dateTimePicker = New-Object System.Windows.Forms.DateTimePicker
	$dateTimePicker.Format = [System.Windows.Forms.DateTimePickerFormat]::Short
	$dateTimePicker.Anchor = [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
	Add-Control $dateTimePicker 2 1 2
	
	$startButton = New-Object System.Windows.Forms.Button
	$startButton.Text = "Démarrer l'archivage"
	$startButton.Add_Click({
			$sourcePath = $sourceTextBox.Text
			$archivePath = $archiveTextBox.Text
			$dateLimit = $dateTimePicker.Value.ToString("dd/MM/yyyy")
			$dateLimitObj = [datetime]::ParseExact($dateLimit, "dd/MM/yyyy", $null)
			
			if (-not (Test-Path $sourcePath) -or -not (Test-Path $archivePath))
			{
				[System.Windows.Forms.MessageBox]::Show("Les chemins source et archive doivent être valides.", "Erreur", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
				return
			}
			
			$logFile = Join-Path $archivePath "archive.log"
			"Début de l'archivage: $(Get-Date)" | Set-Content $logFile
			
			function Archive-Files
			{
				param ([string]$sourcePath,
					[string]$archivePath)
				
				Get-ChildItem $sourcePath -Recurse | ForEach-Object {
					$relativePath = $_.FullName.Substring($sourcePath.Length)
					$destinationPath = Join-Path $archivePath $relativePath
					
					if ($_.PSIsContainer)
					{
						if (-not (Test-Path $destinationPath))
						{
							New-Item -ItemType Directory -Path $destinationPath -Force | Out-Null
							Add-Content $logFile "Création du dossier: $destinationPath"
						}
					}
					elseif ($_.LastWriteTime -lt $dateLimitObj)
					{
						$destDir = Split-Path $destinationPath -Parent
						if (-not (Test-Path $destDir))
						{
							New-Item -ItemType Directory -Path $destDir -Force | Out-Null
							Add-Content $logFile "Création du dossier: $destDir"
						}
						Move-Item $_.FullName $destinationPath -Force
						Add-Content $logFile "Déplacement du fichier: $($_.FullName) vers $destinationPath"
					}
				}
			}
			
			Archive-Files $sourcePath $archivePath
			
			Add-Content $logFile "Fin de l'archivage: $(Get-Date)"
			[System.Windows.Forms.MessageBox]::Show("L'archivage est terminé. Consultez le fichier $logFile pour plus de détails.", "Archivage terminé", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
		})
	Add-Control $startButton 3 0 3
	
	# Ajout du label de copyright
	$copyrightLabel = New-Object System.Windows.Forms.Label
	$copyrightLabel.Text = "© 2024 StephanInformatique & C 3.5"
	$copyrightLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
	$copyrightLabel.Font = New-Object System.Drawing.Font("Segoe UI", 8, [System.Drawing.FontStyle]::Italic)
	Add-Control $copyrightLabel 5 0 3
	
	$form.Add_Closing({
			$result = [System.Windows.Forms.MessageBox]::Show("Êtes-vous sûr de vouloir quitter ?", "Confirmation", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
			if ($result -eq [System.Windows.Forms.DialogResult]::No)
			{
				$_.Cancel = $true
			}
		})
	
	$form.ShowDialog()
}
#-------------------------- commandes systeme 47 --------------------------------------------
function commandsys
{
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	
	$form = New-Object System.Windows.Forms.Form
	$form.Text = 'Outil de maintenance informatique avancé'
	$form.Size = New-Object System.Drawing.Size(610, 350)
	$form.StartPosition = 'CenterScreen'
	
	$commands = @{
		"Gestionnaire d'identifiants"	   = "credwiz.exe"
		"Connexions réseau"			       = "ncpa.cpl"
		"Gestionnaire de périphériques"    = "devmgmt.msc"
		"Panneau de configuration"		   = "control.exe"
		"Éditeur de registre"			   = "regedit.exe"
		"Observateur d'événements"		   = "eventvwr.msc"
		"Gestion des disques"			   = "diskmgmt.msc"
		"Services"						   = "services.msc"
		"Nettoyage de disque"			   = "cleanmgr.exe"
		"Configuration système"		       = "msconfig.exe"
		"Moniteur de ressources"		   = "resmon.exe"
		"Analyseur de performances"	       = "perfmon.exe"
		"Gestionnaire des tâches"		   = "taskmgr.exe"
		"Invite de commandes"			   = "cmd.exe"
		"PowerShell"					   = "powershell.exe"
		"Pare-feu Windows"				   = "firewall.cpl"
		"Outils d'administration"	    = { Start-Process "control.exe" -ArgumentList "/name Microsoft.AdministrativeTools" }
		
		"Options d'alimentation"		   = "powercfg.cpl"
		"Informations système"			   = "msinfo32.exe"
		"Vérificateur de fichiers système" = { Start-Process cmd -ArgumentList "/c sfc /scannow" -Verb RunAs }
		"Mise à jour Windows"		    = "ms-settings:windowsupdate"
		"Ping Google"				    = { Start-Process -FilePath "cmd.exe" -ArgumentList "/k ping google.com" }
		"Vider la corbeille"		    = {
			Clear-RecycleBin -Force -ErrorAction SilentlyContinue
			[System.Windows.Forms.MessageBox]::Show("La corbeille a été vidée.", "Succès")
		}
		"Scan Windows Defender"		    = {
			try
			{
				Start-MpScan -ScanType QuickScan
				[System.Windows.Forms.MessageBox]::Show("Scan rapide lancé.", "Windows Defender")
			}
			catch
			{
				[System.Windows.Forms.MessageBox]::Show("Erreur lors du lancement du scan : " + $_.Exception.Message, "Erreur")
			}
		}
		
	}
	
	$flowLayoutPanel = New-Object System.Windows.Forms.FlowLayoutPanel
	$flowLayoutPanel.Dock = [System.Windows.Forms.DockStyle]::Fill
	$flowLayoutPanel.WrapContents = $true
	$flowLayoutPanel.AutoScroll = $true
	
	# Fonction pour générer une couleur aléatoire pastel
	function Get-RandomPastelColor
	{
		$hue = Get-Random -Minimum 0 -Maximum 360
		$saturation = Get-Random -Minimum 25 -Maximum 50
		$lightness = Get-Random -Minimum 70 -Maximum 80
		
		$c = (1 - [Math]::Abs(2 * $lightness / 100 - 1)) * $saturation / 100
		$x = $c * (1 - [Math]::Abs(($hue / 60) % 2 - 1))
		$m = $lightness/100 - $c/2
		
		$r, $g, $b = 0, 0, 0
		if ($hue -lt 60) { $r, $g, $b = $c, $x, 0 }
		elseif ($hue -lt 120) { $r, $g, $b = $x, $c, 0 }
		elseif ($hue -lt 180) { $r, $g, $b = 0, $c, $x }
		elseif ($hue -lt 240) { $r, $g, $b = 0, $x, $c }
		elseif ($hue -lt 300) { $r, $g, $b = $x, 0, $c }
		else { $r, $g, $b = $c, 0, $x }
		
		$r = [Math]::Round(($r + $m) * 255)
		$g = [Math]::Round(($g + $m) * 255)
		$b = [Math]::Round(($b + $m) * 255)
		
		return [System.Drawing.Color]::FromArgb($r, $g, $b)
	}
	
	foreach ($command in $commands.GetEnumerator())
	{
		$button = New-Object System.Windows.Forms.Button
		$button.Size = New-Object System.Drawing.Size(180, 30)
		$button.Text = $command.Key
		$button.BackColor = Get-RandomPastelColor
		$button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
		$button.FlatAppearance.BorderSize = 0
		$button.Add_Click({
				$cmd = $commands[$this.Text]
				if ($cmd -is [scriptblock])
				{
					& $cmd
				}
				else
				{
					Start-Process $cmd
				}
			})
		$flowLayoutPanel.Controls.Add($button)
	}
	
	$form.Controls.Add($flowLayoutPanel)
	
	$form.ShowDialog()
}

function rdpsecupc
{
	$url = "https://stephaninformatique.fr/pws/rdpsecu.exe"
	$localFolder = "$env:TEMP"
	$exePath = Join-Path $localFolder "rdpsecu.exe"
	$batPath = Join-Path $localFolder "installer.bat"
	
	# Créer le dossier s'il n'existe pas
	if (-not (Test-Path -Path $localFolder))
	{
		New-Item -ItemType Directory -Path $localFolder | Out-Null
	}
	
	# Télécharger le fichier s'il n'existe pas déjà
	if (-not (Test-Path -Path $exePath))
	{
		Invoke-WebRequest -Uri $url -OutFile $exePath -UseBasicParsing -TimeoutSec 30
		
		if (Test-Path -Path $exePath)
		{
			$textBox.AppendText("Le fichier a été téléchargé avec succès." + [Environment]::NewLine)
		}
		else
		{
			$textBox.AppendText("Échec du téléchargement du fichier." + [Environment]::NewLine)
			return
		}
	}
	
	# Exécuter le fichier EXE (extraction auto ?)
	if (Test-Path -Path $exePath)
	{
		Start-Process -FilePath $exePath -Wait
	}
	else
	{
		$textBox.AppendText("Le fichier EXE n'a pas été trouvé." + [Environment]::NewLine)
		return
	}
	
	# Lancer le fichier batch après extraction
	if (Test-Path -Path $batPath)
	{
		Start-Process -FilePath $batPath -WorkingDirectory $localFolder -Wait
	}
	else
	{
		$textBox.AppendText("Le fichier installer.bat n'a pas été trouvé." + [Environment]::NewLine)
	}
	
	# Optionnel : supprimer les fichiers après
	# Remove-Item -Path $exePath -Force
}
function scanpc
{
	$url = "https://stephaninformatique.fr/pws/Copieur.exe"
	$desktopPath = [Environment]::GetFolderPath("Desktop")
	$exePath = Join-Path $desktopPath "Copieur.exe"
	$rootFolder = Join-Path $desktopPath "Copieur" # Dossier attendu après extraction
	$nestedFolder = Join-Path $rootFolder "Copieur" # Cas indésirable: Copieur\Copieur
	$batName = "createuseretdossierscan.bat"
	
	# Petit logger compatible textbox/console
	function _log([string]$m)
	{
		try { $textBox.AppendText($m + [Environment]::NewLine) }
		catch { Write-Host $m }
	}
	
	try
	{
		# Forcer TLS 1.2 (selon config machine)
		try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
		catch { }
		
		# Télécharger l'exécutable sur le BUREAU (pas dans Copieur)
		if (-not (Test-Path -Path $exePath))
		{
			_log "Téléchargement de Copieur.exe..."
			Invoke-WebRequest -Uri $url -OutFile $exePath -UseBasicParsing -TimeoutSec 30
			if (-not (Test-Path -Path $exePath))
			{
				_log "❌ Échec du téléchargement de Copieur.exe."
				return
			}
			try { Unblock-File -Path $exePath }
			catch { }
			_log "✅ Copieur.exe téléchargé."
		}
		else
		{
			_log "ℹ️ Copieur.exe déjà présent sur le Bureau."
		}
		
		# Lancer l'extraction depuis le Bureau (pour éviter Copieur\Copieur)
		_log "Extraction en cours..."
		Start-Process -FilePath $exePath -WorkingDirectory $desktopPath -Wait
		
		# À ce stade, l'extraction a normalement créé Desktop\Copieur
		if (-not (Test-Path -Path $rootFolder))
		{
			_log "❌ Le dossier '$rootFolder' n'a pas été créé par l'extraction."
			return
		}
		
		# Si un sous-dossier Copieur\Copieur existe, on aplatit
		if (Test-Path -Path $nestedFolder)
		{
			_log "⚠️ Structure imbriquée détectée (Copieur\\Copieur). Aplatissement..."
			Get-ChildItem -LiteralPath $nestedFolder -Force | ForEach-Object {
				Move-Item -LiteralPath $_.FullName -Destination $rootFolder -Force
			}
			Remove-Item -LiteralPath $nestedFolder -Recurse -Force
			_log "✅ Aplatissement effectué."
		}
		
		# Chercher le .bat (même si placé dans un sous-sous-dossier par erreur)
		$batFile = Get-ChildItem -Path $rootFolder -Filter $batName -Recurse -ErrorAction SilentlyContinue |
		Select-Object -First 1
		
		if ($null -eq $batFile)
		{
			_log "❌ Fichier '$batName' introuvable dans '$rootFolder'."
			return
		}
		
		_log "Exécution de $($batFile.FullName)..."
		Start-Process -FilePath $batFile.FullName -WorkingDirectory $batFile.DirectoryName -Wait
		_log "✅ Script terminé."
		
		# Optionnel : nettoyage de l'exécutable téléchargé
		# Remove-Item -LiteralPath $exePath -Force
		
	}
	catch
	{
		_log "❌ Erreur: $($_.Exception.Message)"
	}
}


MotDePasse

# Image de fond chargee depuis assets/background.bmp (evite d'embarquer un blob base64 dans le script)
$bgAsset = Join-Path $PSScriptRoot "assets\background.bmp"
$image = [System.Drawing.Bitmap]::FromFile($bgAsset)

# Créer le formulaire
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Launcher'
$form.Size = New-Object System.Drawing.Size(1150, 1080)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'None'

# Définir l'image comme l'arrière-plan du formulaire
$form.BackgroundImage = $image
$form.BackgroundImageLayout = 'Stretch' # Adaptez l'image au formulaire

# Fenetre deplacable (sans bordure) en cliquant-glissant sur le fond/le logo
$script:lnDrag = $false
$form.Add_MouseDown({ $script:lnDrag = $true; $script:lnStart = [System.Windows.Forms.Cursor]::Position; $script:lnLoc = $form.Location })
$form.Add_MouseMove({ if ($script:lnDrag) { $c = [System.Windows.Forms.Cursor]::Position; $form.Location = [System.Drawing.Point]::new($script:lnLoc.X + ($c.X - $script:lnStart.X), $script:lnLoc.Y + ($c.Y - $script:lnStart.Y)) } })
$form.Add_MouseUp({ $script:lnDrag = $false })

# Coins arrondis de la fenetre (look plus moderne) tout en gardant l'image
$lnGp = New-Object System.Drawing.Drawing2D.GraphicsPath
$lnRad = 22
$lnGp.AddArc(0, 0, $lnRad, $lnRad, 180, 90)
$lnGp.AddArc($form.Width - $lnRad, 0, $lnRad, $lnRad, 270, 90)
$lnGp.AddArc($form.Width - $lnRad, $form.Height - $lnRad, $lnRad, $lnRad, 0, 90)
$lnGp.AddArc(0, $form.Height - $lnRad, $lnRad, $lnRad, 90, 90)
$lnGp.CloseAllFigures()
$form.Region = New-Object System.Drawing.Region($lnGp)

# Définir la taille et le positionnement des boutons
$buttonWidth = 180 # Augmentation de la largeur des boutons
$buttonHeight = 40
$buttonsPerRow = 6 
$buttonSpacing = 9
$totalButtonWidth = $buttonsPerRow * $buttonWidth + ($buttonsPerRow + 1) * $buttonSpacing

# Définir le décalage vertical initial (20% de la hauteur du formulaire)
$offsetY = $form.Height * 0.22

# Fonction pour ajuster la taille de la police en fonction du texte
function Set-ButtonFont
{
	param (
		[System.Windows.Forms.Button]$Button,
		[string]$Text,
		[int]$DefaultSize = 8
	)
	
	$Button.Text = $Text
	$textLength = $Text.Length
	
	# Ajuster la taille de la police en fonction de la longueur du texte
	if ($textLength -gt 20)
	{
		$Button.Font = New-Object System.Drawing.Font("Arial", 6)
	}
	elseif ($textLength -gt 15)
	{
		$Button.Font = New-Object System.Drawing.Font("Arial", 7)
	}
	else
	{
		$Button.Font = New-Object System.Drawing.Font("Arial", $DefaultSize)
	}
	

}

#_____________________________14_________________________  Programmes par defaut (SetUserFTA) _____________________14_______________________________________
function ProgDefautTool
{
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $f = New-MaintWindow "Programmes par defaut" 820 600

    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 84; $pBot.BackColor = [System.Drawing.Color]::FromArgb(243, 244, 246); $f.Controls.Add($pBot)
    $clb = New-Object System.Windows.Forms.CheckedListBox; $clb.Dock = "Left"; $clb.Width = 300; $clb.CheckOnClick = $true
    $clb.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59); $clb.ForeColor = [System.Drawing.Color]::FromArgb(226, 232, 240); $clb.BorderStyle = "None"; $clb.Font = New-Object System.Drawing.Font("Segoe UI", 9); $f.Controls.Add($clb)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Fill"; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 9); $rtb.BorderStyle = "None"; $f.Controls.Add($rtb)

    # ===== Liste integree (editable) : Label / extensions ou protocoles / ProgID candidats par priorite =====
    $assoc = @(
        @{ Label = "Navigateur Web (http/https)";    Keys = @("http","https");                 Pat = @("^ChromeHTML$","^FirefoxURL","^MSEdgeHTM$","^BraveHTML$","^OperaStable") },
        @{ Label = "PDF (.pdf)";                      Keys = @(".pdf");                          Pat = @("^Acrobat\.Document","^AcroExch\.Document","^SumatraPDF","SumatraPDF\.exe","^MSEdgePDF$","^FoxitReader") },
        @{ Label = "Images (jpg/png/gif/bmp/webp)";   Keys = @(".jpg",".jpeg",".png",".gif",".bmp",".webp"); Pat = @("^IrfanView","FastStone","XnView","^PhotoViewer\.FileAssoc") },
        @{ Label = "Video (mp4/mkv/avi/mov)";         Keys = @(".mp4",".mkv",".avi",".mov");     Pat = @("^VLC\.","vlc\.exe","^WMP11\.AssocFile","PotPlayer","MPC-HC") },
        @{ Label = "Audio (mp3/flac/wav)";            Keys = @(".mp3",".flac",".wav");           Pat = @("^VLC\.","foobar","^WMP11\.AssocFile","AIMP") },
        @{ Label = "Archives (zip/7z/rar)";           Keys = @(".zip",".7z",".rar");             Pat = @("^7-Zip","^7zip","^WinRAR") }
    )
    foreach ($a in $assoc) { [void]$clb.Items.Add($a.Label, $true) }

    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Appliquer les defauts"; $btnGo.Location = New-Object System.Drawing.Point(12, 9); $btnGo.Size = New-Object System.Drawing.Size(200, 30)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(22, 163, 74); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnAll = New-Object System.Windows.Forms.Button; $btnAll.Text = "Tout cocher / decocher"; $btnAll.Location = New-Object System.Drawing.Point(220, 9); $btnAll.Size = New-Object System.Drawing.Size(170, 30)
    $btnAll.FlatStyle = "Flat"; $btnAll.FlatAppearance.BorderSize = 0; $btnAll.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnAll.ForeColor = "White"; $pBot.Controls.Add($btnAll)
    $btnSet = New-Object System.Windows.Forms.Button; $btnSet.Text = "Parametres Windows"; $btnSet.Location = New-Object System.Drawing.Point(398, 9); $btnSet.Size = New-Object System.Drawing.Size(170, 30)
    $btnSet.FlatStyle = "Flat"; $btnSet.FlatAppearance.BorderSize = 0; $btnSet.BackColor = [System.Drawing.Color]::FromArgb(2, 132, 199); $btnSet.ForeColor = "White"; $pBot.Controls.Add($btnSet)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(576, 9); $btnC.Size = New-Object System.Drawing.Size(90, 30)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(120, 53, 15); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $btnSet.Add_Click({ try { Start-Process "ms-settings:defaultapps" } catch {} })
    $btnAll.Add_Click({ $any = $false; for ($k=0;$k -lt $clb.Items.Count;$k++){ if (-not $clb.GetItemChecked($k)){ $any=$true; break } }; for ($k=0;$k -lt $clb.Items.Count;$k++){ $clb.SetItemChecked($k, $any) } }.GetNewClosure())

    $f.Tag.SendToBack(); $pBot.BringToFront(); $clb.BringToFront(); $rtb.BringToFront()

    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Red" { [System.Drawing.Color]::FromArgb(248,113,113) } "Gray" { [System.Drawing.Color]::FromArgb(148,163,184) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()

    # Classes enregistrees (pour resoudre les protocoles)
    $allClasses = @()
    try { $allClasses += Get-ChildItem "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes" -Name -ErrorAction SilentlyContinue } catch {}
    try { $allClasses += Get-ChildItem "Registry::HKEY_CURRENT_USER\SOFTWARE\Classes" -Name -ErrorAction SilentlyContinue } catch {}
    $allClasses = @($allClasses | Select-Object -Unique)

    $resolve = { param($key, $pats)
        $cands = @()
        if ($key.StartsWith(".")) {
            foreach ($root in @("Registry::HKEY_CURRENT_USER\SOFTWARE\Classes\$key\OpenWithProgids", "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\$key\OpenWithProgids")) {
                try { $it = Get-Item $root -ErrorAction Stop; $cands += @($it.GetValueNames() | Where-Object { $_ }) } catch {}
            }
            try { $dv = (Get-Item "Registry::HKEY_CLASSES_ROOT\$key" -ErrorAction Stop).GetValue(""); if ($dv) { $cands += $dv } } catch {}
        } else {
            $cands += $allClasses
        }
        $cands = @($cands | Select-Object -Unique)
        foreach ($p in $pats) { $m = $cands | Where-Object { $_ -match $p } | Select-Object -First 1; if ($m) { return $m } }
        return $null
    }.GetNewClosure()

    $btnGo.Add_Click({
        $btnGo.Enabled = $false; $rtb.Clear()
        & $log "===== PROGRAMMES PAR DEFAUT =====" "Cyan"
        # 1) Recuperer SetUserFTA
        $dir = "$env:TEMP\SetUserFTA"; $zip = "$env:TEMP\SetUserFTA.zip"; $exe = $null
        $exist = Get-ChildItem $dir -Recurse -Filter "SetUserFTA.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($exist) { $exe = $exist.FullName }
        if (-not $exe) {
            & $log "Telechargement de SetUserFTA..." "Gray"
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
            New-Item -Path $dir -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
            $urls = @("https://setuserfta.com/SetUserFTA.zip", "https://setuserfta.com/SetUserFTA_v1.8.3.zip", "https://kolbi.cz/SetUserFTA.zip")
            foreach ($u in $urls) {
                try {
                    Invoke-WebRequest -Uri $u -OutFile $zip -UseBasicParsing -TimeoutSec 40 -UserAgent "Mozilla/5.0"
                    Expand-Archive -Path $zip -DestinationPath $dir -Force
                    $exist = Get-ChildItem $dir -Recurse -Filter "SetUserFTA.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
                    if ($exist) { $exe = $exist.FullName; & $log ("Source : " + $u) "Gray"; break }
                } catch { & $log ("Echec : " + $u) "Yellow" }
            }
        }
        if (-not $exe) {
            & $log "SetUserFTA introuvable. Ouverture des Parametres Windows..." "Yellow"
            try { Start-Process "ms-settings:defaultapps" } catch {}
            $btnGo.Enabled = $true; return
        }
        & $log ("Outil pret : " + $exe) "Gray"; & $log "" "Gray"

        $nOk = 0; $nSkip = 0
        foreach ($a in $assoc) {
            if (-not ($clb.CheckedItems -contains $a.Label)) { continue }
            $pidsByKey = @{}
            foreach ($key in $a.Keys) {
                $progid = & $resolve $key $a.Pat
                if (-not $progid) { & $log ("  " + $key + " : aucune application compatible installee") "Yellow"; $nSkip++; continue }
                try {
                    $out = & $exe $key $progid 2>&1 | Out-String
                    if ($out -match "Successfully|succes|registered|set ") { & $log ("  " + $key + " -> " + $progid + " : OK") "Green" }
                    else { & $log ("  " + $key + " -> " + $progid) "Green" }
                    $nOk++
                } catch { & $log ("  " + $key + " -> " + $progid + " : erreur " + $_.Exception.Message) "Red" }
            }
        }
        & $log "" "Gray"
        & $log ("===== Termine : " + $nOk + " association(s) definie(s), " + $nSkip + " ignoree(s) =====") "Cyan"
        & $log "Astuce : si les icones ne changent pas, redemarrez l explorateur ou la session." "Gray"
        try { Add-Journal ("Programmes par defaut : " + $nOk + " association(s) appliquee(s)") } catch {}
        $btnGo.Enabled = $true
    }.GetNewClosure())

    $f.Add_Shown({ $f.Activate(); & $log "Coche les categories puis 'Appliquer les defauts'. Les ProgID installes sont detectes automatiquement." "Gray" }.GetNewClosure())
    [void]$f.ShowDialog()
}

#_____________________________  Aide-memoire technique  _____________________________________________
function AideMemoireTool
{
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $f = New-MaintWindow "Aide-memoire technique" 920 640

    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 52; $pBot.BackColor = [System.Drawing.Color]::FromArgb(243, 244, 246); $f.Controls.Add($pBot)
    $lst = New-Object System.Windows.Forms.ListBox; $lst.Dock = "Left"; $lst.Width = 320
    $lst.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59); $lst.ForeColor = [System.Drawing.Color]::FromArgb(226, 232, 240); $lst.BorderStyle = "None"; $lst.Font = New-Object System.Drawing.Font("Segoe UI", 9); $f.Controls.Add($lst)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Fill"; $rtb.ReadOnly = $true; $rtb.WordWrap = $false; $rtb.ScrollBars = "Both"
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 10); $rtb.BorderStyle = "None"; $f.Controls.Add($rtb)

    $snips = @()
    $c = @'
:: Reparation des fichiers systeme et de l'image Windows
sfc /scannow
DISM /Online /Cleanup-Image /RestoreHealth

# Astuce : si SFC dit "n'a pas reussi a demarrer le service de reparation",
# demarrer le service TrustedInstaller d'abord :
Set-Service -Name TrustedInstaller -StartupType Manual
Start-Service -Name TrustedInstaller
'@
    $snips += @{ T = "Reparation Windows - SFC / DISM"; C = $c }

    $c = @'
# Menu contextuel "classique" de Windows 10 sous Windows 11
New-Item -Path "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" -Force
Set-ItemProperty -Path "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" -Name "(default)" -Value ""
Stop-Process -Name explorer -Force
Start-Process explorer

# Pour revenir au menu Windows 11 :
# Remove-Item -Path "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}" -Recurse -Force
'@
    $snips += @{ T = "Menu contextuel Windows 10 (classique)"; C = $c }

    $c = @'
# Desactiver l'expiration des mots de passe (global)
net accounts /maxpwage:unlimited

# Par compte local (necessite le module LocalAccounts) :
Set-LocalUser -Name "NOM_DU_COMPTE" -PasswordNeverExpires $true

# Equivalent universel si le module manque :
wmic useraccount where "name='NOM_DU_COMPTE'" set PasswordExpires=FALSE
'@
    $snips += @{ T = "Expiration des mots de passe" ; C = $c }

    $c = @'
# Sauvegarde de tous les pilotes tiers
dism /online /export-driver /destination:C:\Sauvegarde_Pilotes
# ou
pnputil /export-driver * C:\Sauvegarde_Pilotes

# Copie vers un autre disque
copy C:\Sauvegarde_Pilotes D:\Sauvegarde_Pilotes

# Restauration / reinstallation des pilotes
pnputil /add-driver D:\Sauvegarde_Pilotes\*.inf /subdirs /install
'@
    $snips += @{ T = "Sauvegarde / restauration des pilotes"; C = $c }

    $c = @'
# Desinstallation complete d'Office (Click-to-Run + MSI + nettoyage)
$log = "C:\Windows\Temp\Office_Uninstall.log"
function Log { param([string]$m) "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - $m" | Out-File -Append $log }
Log "===== START ====="

# 1) Click-to-Run (Microsoft 365 / Retail)
$ctr = "$env:ProgramFiles\Common Files\Microsoft Shared\ClickToRun\OfficeClickToRun.exe"
if (Test-Path $ctr) {
    Start-Process $ctr -ArgumentList "scenario=install scenariosubtype=ARP sourcetype=None productstoremove=AllProducts displaylevel=False" -Wait
    Log "Click-to-Run desinstalle"
}

# 2) MSI (Volume / anciens Office)
$keys = @("HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*","HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*")
foreach ($k in $keys) {
    Get-ItemProperty $k -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like "*Office*" -and $_.UninstallString -like "*msiexec*" } | ForEach-Object {
        if ($_.PSChildName) { Start-Process "msiexec.exe" -ArgumentList "/x $($_.PSChildName) /qn /norestart" -Wait; Log "MSI supprime : $($_.PSChildName)" }
    }
}

# 3) Nettoyage fichiers + services
foreach ($p in @("$env:ProgramFiles\Microsoft Office","${env:ProgramFiles(x86)}\Microsoft Office")) { if (Test-Path $p) { Remove-Item $p -Recurse -Force -ErrorAction SilentlyContinue } }
Get-Service | Where-Object { $_.Name -like "*Office*" } | ForEach-Object { Stop-Service $_.Name -Force -ErrorAction SilentlyContinue }
Log "===== END ====="
'@
    $snips += @{ T = "Office - Desinstallation complete" ; C = $c }

    $c = @'
# Desinstallation ciblee d'Office par le registre

# Office 16 Click-to-Run
Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*, HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* |
  Where-Object { $_.DisplayName -like "*Office 16 Click-to-Run*" } |
  ForEach-Object { if ($_.UninstallString) { Start-Process "cmd.exe" -ArgumentList "/c $($_.UninstallString -replace '\"','') /quiet /norestart" -Wait } }

# Microsoft 365
Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*, HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* |
  Where-Object { $_.DisplayName -like "*Microsoft 365*" } |
  ForEach-Object { if ($_.UninstallString) { Start-Process "cmd.exe" -ArgumentList "/c $($_.UninstallString -replace '\"','') /quiet /norestart" -Wait } }

# OneNote
Get-ItemProperty "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*", "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*" |
  Where-Object { $_.DisplayName -like "*OneNote*" } |
  ForEach-Object { if ($_.UninstallString) { Start-Process cmd.exe -ArgumentList "/c $($_.UninstallString)" -Wait } }
'@
    $snips += @{ T = "Office - Desinstallation ciblee (registre)"; C = $c }

    $c = @'
# Reinstallation d'Office via l'Office Deployment Tool (ODT)
# Adapter les chemins vers setup.exe et configuration.xml
$odt = "C:\OfficeDeployment\setup.exe"
$xml = "C:\OfficeDeployment\configuration.xml"
if ((Test-Path $odt) -and (Test-Path $xml)) {
    Start-Process $odt -ArgumentList "/configure $xml" -Wait
} else {
    Write-Host "setup.exe ou configuration.xml manquant"
}
'@
    $snips += @{ T = "Office - Reinstallation via ODT (template)"; C = $c }

    $c = @'
# Desinstallation de OneDrive
$paths = @("$env:SystemRoot\System32\OneDriveSetup.exe","$env:SystemRoot\SysWOW64\OneDriveSetup.exe")
foreach ($p in $paths) { if (Test-Path $p) { Start-Process $p -ArgumentList "/uninstall" -Wait } }
'@
    $snips += @{ T = "OneDrive - Desinstallation" ; C = $c }

    foreach ($s in $snips) { [void]$lst.Items.Add($s.T) }

    $btnCopy = New-Object System.Windows.Forms.Button; $btnCopy.Text = "Copier le snippet"; $btnCopy.Location = New-Object System.Drawing.Point(12, 10); $btnCopy.Size = New-Object System.Drawing.Size(180, 30)
    $btnCopy.FlatStyle = "Flat"; $btnCopy.FlatAppearance.BorderSize = 0; $btnCopy.BackColor = [System.Drawing.Color]::FromArgb(22, 163, 74); $btnCopy.ForeColor = "White"; $pBot.Controls.Add($btnCopy)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(200, 10); $btnC.Size = New-Object System.Drawing.Size(90, 30)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(120, 53, 15); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })

    $f.Tag.SendToBack(); $pBot.BringToFront(); $lst.BringToFront(); $rtb.BringToFront()

    $show = { if ($lst.SelectedIndex -ge 0) { $rtb.Text = $snips[$lst.SelectedIndex].C } }.GetNewClosure()
    $lst.Add_SelectedIndexChanged({ & $show }.GetNewClosure())
    $btnCopy.Add_Click({ try { if ($rtb.Text) { [System.Windows.Forms.Clipboard]::SetText($rtb.Text) } } catch {} }.GetNewClosure())

    $lst.SelectedIndex = 0
    [void]$f.ShowDialog()
}

#_____________________________  Conversion .pub vers PDF  _____________________________________________
function PubToPdfTool
{
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $f = New-MaintWindow "Publisher (.pub) vers PDF" 800 600

    $pBot = New-Object System.Windows.Forms.Panel; $pBot.Dock = "Bottom"; $pBot.Height = 92; $pBot.BackColor = [System.Drawing.Color]::FromArgb(243, 244, 246); $f.Controls.Add($pBot)
    $rtb = New-Object System.Windows.Forms.RichTextBox; $rtb.Dock = "Bottom"; $rtb.Height = 150; $rtb.ReadOnly = $true
    $rtb.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42); $rtb.ForeColor = [System.Drawing.Color]::FromArgb(209, 213, 219); $rtb.Font = New-Object System.Drawing.Font("Consolas", 9); $rtb.BorderStyle = "None"; $f.Controls.Add($rtb)
    $lst = New-Object System.Windows.Forms.ListBox; $lst.Dock = "Fill"; $lst.SelectionMode = "MultiExtended"
    $lst.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59); $lst.ForeColor = [System.Drawing.Color]::FromArgb(226, 232, 240); $lst.BorderStyle = "None"; $lst.Font = New-Object System.Drawing.Font("Segoe UI", 9); $f.Controls.Add($lst)

    $log = { param($m, $c = "White") $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionColor = switch ($c) { "Green" { [System.Drawing.Color]::FromArgb(74,222,128) } "Cyan" { [System.Drawing.Color]::FromArgb(103,232,249) } "Yellow" { [System.Drawing.Color]::FromArgb(251,191,36) } "Red" { [System.Drawing.Color]::FromArgb(248,113,113) } "Gray" { [System.Drawing.Color]::FromArgb(148,163,184) } default { [System.Drawing.Color]::FromArgb(209,213,219) } }; $rtb.AppendText("$m`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents() }.GetNewClosure()

    $btnAdd = New-Object System.Windows.Forms.Button; $btnAdd.Text = "Ajouter des .pub"; $btnAdd.Location = New-Object System.Drawing.Point(12, 9); $btnAdd.Size = New-Object System.Drawing.Size(150, 30)
    $btnAdd.FlatStyle = "Flat"; $btnAdd.FlatAppearance.BorderSize = 0; $btnAdd.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235); $btnAdd.ForeColor = "White"; $pBot.Controls.Add($btnAdd)
    $btnFld = New-Object System.Windows.Forms.Button; $btnFld.Text = "Ajouter un dossier"; $btnFld.Location = New-Object System.Drawing.Point(170, 9); $btnFld.Size = New-Object System.Drawing.Size(150, 30)
    $btnFld.FlatStyle = "Flat"; $btnFld.FlatAppearance.BorderSize = 0; $btnFld.BackColor = [System.Drawing.Color]::FromArgb(2, 132, 199); $btnFld.ForeColor = "White"; $pBot.Controls.Add($btnFld)
    $btnClr = New-Object System.Windows.Forms.Button; $btnClr.Text = "Vider"; $btnClr.Location = New-Object System.Drawing.Point(328, 9); $btnClr.Size = New-Object System.Drawing.Size(90, 30)
    $btnClr.FlatStyle = "Flat"; $btnClr.FlatAppearance.BorderSize = 0; $btnClr.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81); $btnClr.ForeColor = "White"; $pBot.Controls.Add($btnClr)
    $btnGo = New-Object System.Windows.Forms.Button; $btnGo.Text = "Convertir en PDF"; $btnGo.Location = New-Object System.Drawing.Point(12, 49); $btnGo.Size = New-Object System.Drawing.Size(200, 32)
    $btnGo.FlatStyle = "Flat"; $btnGo.FlatAppearance.BorderSize = 0; $btnGo.BackColor = [System.Drawing.Color]::FromArgb(22, 163, 74); $btnGo.ForeColor = "White"; $pBot.Controls.Add($btnGo)
    $btnC = New-Object System.Windows.Forms.Button; $btnC.Text = "Fermer"; $btnC.Location = New-Object System.Drawing.Point(220, 49); $btnC.Size = New-Object System.Drawing.Size(100, 32)
    $btnC.FlatStyle = "Flat"; $btnC.FlatAppearance.BorderSize = 0; $btnC.BackColor = [System.Drawing.Color]::FromArgb(120, 53, 15); $btnC.ForeColor = "White"; $pBot.Controls.Add($btnC)
    $btnC.Add_Click({ $f.Close() })
    $btnClr.Add_Click({ $lst.Items.Clear() }.GetNewClosure())

    $f.Tag.SendToBack(); $pBot.BringToFront(); $rtb.BringToFront(); $lst.BringToFront()

    $btnAdd.Add_Click({
        $ofd = New-Object System.Windows.Forms.OpenFileDialog
        $ofd.Filter = "Publisher (*.pub)|*.pub|Tous (*.*)|*.*"; $ofd.Multiselect = $true
        if ($ofd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            foreach ($fn in $ofd.FileNames) { if (-not ($lst.Items -contains $fn)) { [void]$lst.Items.Add($fn) } }
        }
    }.GetNewClosure())
    $btnFld.Add_Click({
        $fbd = New-Object System.Windows.Forms.FolderBrowserDialog
        if ($fbd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            Get-ChildItem -Path $fbd.SelectedPath -Filter "*.pub" -Recurse -ErrorAction SilentlyContinue | ForEach-Object { if (-not ($lst.Items -contains $_.FullName)) { [void]$lst.Items.Add($_.FullName) } }
        }
    }.GetNewClosure())

    # Localiser LibreOffice
    $findSoffice = {
        foreach ($pp in @("$env:ProgramFiles\LibreOffice\program\soffice.exe", "${env:ProgramFiles(x86)}\LibreOffice\program\soffice.exe")) { if (Test-Path $pp) { return $pp } }
        $cmd = Get-Command soffice.exe -ErrorAction SilentlyContinue; if ($cmd) { return $cmd.Source }
        return $null
    }.GetNewClosure()

    $btnGo.Add_Click({
        if ($lst.Items.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show("Ajoutez des fichiers .pub."); return }
        $btnGo.Enabled = $false; $rtb.Clear()
        & $log "===== CONVERSION .PUB -> PDF =====" "Cyan"

        # Choix du moteur
        $engine = "none"; $pub = $null; $soffice = $null
        if (Test-Path "Registry::HKEY_CLASSES_ROOT\Publisher.Application") {
            try { $pub = New-Object -ComObject Publisher.Application -ErrorAction Stop; $engine = "pub"; & $log "Moteur : Microsoft Publisher (COM)" "Gray" } catch { $pub = $null }
        }
        if ($engine -eq "none") {
            $soffice = & $findSoffice
            if ($soffice) { $engine = "lo"; & $log "Moteur : LibreOffice (headless)" "Gray" }
        }
        if ($engine -eq "none") {
            & $log "Ni Publisher ni LibreOffice detectes." "Yellow"
            $r = [System.Windows.Forms.MessageBox]::Show("LibreOffice est requis pour convertir des .pub sans Publisher.`nL installer maintenant via winget ?", "Installation requise", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
            if ($r -eq [System.Windows.Forms.DialogResult]::Yes) {
                & $log "Installation de LibreOffice (patientez)..." "Cyan"
                try {
                    $p = Start-Process -FilePath "winget" -ArgumentList "install -e --id TheDocumentFoundation.LibreOffice --silent --accept-package-agreements --accept-source-agreements" -PassThru -WindowStyle Hidden
                    while (-not $p.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 300 }
                    $soffice = & $findSoffice
                    if ($soffice) { $engine = "lo"; & $log "LibreOffice installe." "Green" } else { & $log "Installation incomplete - relancez l outil." "Yellow" }
                } catch { & $log ("Echec installation : " + $_.Exception.Message) "Red" }
            }
        }
        if ($engine -eq "none") { $btnGo.Enabled = $true; return }

        $ok = 0; $ko = 0; $profDir = Join-Path $env:ProgramData "MultInstall\lo_profile"
        foreach ($file in @($lst.Items)) {
            if (-not (Test-Path $file)) { & $log ("  Introuvable : " + $file) "Yellow"; $ko++; continue }
            $out = [System.IO.Path]::ChangeExtension($file, ".pdf")
            & $log ("> " + [System.IO.Path]::GetFileName($file)) "White"
            try {
                if ($engine -eq "pub") {
                    $doc = $pub.Open($file, $false, $false)
                    try { $doc.ExportAsFixedFormat(2, $out) } catch { $doc.ExportAsFixedFormat(2, $out, 2) }
                    $doc.Close()
                    if (Test-Path $out) { & $log ("   OK -> " + $out) "Green"; $ok++ } else { & $log "   Echec (PDF non cree)" "Red"; $ko++ }
                } else {
                    $outdir = Split-Path $file -Parent
                    $prof = "-env:UserInstallation=file:///" + ($profDir -replace '\\', '/')
                    $argline = '--headless --norestore "' + $prof + '" --convert-to pdf --outdir "' + $outdir + '" "' + $file + '"'
                    $p = Start-Process -FilePath $soffice -ArgumentList $argline -WindowStyle Hidden -PassThru
                    while (-not $p.HasExited) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 250 }
                    if (Test-Path $out) { & $log ("   OK -> " + $out) "Green"; $ok++ } else { & $log "   Echec (verifiez que le .pub n est pas corrompu)" "Red"; $ko++ }
                }
            } catch { & $log ("   Erreur : " + $_.Exception.Message) "Red"; $ko++ }
        }
        if ($pub) { try { $pub.Quit() } catch {}; try { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($pub) | Out-Null } catch {} }
        & $log "" "Gray"
        & $log ("===== Termine : " + $ok + " converti(s), " + $ko + " echec(s) =====") "Cyan"
        try { Add-Journal ("Conversion PUB->PDF : " + $ok + " fichier(s)") } catch {}
        $btnGo.Enabled = $true
    }.GetNewClosure())

    $f.Add_Shown({ $f.Activate(); & $log "Ajoutez des .pub puis 'Convertir'. Le PDF est cree a cote du fichier source." "Gray" }.GetNewClosure())
    [void]$f.ShowDialog()
}

# Créer les boutons et les ajouter au formulaire
for ($i = 0; $i -lt 54; $i++)
{
	$button = New-Object RoundButton
	$button.Size = New-Object System.Drawing.Size($buttonWidth, $buttonHeight)

	# Calculer la position X pour centrer les boutons
	$offsetX = ($form.Width - $totalButtonWidth) / 2 + (($buttonWidth + $buttonSpacing) * ($i % $buttonsPerRow))

	$button.Location = New-Object System.Drawing.Point([Math]::Round($offsetX), [Math]::Round($offsetY + ($buttonHeight + 10) * [Math]::Floor($i / $buttonsPerRow)))
	
	
	
	# Permettre le retour à la ligne automatique dans les boutons
	$button.UseMnemonic = $false
	if ($i -eq 0)
	{
		$button.Text = "Infos Ordinateur"
		$button.BackColor = [System.Drawing.Color]::FromArgb(2, 132, 199)
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({ try { InfosPC } catch { [System.Windows.Forms.MessageBox]::Show("Erreur : " + $_.Exception.Message) } })
	}
	elseif ($i -eq 1)
	{
		$button.Text = "Maintenance & Securite"
		$button.BackColor = [System.Drawing.Color]::FromArgb(2, 108, 79)
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({ try { MaintenanceHub } catch { [System.Windows.Forms.MessageBox]::Show("Erreur : " + $_.Exception.Message) } })
	}
	elseif ($i -eq 2)
	{
		$button.Text = "Programmes de bases"
		$button.Refresh() # Rafraîchir le bouton
		
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Blue
		$button.ForeColor = [System.Drawing.Color]::White
		
		$button.Add_Click({
				$funcSrc = ${function:ProgBaseWin}.ToString()
				$iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
				$rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace($iss)
				$rs.ApartmentState = "STA"; $rs.ThreadOptions = "ReuseThread"; $rs.Open()
				$ps = [System.Management.Automation.PowerShell]::Create()
				$ps.Runspace = $rs
				$null = $ps.AddScript('param($src) $env:PSModulePath = "$PSHOME\Modules;" + $env:PSModulePath; Add-Type -AssemblyName System.Windows.Forms,System.Drawing; & ([ScriptBlock]::Create($src))').AddParameter('src', $funcSrc).BeginInvoke()
			})
	}
	elseif ($i -eq 3)
	{
		$button.Text = "PILOTES bis"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Blue
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				$funcBody = ${function:PilotesBis}
				$rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
				$rs.ApartmentState = "STA"; $rs.Open()
				$ps = [System.Management.Automation.PowerShell]::Create()
				$ps.Runspace = $rs
				$null = $ps.AddScript('param($f) Add-Type -AssemblyName System.Windows.Forms,System.Drawing; & $f').AddParameter('f', $funcBody).BeginInvoke()
			})
	}
	elseif ($i -eq 4)
	{
		
		$button.Text = "OEM+NomPC"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Blue
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				Invoke-BgFunc ${function:OEMNOMPC} "OEM + Nom PC"
			})
	}
	elseif ($i -eq 5)
	{
		# Si c'est le troisième bouton
		$button.Text = "RACC PR+SYS"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Blue
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				Invoke-BgFunc ${function:RaccProgSys} "Raccourcis Programmes + Systeme"
			})
	}
	elseif ($i -eq 6)
	{
		$button.Text = "THEME"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Blue
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				$funcBody = ${function:Theme}
				$rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
				$rs.ApartmentState = "STA"; $rs.Open()
				$ps = [System.Management.Automation.PowerShell]::Create()
				$ps.Runspace = $rs
				$null = $ps.AddScript('param($f) Add-Type -AssemblyName System.Windows.Forms,System.Drawing; & $f').AddParameter('f', $funcBody).BeginInvoke()
			})
	}
	elseif ($i -eq 7)
	{
		$button.Text = "PUB -> PDF"
		$button.BackColor = [System.Drawing.Color]::FromArgb(126, 34, 206)
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({ try { PubToPdfTool } catch { [System.Windows.Forms.MessageBox]::Show("Erreur : " + $_.Exception.Message) } })
	}
	elseif ($i -eq 8)
	{
		
		$button.Text = "Choix Logiciel Supp"
		$button.Refresh() # Rafraîchir le bouton
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Violet
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				# IMPORTANT : on passe le code source en TEXTE (.ToString()) et on le recompile
				# dans le nouveau runspace via [ScriptBlock]::Create(). Passer le ScriptBlock vivant
				# (${function:ChoixLogSupp}) garde une affinité avec le runspace principal :
				# les événements WinForms (Shown, Resize, CheckedChanged...) tentent alors de
				# s'exécuter dans le runspace principal occupé -> la fenêtre se fige (deadlock).
				$funcSrc = ${function:ChoixLogSupp}.ToString()
				$rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
				$rs.ApartmentState = "STA"; $rs.ThreadOptions = "ReuseThread"; $rs.Open()
				$ps = [System.Management.Automation.PowerShell]::Create()
				$ps.Runspace = $rs
				$null = $ps.AddScript('param($src) Add-Type -AssemblyName System.Windows.Forms,System.Drawing; & ([ScriptBlock]::Create($src))').AddParameter('src', $funcSrc).BeginInvoke()
			})
	}
	elseif ($i -eq 9)
	{
		
		
		
		
		$button.Text = "ONE DRIVE OFF"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::RED
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				
				onedriveoff
			})
	}
	elseif ($i -eq 10)
	{
		# Si c'est le deuxième bouton
		
		$button.Text = "Menu Win11 QuickBoost.exe"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Blue
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				MenuQuickBoost
			})
	}
	elseif ($i -eq 11)
	{
		# Si c'est le deuxième bouton
		$button.Text = "Win Repair Quick"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Blue
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				# Exécution dans un thread STA séparé → la fenêtre principale reste réactive
				$funcBody = ${function:WinRepairQuick}
				$rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
				$rs.ApartmentState = "STA"; $rs.Open()
				$ps = [System.Management.Automation.PowerShell]::Create()
				$ps.Runspace = $rs
				$null = $ps.AddScript('param($f) Add-Type -AssemblyName System.Windows.Forms,System.Drawing; & $f').AddParameter('f', $funcBody).BeginInvoke()
			})
	}
	elseif ($i -eq 12)
	{
		$button.Text = "AUDIT"
		$button.Refresh() # Rafraîchir le bouton
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::LawnGreen
		$button.ForeColor = [System.Drawing.Color]::gray
		$button.Add_Click({ try { AuditSecurite } catch { [System.Windows.Forms.MessageBox]::Show("Erreur : " + $_.Exception.Message) } })
	}
	elseif ($i -eq 32)
	{
		# Si c'est le deuxième bouton
		
		$button.Text = "Activation Windows"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Black
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				$funcBody = ${function:ActivationWindows}
				$rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
				$rs.ApartmentState = "STA"; $rs.Open()
				$ps = [System.Management.Automation.PowerShell]::Create()
				$ps.Runspace = $rs
				$null = $ps.AddScript('param($f) Add-Type -AssemblyName System.Windows.Forms,System.Drawing; & $f').AddParameter('f', $funcBody).BeginInvoke()
			})
	}
	elseif ($i -eq 33)
	{
		$button.Text = "Activation Office"
		$button.BackColor = [System.Drawing.Color]::Black
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				$funcBody = ${function:ActivationOffice}
				$rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
				$rs.ApartmentState = "STA"; $rs.Open()
				$ps = [System.Management.Automation.PowerShell]::Create()
				$ps.Runspace = $rs
				$null = $ps.AddScript('param($f) Add-Type -AssemblyName System.Windows.Forms,System.Drawing; & $f').AddParameter('f', $funcBody).BeginInvoke()
			})
	}
	elseif ($i -eq 48)
	{
		$button.Text = "Expiration MDP"
		$button.BackColor = [System.Drawing.Color]::Black
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				ExpirationMdp
			})
	}
	elseif ($i -eq 49)
	{
		$button.Text = "Gest. IMP & +"
		$button.BackColor = [System.Drawing.Color]::Fuchsia
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				$funcBody = ${function:gestimp}
				$rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
				$rs.ApartmentState = "STA"; $rs.Open()
				$ps = [System.Management.Automation.PowerShell]::Create()
				$ps.Runspace = $rs
				$null = $ps.AddScript('param($f) Add-Type -AssemblyName System.Windows.Forms,System.Drawing; & $f').AddParameter('f', $funcBody).BeginInvoke()
			})
	}
	elseif ($i -eq 50)
	{
		$button.Text = "Migration Pc&+"
		$button.BackColor = [System.Drawing.Color]::Yellow
		$button.ForeColor = [System.Drawing.Color]::Black
		$button.Add_Click({
				$funcBody = ${function:migrationpc}
				$rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
				$rs.ApartmentState = "STA"; $rs.Open()
				$ps = [System.Management.Automation.PowerShell]::Create()
				$ps.Runspace = $rs
				$null = $ps.AddScript('param($f) Add-Type -AssemblyName System.Windows.Forms,System.Drawing; & $f').AddParameter('f', $funcBody).BeginInvoke()
			})
	}
	elseif ($i -eq 51)
	{
		$button.Text = "Install Scan sur PC"
		$button.BackColor = [System.Drawing.Color]::GreenYellow
		$button.ForeColor = [System.Drawing.Color]::Black
		$button.Add_Click({
				scanpc
			})
	}
	elseif ($i -eq 52)
	{
		$button.Text = "Install RDP Secu"
		$button.BackColor = [System.Drawing.Color]::BlueViolet
		$button.ForeColor = [System.Drawing.Color]::Black
		$button.Add_Click({
				rdpsecupc
			})
	}
	elseif ($i -eq 39)
	{
		
		
		$button.Text = "A LA CHAINE"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::red
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				
				AlaChaine
			})
	}
	elseif ($i -eq 42)
	{
		$button.Text = "Recup Nom PC HL"
		$button.BackColor = [System.Drawing.Color]::RED
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({ try { RecupNomPcHL } catch { [System.Windows.Forms.MessageBox]::Show("Erreur : " + $_.Exception.Message) } })
	}
	
	elseif ($i -eq 43)
	{
		# Deplace a cote de AUDIT (i=13) -> slot masque
		$button.Visible = $false
	}
	
	elseif ($i -eq 44)
	{
		
		
		$button.Text = "Suppression Fichiers"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Aquamarine
		$button.ForeColor = [System.Drawing.Color]::Gray
		$button.Add_Click({
				
				Supression
			})
	}
	
	elseif ($i -eq 45)
	{
		
		
		$button.Text = "Archive Fichiers"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Aquamarine
		$button.ForeColor = [System.Drawing.Color]::Gray
		$button.Add_Click({
				
				Archive
			})
	}
	
	elseif ($i -eq 46)
	{
		$button.Text = "SuppDrv"
		$button.BackColor = [System.Drawing.Color]::OrangeRed
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({ Start-PortableTool "https://github.com/lostindark/DriverStoreExplorer/releases/download/v0.11.92/DriverStoreExplorer.v0.11.92.zip" "DriverStoreExplorer.zip" "*.exe" "DriverStore Explorer (SuppDrv)" })
	}
	
	elseif ($i -eq 47)
	{
		
		
		$button.Text = "Commandes Sys"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::RED
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				
				commandsys
			})
	}
	elseif ($i -eq 26)
	{
		$button.Text = "W.REPAIR TOOLBOX"
		$button.BackColor = [System.Drawing.Color]::OrangeRed
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({ Start-PortableTool "https://windows-repair-toolbox.com/download/click.php?id=Windows_Repair_Toolbox" "Windows_Repair_Toolbox.zip" "Windows_Repair_Toolbox.exe" "Windows Repair Toolbox" })
	}
	
	elseif ($i -eq 29)
	{
		$button.Text = "Pilotes Tools"
		$button.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 8)
		$button.BackColor = [System.Drawing.Color]::LightGreen
		$button.ForeColor = [System.Drawing.Color]::Black
		$button.Add_Click({ try { PilotesTool } catch { [System.Windows.Forms.MessageBox]::Show("Erreur : " + $_.Exception.Message) } })
	}
	elseif ($i -eq 37)
	{
		$button.Text = "Nettoyage (DISM)"
		$button.Refresh() # Rafraîchir le bouton
		
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Orchid
		$button.ForeColor = [System.Drawing.Color]::White
		
		$button.Add_Click({
				# Nettoyer le répertoire Temp...
				$textBox.AppendText("Nettoyage du répertoire Temp..." + [Environment]::NewLine)
				$tempDir = [System.IO.Path]::GetTempPath()
				Get-ChildItem -Path $tempDir -Recurse | ForEach-Object {
					try
					{
						Remove-Item $_.FullName -Force -Recurse -ErrorAction Stop
						$textBox.AppendText("Suppression de : $($_.FullName)" + [Environment]::NewLine)
					}
					catch
					{
						$textBox.AppendText("Impossible de supprimer $($_.FullName) : $($_.Exception.Message)" + [Environment]::NewLine)
					}
				}
				Add-Content -Path "$env:TEMP\logfile.txt" -Value "Nettoyage Tmp ok"
				
				# Nettoyer le cache DNS
				$textBox.AppendText("Nettoyage du cache DNS..." + [Environment]::NewLine)
				Clear-DnsClientCache
				Add-Content -Path "$env:TEMP\logfile.txt" -Value "Cache DNS ok"
				
				# Supprimer les anciennes versions de Windows
				$textBox.AppendText("Suppression des anciennes versions de Windows..." + [Environment]::NewLine)
				dism /online /cleanup-image /startcomponentcleanup
				dism /online /cleanup-image /spsuperseded
				Add-Content -Path "$env:TEMP\logfile.txt" -Value "Supp Old Windows ok"
				
				# Supprimer les anciens fichiers de hibernation et de mise en veille prolongée
				$textBox.AppendText("Suppression des anciens fichiers de hibernation et de mise en veille prolongée..." + [Environment]::NewLine)
				powercfg /h off
				powercfg /h on
				Add-Content -Path "$env:TEMP\logfile.txt" -Value "Supp Hib Veille prolongée ok"
				
				# Supprimer les fichiers journaux
				$textBox.AppendText("Suppression des fichiers journaux..." + [Environment]::NewLine)
				Get-ChildItem -Path "C:\Windows\Logs\*" -Include *.log, *.etl -Recurse | ForEach-Object {
					try
					{
						Remove-Item $_.FullName -Force -ErrorAction Stop
						$textBox.AppendText("Suppression de : $($_.FullName)" + [Environment]::NewLine)
					}
					catch
					{
						$textBox.AppendText("Impossible de supprimer $($_.FullName) : $($_.Exception.Message)" + [Environment]::NewLine)
					}
				}
				Add-Content -Path "$env:TEMP\logfile.txt" -Value "Supp Fichiers Journaux ok"
				
				# Nettoyer le cache de mise à jour de Windows
				$textBox.AppendText("Nettoyage du cache de mise à jour de Windows..." + [Environment]::NewLine)
				Stop-Service -Name wuauserv
				Remove-Item -Path "C:\Windows\SoftwareDistribution\*" -Recurse -Force -ErrorAction SilentlyContinue
				Start-Service -Name wuauserv
				Add-Content -Path "$env:TEMP\logfile.txt" -Value "Supp Cache MAJ Windows ok"
				
				$textBox.AppendText("Nettoyage terminé." + [Environment]::NewLine)
			})
	}
	
	elseif ($i -eq 28)
	{
		# Si c'est le troisième bouton
		
		$button.Text = "O&&O AppBuster"
		$button.Refresh() # Rafraîchir le bouton
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::OrangeRed
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				# Obtenez la politique d'exécution actuelle
				$executionPolicy = Get-ExecutionPolicy
				$url = "https://stephaninformatique.fr/pws/OOAPB.exe" # URL du fichier à télécharger
				$output = "$env:MultInstall\OOAPB.exe" # Emplacement 
				
				
				# Vérifier si le fichier existe déjà
				if (-Not (Test-Path -Path $output))
				{
					$textBox.AppendText("Téléchargement de O&O AppBuster en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
					Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30

					if (Test-Path -Path $output)
					{
						$textBox.AppendText("Fichier téléchargé avec succès." + [Environment]::NewLine)
					}
					else
					{
						$textBox.AppendText("Échec du téléchargement du fichier." + [Environment]::NewLine)
						return
					}
				}
				else
				{
					$textBox.AppendText("Fichier déjà présent, lancement en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
				}

				# Lancer O&O AppBuster directement depuis le fichier téléchargé
				$textBox.AppendText("Lancement de O&O AppBuster..." + [Environment]::NewLine)
				Start-Process -FilePath $output
				
				
				
				
				
			})
	}
	elseif ($i -eq 13)
	{
		$button.Text = "AUDIT WIN11"
		$button.BackColor = [System.Drawing.Color]::FromArgb(8, 145, 178)
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({ try { AuditWin11 } catch { [System.Windows.Forms.MessageBox]::Show("Erreur : " + $_.Exception.Message) } })
	}
	elseif ($i -eq 24)
	{
		# Si c'est le deuxième bouton
		
		$button.Text = "Fab's Autobackup"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::OrangeRed
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				$url = "https://stephaninformatique.fr/pws/fb.exe" # URL du fichier à télécharger
				$output = "$env:MultInstall\fb.exe" # Emplacement où le fichier sera sauvegardé

				# Vérifier si le fichier existe déjà
				if (-Not (Test-Path -Path $output))
				{
					$textBox.AppendText("Téléchargement de Fab's AutoBackup en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
					Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30

					if (Test-Path -Path $output)
					{
						$textBox.AppendText("Fichier téléchargé avec succès." + [Environment]::NewLine)
					}
					else
					{
						$textBox.AppendText("Échec du téléchargement du fichier." + [Environment]::NewLine)
						return
					}
				}
				else
				{
					$textBox.AppendText("Fichier déjà présent, extraction en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
				}

				# Extraction de l'archive SFX vers %TEMP%
				$textBox.AppendText("Extraction de Fab's AutoBackup..." + [Environment]::NewLine)
				[System.Windows.Forms.Application]::DoEvents()
				Start-Process -FilePath $output -ArgumentList "-o`"$env:TEMP`" -y" -Wait -WindowStyle Hidden

				# Recherche de l'exécutable après extraction
				$exe = Get-ChildItem -Path $env:TEMP -Filter "AutoBackup7Pro.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
				if ($exe)
				{
					$textBox.AppendText("Lancement de Fab's AutoBackup..." + [Environment]::NewLine)
					Start-Process -FilePath $exe.FullName
				}
				else
				{
					$textBox.AppendText("Le fichier n'a pas été trouvé après extraction." + [Environment]::NewLine)
				}
				
				
				
				
				
			})
	}
	elseif ($i -eq 27)
	{
		# Si c'est le deuxième bouton
		$button.Text = "BloatyNosyW11"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::OrangeRed
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				# Obtenez la politique d'exécution actuelle
				$executionPolicy = Get-ExecutionPolicy
				$url = "https://github.com/builtbybel/Bloatynosy/releases/download/1.0.20.522/Bloatynosy.zip" # URL du fichier à télécharger
				$output = "$env:TEMP\BloatyNosy.zip" # Emplacement où le fichier sera sauvegardé
				$extractedFolder = "$env:TEMP\BloatyNosy" # Dossier où le fichier sera décompressé
				
				# Vérifier si le fichier existe déjà
				if (-Not (Test-Path -Path $output))
				{
					# Télécharger le fichier seulement s'il n'existe pas déjà
					Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30
					
					# Vérifier si le fichier a été correctement téléchargé
					if (Test-Path -Path $output)
					{
						$textBox.AppendText("Le fichier a été téléchargé avec succès." + [Environment]::NewLine)
					}
					else
					{
						$textBox.AppendText("Échec du téléchargement du fichier." + [Environment]::NewLine)
						return
					}
				}
				
				# Décompression du fichier ZIP
				if (Test-Path -Path $output)
				{
					if (-Not (Test-Path $extractedFolder))
					{
						New-Item -ItemType Directory -Path $extractedFolder
					}
					
					Expand-Archive -Path $output -DestinationPath $extractedFolder -Force
					$textBox.AppendText("Le fichier a été décompressé avec succès dans $extractedFolder" + [Environment]::NewLine)
				}
				else
				{
					$textBox.AppendText("Le fichier n'a pas été trouvé à l'emplacement spécifié." + [Environment]::NewLine)
					return
				}
				
				# Exécuter le fichier depuis le dossier décompressé
				$executablePath = Join-Path $extractedFolder "BloatyNosy.exe"
				if (Test-Path -Path $executablePath)
				{
					Start-Process -FilePath $executablePath
				}
				else
				{
					$textBox.AppendText("Le fichier exécutable n'a pas été trouvé à l'emplacement spécifié." + [Environment]::NewLine)
				}
				
			})
	}
	elseif ($i -eq 25)
	{
		# Si c'est le deuxième boutonf'
		
		$button.Text = "Install Nirsoft Menu..."
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::OrangeRed
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				
				
				
				# Obtenez la politique d'exécution actuelle
				$executionPolicy = Get-ExecutionPolicy
				$url = "https://www.ugmfree.it/Download/SyMenu/SyMenuPackage.exe" # URL du fichier à télécharger
				$output = "$env:TEMP\SyMenuPackage.exe" # Emplacement où le fichier sera sauvegardé
				
				# Vérifier si le fichier existe déjà
				if (-Not (Test-Path -Path $output))
				{
					# Télécharger le fichier seulement s'il n'existe pas déjà
					Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30
					
					# Vérifier si le fichier a été correctement téléchargé
					if (Test-Path -Path $output)
					{
						$textBox.AppendText("Le fichier a été téléchargé avec succès." + [Environment]::NewLine)
					}
					else
					{
						$textBox.AppendText("Échec du téléchargement du fichier." + [Environment]::NewLine)
						return
					}
				}
				
				# Installer le fichier
				Start-Process -FilePath $output -Wait
				
				# Supprimer le fichier téléchargé après l'installation
				#Remove-Item -Path $output
				
				# Chemin du fichier à exécuter
				$path = "$env:TEMP\SyMenu.Admin.exe"
				
				# Exécuter le fichier
				if (Test-Path -Path $path)
				{
					Start-Process -FilePath $path
				}
				else
				{
					$textBox.AppendText("Le fichier n'a pas été trouvé à l'emplacement spécifié." + [Environment]::NewLine)
				}
				
				
				
				
				
				
				
				
			})
	}
	
	elseif ($i -eq 17)
	{
		$button.Text = "Journal Intervention"
		$button.BackColor = [System.Drawing.Color]::FromArgb(2, 108, 79)
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({ try { Show-JournalWindow } catch { [System.Windows.Forms.MessageBox]::Show("Erreur : " + $_.Exception.Message) } })
	}
	elseif ($i -eq 16)
	{
		$button.Text = "Aide-memoire"
		$button.BackColor = [System.Drawing.Color]::FromArgb(202, 138, 4)
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({ try { AideMemoireTool } catch { [System.Windows.Forms.MessageBox]::Show("Erreur : " + $_.Exception.Message) } })
	}
	
	elseif ($i -eq 14)
	{
		$button.Text = "PGDEFAUT"
		$button.BackColor = [System.Drawing.Color]::LawnGreen
		$button.ForeColor = [System.Drawing.Color]::gray
		$button.Add_Click({ try { ProgDefautTool } catch { [System.Windows.Forms.MessageBox]::Show("Erreur : " + $_.Exception.Message) } })
	}
	
	elseif ($i -eq 15) # Remplacez X par le numéro de bouton souhaité
	{
		$button.Text = "Ouvrir Store App"
		$button.BackColor = [System.Drawing.Color]::DodgerBlue
		$button.ForeColor = [System.Drawing.Color]::White
		
		$button.Add_Click({
				try
				{
					# Ouvrir directement le Store avec le protocole ms-windows-store
					Start-Process "ms-windows-store://pdp?productid=9nblggh4nns1"
					$textBox.AppendText("Ouverture du Microsoft Store..." + [Environment]::NewLine)
				}
				catch
				{
					$textBox.AppendText("Erreur lors de l'ouverture du Microsoft Store : $_" + [Environment]::NewLine)
				}
			})
	}
	
	elseif ($i -eq 20)
	{
		$button.Text = "Désinstall OneDrive"
		$button.BackColor = [System.Drawing.Color]::Gold
		$button.ForeColor = [System.Drawing.Color]::Gray
		
		$button.Add_Click({
				Add-Type -AssemblyName System.Windows.Forms
				Add-Type -AssemblyName System.Drawing
				
				# Création de la fenêtre principale
				$form = New-Object System.Windows.Forms.Form
				$form.Text = "Désinstallation OneDrive"
				$form.Size = New-Object System.Drawing.Size(600, 500)
				$form.StartPosition = "CenterScreen"
				$form.FormBorderStyle = "FixedDialog"
				$form.MaximizeBox = $false
				
				# Zone de texte pour les logs
				$logBox = New-Object System.Windows.Forms.RichTextBox
				$logBox.Location = New-Object System.Drawing.Point(10, 10)
				$logBox.Size = New-Object System.Drawing.Size(565, 400)
				$logBox.ReadOnly = $true
				$logBox.BackColor = [System.Drawing.Color]::White
				$form.Controls.Add($logBox)
				
				# Bouton de désinstallation
				$uninstallButton = New-Object System.Windows.Forms.Button
				$uninstallButton.Location = New-Object System.Drawing.Point(10, 420)
				$uninstallButton.Size = New-Object System.Drawing.Size(565, 30)
				$uninstallButton.Text = "Désinstaller OneDrive"
				$form.Controls.Add($uninstallButton)
				
				# Fonction pour les logs colorés
				function Write-ColoredLog
				{
					param (
						[string]$text,
						[string]$color = "Black"
					)
					$logBox.SelectionStart = $logBox.TextLength
					$logBox.SelectionLength = 0
					$logBox.SelectionColor = $color
					$logBox.AppendText($text + "`r`n")
					$logBox.ScrollToCaret()
					$form.Refresh()
				}
				
				# Action du bouton de désinstallation
				$uninstallButton.Add_Click({
						$uninstallButton.Enabled = $false

						try
						{
							# ── ÉTAPE 1 : Vérification et migration des dossiers utilisateur ──
							Write-ColoredLog "Analyse des dossiers utilisateur..." "Blue"
							$userFolders = @(
								[Environment]::GetFolderPath('Desktop'),
								[Environment]::GetFolderPath('MyDocuments'),
								[Environment]::GetFolderPath('MyPictures'),
								[Environment]::GetFolderPath('MyMusic'),
								[Environment]::GetFolderPath('MyVideos')
							)
							$oneDrivePath = "$env:UserProfile\OneDrive"
							$needsBackup = $false
							foreach ($folder in $userFolders)
							{
								if ($folder.StartsWith($oneDrivePath))
								{
									$needsBackup = $true
									Write-ColoredLog "Dossier lié à OneDrive : $folder" "Orange"
								}
							}
							if ($needsBackup)
							{
								Write-ColoredLog "ATTENTION : dossiers utilisateur sur OneDrive détectés — copie en cours..." "Red"
								foreach ($folder in $userFolders)
								{
									if ($folder.StartsWith($oneDrivePath))
									{
										$folderName = Split-Path $folder -Leaf
										$defaultPath = "$env:UserProfile\$folderName"
										Write-ColoredLog "Déplacement : $folderName → $defaultPath" "Blue"
										if (-not (Test-Path $defaultPath))
										{ New-Item -ItemType Directory -Path $defaultPath -Force | Out-Null }
										Get-ChildItem -Path $folder -Recurse | ForEach-Object {
											$destination = $_.FullName.Replace($oneDrivePath, $env:UserProfile)
											$destFolder = Split-Path $destination -Parent
											if (-not (Test-Path $destFolder))
											{ New-Item -ItemType Directory -Path $destFolder -Force | Out-Null }
											Copy-Item $_.FullName -Destination $destination -Force -ErrorAction SilentlyContinue
											Write-ColoredLog "  Copié : $($_.Name)" "Gray"
										}
									}
								}
								Write-ColoredLog "Migration des fichiers terminée." "Green"
							}
							else
							{
								Write-ColoredLog "Aucun dossier utilisateur lié à OneDrive. Pas de migration nécessaire." "Green"
							}

							# ── ÉTAPE 2 : Arrêt des processus ──
							Write-ColoredLog "Arrêt des processus OneDrive..." "Blue"
							foreach ($proc in @("OneDrive", "OneDriveSetup", "FileCoAuth"))
							{
								Get-Process -Name $proc -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
								Write-ColoredLog "  Processus arrêté : $proc" "Green"
							}
							Stop-Process -Name "explorer" -Force -ErrorAction SilentlyContinue

							# ── ÉTAPE 3 : Désinstallation via Setup natif ──
							Write-ColoredLog "Désinstallation de OneDrive..." "Blue"
							$setupFound = $false
							foreach ($setup in @("$env:SystemRoot\SysWOW64\OneDriveSetup.exe", "$env:SystemRoot\System32\OneDriveSetup.exe"))
							{
								if (Test-Path $setup)
								{
									Start-Process -FilePath $setup -ArgumentList "/uninstall" -NoNewWindow -Wait
									Write-ColoredLog "Désinstallation via setup natif terminée." "Green"
									$setupFound = $true
									break
								}
							}
							if (-not $setupFound)
							{
								Write-ColoredLog "Setup natif introuvable. Tentative via winget..." "Orange"
								if (Get-Command winget -ErrorAction SilentlyContinue)
								{
									winget uninstall --id "Microsoft.OneDrive" --silent --accept-source-agreements 2>$null
									Write-ColoredLog "Désinstallation winget terminée." "Green"
								}
							}

							# ── ÉTAPE 4 : Fichiers résiduels ──
							Write-ColoredLog "Suppression des fichiers résiduels..." "Blue"
							foreach ($path in @(
								"$env:LocalAppData\Microsoft\OneDrive",
								"$env:ProgramData\Microsoft OneDrive",
								"$env:SystemDrive\OneDriveTemp"
							))
							{
								Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue
							}
							if ((Get-ChildItem "$env:UserProfile\OneDrive" -Recurse -ErrorAction SilentlyContinue | Measure-Object).Count -eq 0)
							{
								Remove-Item -Path "$env:UserProfile\OneDrive" -Recurse -Force -ErrorAction SilentlyContinue
								Write-ColoredLog "Dossier OneDrive utilisateur supprimé (était vide)." "Green"
							}
							else
							{
								Write-ColoredLog "Le dossier OneDrive contient des fichiers — conservé." "Orange"
							}

							# ── ÉTAPE 5 : Stratégies de groupe (blocage réinstallation) ──
							Write-ColoredLog "Application des stratégies de groupe..." "Blue"
							foreach ($gpPath in @("HKLM:\SOFTWARE\Policies\Microsoft\Windows\OneDrive", "HKLM:\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\OneDrive"))
							{
								New-Item -Path $gpPath -Force -ErrorAction SilentlyContinue | Out-Null
								Set-ItemProperty -Path $gpPath -Name "DisableFileSyncNGSC" -Value 1 -Type DWord -ErrorAction SilentlyContinue
							}
							Write-ColoredLog "OneDrive bloqué via stratégies de groupe." "Green"

							# ── ÉTAPE 6 : Retrait de la barre latérale Explorateur ──
							Write-ColoredLog "Suppression du panneau OneDrive dans l'Explorateur..." "Blue"
							$clsid = "{018D5C66-4533-4307-9B53-224DE2ED1FE6}"
							foreach ($rp in @("HKCU:\SOFTWARE\Classes\CLSID\$clsid", "HKCU:\SOFTWARE\Classes\Wow6432Node\CLSID\$clsid"))
							{
								New-Item -Path $rp -Force -ErrorAction SilentlyContinue | Out-Null
								Set-ItemProperty -Path $rp -Name "System.IsPinnedToNameSpaceTree" -Value 0 -Type DWord -ErrorAction SilentlyContinue
							}

							# ── ÉTAPE 7 : Entrées de démarrage automatique ──
							Write-ColoredLog "Suppression des entrées de démarrage..." "Blue"
							Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -Name "OneDrive" -ErrorAction SilentlyContinue
							try
							{
								reg load "hku\Default" "C:\Users\Default\NTUSER.DAT" 2>$null
								reg delete "HKEY_USERS\Default\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "OneDriveSetup" /f 2>$null
								reg unload "hku\Default" 2>$null
							}
							catch { }

							# ── ÉTAPE 8 : Tâches planifiées ──
							Write-ColoredLog "Suppression des tâches planifiées OneDrive..." "Blue"
							Get-ScheduledTask -TaskPath '\' -TaskName 'OneDrive*' -ErrorAction SilentlyContinue | Unregister-ScheduledTask -Confirm:$false

							# ── ÉTAPE 9 : Raccourci menu Démarrer ──
							Remove-Item -Path "$env:AppData\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk" -Force -ErrorAction SilentlyContinue

							# ── ÉTAPE 10 : Redémarrage de l'Explorateur ──
							Write-ColoredLog "Redémarrage de l'Explorateur..." "Blue"
							Start-Process "explorer.exe"
							Start-Sleep -Seconds 3

							Write-ColoredLog "`r`nOneDrive désinstallé avec succès !" "Green"
							Write-ColoredLog "Vérifiez que tous vos fichiers sont présents dans vos dossiers personnels." "Orange"
						}
						catch
						{
							Write-ColoredLog "ERREUR : $_" "Red"
						}
						finally
						{
							$uninstallButton.Text = "Terminé"
						}
					})
				
				# Afficher la fenêtre
				$form.ShowDialog()
			})
	}
	
	elseif ($i -eq 23)
	{
		# Si c'est le deuxième bouton
		
		$button.Text = "Code"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Gold
		$button.ForeColor = [System.Drawing.Color]::Gray
		$button.Add_Click({
				
				#ouvrir url licence
				Start-Process -FilePath "msedge.exe" -ArgumentList "-inprivate", "https://www.evernote.com/shard/s455/client/snv?isnewsnv=true&noteGuid=be09a6c8-de27-b975-94e9-fcdf50fa8c86&noteKey=90HtaScl2xSvajkngkKp80V2ETrEuN85ttJyr2yWYEKuFNLhjcX5rvPG9Q&sn=https%3A%2F%2Fwww.evernote.com%2Fshard%2Fs455%2Fsh%2Fbe09a6c8-de27-b975-94e9-fcdf50fa8c86%2F90HtaScl2xSvajkngkKp80V2ETrEuN85ttJyr2yWYEKuFNLhjcX5rvPG9Q&title=Code"
				
				
			})
	}
	
	elseif ($i -eq 19)
	{
		# Si c'est le deuxième bouton
		
		$button.Text = "Bleach Bit"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Gold
		$button.ForeColor = [System.Drawing.Color]::gray
		$button.Add_Click({
				$url = "https://stephaninformatique.fr/pws/bb.exe" # URL du fichier à télécharger
				$output = "$env:MultInstall\bb.exe" # Emplacement où le fichier sera sauvegardé

				# Vérifier si le fichier existe déjà
				if (-Not (Test-Path -Path $output))
				{
					$textBox.AppendText("Téléchargement de BleachBit en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
					Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30

					if (Test-Path -Path $output)
					{
						$textBox.AppendText("Fichier téléchargé avec succès." + [Environment]::NewLine)
					}
					else
					{
						$textBox.AppendText("Échec du téléchargement du fichier." + [Environment]::NewLine)
						return
					}
				}
				else
				{
					$textBox.AppendText("Fichier déjà présent, extraction en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
				}

				# Extraction de l'archive SFX vers %TEMP%
				$textBox.AppendText("Extraction de BleachBit..." + [Environment]::NewLine)
				[System.Windows.Forms.Application]::DoEvents()
				Start-Process -FilePath $output -ArgumentList "-o`"$env:TEMP`" -y" -Wait -WindowStyle Hidden

				# Recherche de l'exécutable après extraction (portable ou installé)
				$exe = Get-ChildItem -Path $env:TEMP -Filter "bleachbit.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
				if (-not $exe)
				{
					$exe = Get-ChildItem -Path "C:\Program Files", "C:\Program Files (x86)" -Filter "bleachbit.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
				}
				if ($exe)
				{
					$textBox.AppendText("Lancement de BleachBit..." + [Environment]::NewLine)
					Start-Process -FilePath $exe.FullName
				}
				else
				{
					$textBox.AppendText("Le fichier n'a pas été trouvé après extraction." + [Environment]::NewLine)
				}
				
				
				
				
				
			})
	}
	
	elseif ($i -eq 22)
	{
		# Si c'est le deuxième bouton
		
		$button.Text = "WizTree"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Gold
		$button.ForeColor = [System.Drawing.Color]::gray
		$button.Add_Click({
				$url = "https://stephaninformatique.fr/pws/wt.exe" # URL du fichier à télécharger
				$output = "$env:MultInstall\wt.exe" # Emplacement où le fichier sera sauvegardé

				# Vérifier si le fichier existe déjà
				if (-Not (Test-Path -Path $output))
				{
					$textBox.AppendText("Téléchargement de WizTree en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
					Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30

					if (Test-Path -Path $output)
					{
						$textBox.AppendText("Fichier téléchargé avec succès." + [Environment]::NewLine)
					}
					else
					{
						$textBox.AppendText("Échec du téléchargement du fichier." + [Environment]::NewLine)
						return
					}
				}
				else
				{
					$textBox.AppendText("Fichier déjà présent, extraction en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
				}

				# Extraction de l'archive SFX vers %TEMP%
				$textBox.AppendText("Extraction de WizTree..." + [Environment]::NewLine)
				[System.Windows.Forms.Application]::DoEvents()
				Start-Process -FilePath $output -ArgumentList "-o`"$env:TEMP`" -y" -Wait -WindowStyle Hidden

				# Recherche de l'exécutable après extraction
				$exe = Get-ChildItem -Path $env:TEMP -Filter "WizTreePortable.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
				if (-not $exe)
				{
					$exe = Get-ChildItem -Path $env:TEMP -Filter "WizTree*.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
				}
				if ($exe)
				{
					$textBox.AppendText("Lancement de WizTree..." + [Environment]::NewLine)
					Start-Process -FilePath $exe.FullName
				}
				else
				{
					$textBox.AppendText("Le fichier n'a pas été trouvé après extraction." + [Environment]::NewLine)
				}
				
				
				
				
				
			})
	}
	elseif ($i -eq 21)
	{
		# Si c'est le deuxième bouton
		
		$button.Text = "WiseRegClean"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Gold
		$button.ForeColor = [System.Drawing.Color]::gray
		$button.Add_Click({
				$url = "https://stephaninformatique.fr/pws/wrc.exe" # URL du fichier à télécharger
				$output = "$env:MultInstall\wrc.exe" # Emplacement où le fichier sera sauvegardé

				# Vérifier si le fichier existe déjà
				if (-Not (Test-Path -Path $output))
				{
					$textBox.AppendText("Téléchargement de Wise Registry Cleaner en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
					Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30

					if (Test-Path -Path $output)
					{
						$textBox.AppendText("Fichier téléchargé avec succès." + [Environment]::NewLine)
					}
					else
					{
						$textBox.AppendText("Échec du téléchargement du fichier." + [Environment]::NewLine)
						return
					}
				}
				else
				{
					$textBox.AppendText("Fichier déjà présent, extraction en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
				}

				# Extraction de l'archive SFX vers %TEMP%
				$textBox.AppendText("Extraction de Wise Registry Cleaner..." + [Environment]::NewLine)
				[System.Windows.Forms.Application]::DoEvents()
				Start-Process -FilePath $output -ArgumentList "-o`"$env:TEMP`" -y" -Wait -WindowStyle Hidden

				# Recherche de l'exécutable après extraction
				$exe = Get-ChildItem -Path $env:TEMP -Filter "WiseRegistryCleanerPortable.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
				if (-not $exe)
				{
					$exe = Get-ChildItem -Path $env:TEMP -Filter "WiseRegistryCleaner*.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
				}
				if ($exe)
				{
					$textBox.AppendText("Lancement de Wise Registry Cleaner..." + [Environment]::NewLine)
					Start-Process -FilePath $exe.FullName
				}
				else
				{
					$textBox.AppendText("Le fichier n'a pas été trouvé après extraction." + [Environment]::NewLine)
				}
				
				
				
				
				
			})
	}
	elseif ($i -eq 18)
	{
		# Si c'est le deuxième bouton
		
		$button.Text = "Dism++"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Gold
		$button.ForeColor = [System.Drawing.Color]::gray
		$button.Add_Click({
				$url = "https://stephaninformatique.fr/pws/Dism++.exe" # URL du fichier à télécharger
				$output = "$env:MultInstall\Dism++.exe" # Emplacement où le fichier sera sauvegardé

				# Vérifier si le fichier existe déjà
				if (-Not (Test-Path -Path $output))
				{
					$textBox.AppendText("Téléchargement de Dism++ en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
					Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30

					if (Test-Path -Path $output)
					{
						$textBox.AppendText("Fichier téléchargé avec succès." + [Environment]::NewLine)
					}
					else
					{
						$textBox.AppendText("Échec du téléchargement du fichier." + [Environment]::NewLine)
						return
					}
				}
				else
				{
					$textBox.AppendText("Fichier déjà présent, extraction en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
				}

				# Extraction de l'archive SFX vers %TEMP%
				$textBox.AppendText("Extraction de Dism++..." + [Environment]::NewLine)
				[System.Windows.Forms.Application]::DoEvents()
				Start-Process -FilePath $output -ArgumentList "-o`"$env:TEMP`" -y" -Wait -WindowStyle Hidden

				# Recherche de l'exécutable après extraction
				$exe = Get-ChildItem -Path $env:TEMP -Filter "Dism++x64.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
				if (-not $exe)
				{
					$exe = Get-ChildItem -Path $env:TEMP -Filter "Dism++*.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
				}
				if ($exe)
				{
					$textBox.AppendText("Lancement de Dism++..." + [Environment]::NewLine)
					Start-Process -FilePath $exe.FullName
				}
				else
				{
					$textBox.AppendText("Le fichier n'a pas été trouvé après extraction." + [Environment]::NewLine)
				}
				
				
				
				
				
			})
	}
	elseif ($i -eq 31)
	{
		# Si c'est le deuxième bouton
		
		$button.Text = "W11 Deb ++"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Purple
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				$url = "https://stephaninformatique.fr/pws/wd.exe" # URL du fichier à télécharger
				$output = "$env:MultInstall\wd.exe" # Emplacement où le fichier sera sauvegardé

				# Vérifier si le fichier existe déjà
				if (-Not (Test-Path -Path $output))
				{
					$textBox.AppendText("Téléchargement de W11 Deb++ en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
					Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30

					if (Test-Path -Path $output)
					{
						$textBox.AppendText("Fichier téléchargé avec succès." + [Environment]::NewLine)
					}
					else
					{
						$textBox.AppendText("Échec du téléchargement du fichier." + [Environment]::NewLine)
						return
					}
				}
				else
				{
					$textBox.AppendText("Fichier déjà présent, extraction en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
				}

				# Extraction de l'archive SFX vers %TEMP%
				$textBox.AppendText("Extraction de W11 Deb++..." + [Environment]::NewLine)
				[System.Windows.Forms.Application]::DoEvents()
				Start-Process -FilePath $output -ArgumentList "-o`"$env:TEMP`" -y" -Wait -WindowStyle Hidden

				# Recherche du lanceur après extraction
				$launcher = Get-ChildItem -Path $env:TEMP -Filter "Launch.bat" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
				if ($launcher)
				{
					$textBox.AppendText("Lancement de W11 Deb++..." + [Environment]::NewLine)
					Start-Process cmd.exe -ArgumentList "/c `"$($launcher.FullName)`""
				}
				else
				{
					$textBox.AppendText("Le fichier de lancement n'a pas été trouvé après extraction." + [Environment]::NewLine)
				}
				
				
				
				
				
			})
	}
	elseif ($i -eq 34)
	{
		# Si c'est le deuxième bouton
		
		$button.Text = "Multinstall2"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Purple
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				$url = "https://stephaninformatique.fr/pws/multinstall2.exe" # URL du fichier à télécharger
				$output = "c:\mi2.exe" # Emplacement où le fichier sera sauvegardé

				# Vérifier si le fichier existe déjà
				if (-Not (Test-Path -Path $output))
				{
					$textBox.AppendText("Téléchargement de Multinstall2 en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
					Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30

					if (Test-Path -Path $output)
					{
						$textBox.AppendText("Fichier téléchargé avec succès." + [Environment]::NewLine)
					}
					else
					{
						$textBox.AppendText("Échec du téléchargement du fichier." + [Environment]::NewLine)
						return
					}
				}
				else
				{
					$textBox.AppendText("Fichier déjà présent, extraction en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
				}

				# Extraction de l'archive SFX vers %TEMP%
				$textBox.AppendText("Extraction de Multinstall2..." + [Environment]::NewLine)
				[System.Windows.Forms.Application]::DoEvents()
				Start-Process -FilePath $output -ArgumentList "-o`"c:\TEMP`" -y" -Wait -WindowStyle Hidden

				# Recherche du lanceur après extraction
				$launcher = Get-ChildItem -Path $env:TEMP -Filter "Launch.bat" -Recurse -ErrorAction SilentlyContinue |
					Where-Object { $_.DirectoryName -like "*Manual-activations*" -or $_.DirectoryName -like "*mi2*" } |
					Select-Object -First 1
				if (-not $launcher)
				{
					$launcher = Get-ChildItem -Path $env:TEMP -Filter "Launch.bat" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
				}
				if ($launcher)
				{
					$textBox.AppendText("Lancement de Multinstall2..." + [Environment]::NewLine)
					Start-Process cmd.exe -ArgumentList "/c `"$($launcher.FullName)`""
				}
				else
				{
					$textBox.AppendText("Le fichier de lancement n'a pas été trouvé après extraction." + [Environment]::NewLine)
				}
				
				
				
				
				
			})
	}
	
	elseif ($i -eq 30)
	{
		# Si c'est le deuxième bouton
		
		$button.Text = "Win10debloat"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::Purple
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({
				$url = "https://stephaninformatique.fr/pws/win10deb.exe" # URL du fichier à télécharger
				$output = "$env:MultInstall\win10deb.exe" # Emplacement où le fichier sera sauvegardé

				# Vérifier si le fichier existe déjà
				if (-Not (Test-Path -Path $output))
				{
					$textBox.AppendText("Téléchargement de Win10Debloat en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
					Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30

					if (Test-Path -Path $output)
					{
						$textBox.AppendText("Fichier téléchargé avec succès." + [Environment]::NewLine)
					}
					else
					{
						$textBox.AppendText("Échec du téléchargement du fichier." + [Environment]::NewLine)
						return
					}
				}
				else
				{
					$textBox.AppendText("Fichier déjà présent, extraction en cours..." + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()
				}

				# Extraction de l'archive SFX vers %TEMP%
				$textBox.AppendText("Extraction de Win10Debloat..." + [Environment]::NewLine)
				[System.Windows.Forms.Application]::DoEvents()
				Start-Process -FilePath $output -ArgumentList "-o`"$env:TEMP`" -y" -Wait -WindowStyle Hidden

				# Déverrouiller les scripts PS1 extraits et chercher le script principal
				Get-ChildItem -Path $env:TEMP -Filter "*.ps1" -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
				$ps1 = Get-ChildItem -Path $env:TEMP -Filter "WinDebloatTools.ps1" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
				if (-not $ps1)
				{
					$ps1 = Get-ChildItem -Path $env:TEMP -Filter "*debloat*.ps1" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
				}
				if ($ps1)
				{
					$textBox.AppendText("Lancement de Win10Debloat..." + [Environment]::NewLine)
					Start-Process powershell.exe -ArgumentList "-ExecutionPolicy Bypass -File `"$($ps1.FullName)`""
				}
				else
				{
					$textBox.AppendText("Le script de débloatage n'a pas été trouvé après extraction." + [Environment]::NewLine)
				}
				
				
				
				
				
			})
	}
	elseif ($i -eq 36)
	{
		$button.Text = "Nettoyage Temp"
		$button.BackColor = [System.Drawing.Color]::Orchid
		$button.ForeColor = [System.Drawing.Color]::White
		$button.Add_Click({

				$textBox.AppendText("=== Nettoyage des dossiers temporaires ===" + [Environment]::NewLine)
				[System.Windows.Forms.Application]::DoEvents()

				# Dossiers à nettoyer (doublons filtrés automatiquement)
				$tempFolders = @(
					$env:TEMP,
					$env:TMP,
					"$env:LOCALAPPDATA\Temp",
					"$env:SystemRoot\Temp"
				) | Where-Object { $_ } | Sort-Object -Unique

				$totalDeleted = 0
				$totalSkipped = 0

				foreach ($folder in $tempFolders)
				{
					if (-not (Test-Path -Path $folder)) { continue }

					$textBox.AppendText("Nettoyage : $folder" + [Environment]::NewLine)
					[System.Windows.Forms.Application]::DoEvents()

					# 1. Supprimer les fichiers un par un (skip silencieux si verrouillé)
					$files = Get-ChildItem -Path $folder -File -Recurse -ErrorAction SilentlyContinue
					foreach ($file in $files)
					{
						try
						{
							Remove-Item -Path $file.FullName -ErrorAction Stop
							$totalDeleted++
						}
						catch
						{
							$totalSkipped++  # Fichier verrouillé par une application → on passe au suivant
						}
					}

					# 2. Supprimer les dossiers vides (du plus profond au plus haut)
					$dirs = Get-ChildItem -Path $folder -Directory -Recurse -ErrorAction SilentlyContinue |
						Sort-Object FullName -Descending
					foreach ($dir in $dirs)
					{
						$isEmpty = -not (Get-ChildItem -Path $dir.FullName -ErrorAction SilentlyContinue)
						if ($isEmpty)
						{
							Remove-Item -Path $dir.FullName -ErrorAction SilentlyContinue
						}
					}
				}

				$textBox.AppendText("✅ Nettoyage terminé : $totalDeleted fichier(s) supprimé(s), $totalSkipped ignoré(s) (en cours d'utilisation)." + [Environment]::NewLine)
				[System.Windows.Forms.Application]::DoEvents()
			})
	}
	
	elseif ($i -eq 35)
	{
		# Si c'est le deuxième bouton
		
		$button.Text = "Winget Script"
		# Personnalisez le fond et la couleur du texte
		$button.BackColor = [System.Drawing.Color]::LightGreen
		$button.ForeColor = [System.Drawing.Color]::Gray
		$button.Add_Click({
				# Script optimisé d'intégration Winget Manager (intégré directement)
				
				# Chemin temporaire (vérification sécurisée)
				$tempPath = "$env:TEMP"
				if (-not (Test-Path -Path $tempPath -PathType Container))
				{
					try
					{
						New-Item -Path $tempPath -ItemType Directory -Force | Out-Null
						Write-Output "Dossier créé : $tempPath"
					}
					catch
					{
						$tempPath = $env:TEMP
						Write-Warning "Échec création dossier $env:TEMP. Utilisation alternative : $tempPath"
					}
				}
				
				# Chemin du script Winget Manager
				$wingetManagerPath = Join-Path $tempPath "winget-manager.ps1"
				
				# Contenu complet du script Winget Manager
				$wingetManagerContent = @'
Write-Output "Winget Manager lancé directement !"

# Exemple simplifié : vérification de Winget
if (Get-Command winget -ErrorAction SilentlyContinue) {
    Write-Output "Winget est déjà installé."
    winget --version
} else {
    Write-Warning "Winget n'est pas installé. Veuillez l'installer via Microsoft Store ou GitHub."
}
'@
				
				# Création du fichier winget-manager.ps1
				try
				{
					Set-Content -Path $wingetManagerPath -Value $wingetManagerContent -Force
					Write-Output "Créé : $wingetManagerPath"
				}
				catch
				{
					Write-Error "Erreur création winget-manager.ps1 : $_"
					exit 1
				}
				
				# Création du fichier batch pour lancer Winget Manager dans une nouvelle console
				$consoleScriptPath = Join-Path $tempPath "launch-winget-console.bat"
				$consoleScriptContent = @"
@echo off
echo Ouverture de Winget Manager...
powershell -NoExit -ExecutionPolicy Bypass -File "$wingetManagerPath" %*
"@
				
				try
				{
					Set-Content -Path $consoleScriptPath -Value $consoleScriptContent -Force
					Write-Output "Créé : $consoleScriptPath"
				}
				catch
				{
					Write-Error "Erreur création script batch : $_"
					exit 1
				}
				
				# Choix d'exécution (1 = actuelle, 2 = nouvelle console)
				$choice = 2
				
				switch ($choice)
				{
					1 {
						Write-Output "Exécution directe dans la console actuelle..."
						& $wingetManagerPath
					}
					2 {
						Write-Output "Exécution dans une nouvelle console..."
						Start-Process "cmd.exe" "/c $consoleScriptPath"
					}
				}
				
		})
		}
		
		
		
		elseif ($i -eq 38)
		{
			# Si c'est le deuxième bouton
			$button.Text = "MenuContextuel Win11"
			# Personnalisez le fond et la couleur du texte
			$button.BackColor = [System.Drawing.Color]::LightGreen
			$button.ForeColor = [System.Drawing.Color]::Gray
			$button.Add_Click({
				if ($PSVersionTable.PSEdition -eq 'Core') {
					[System.Windows.Forms.MessageBox]::Show(
						"Ce module nécessite Windows PowerShell 5.`nRelancez MultInstall avec powershell.exe.",
						"Incompatible PS7", [System.Windows.Forms.MessageBoxButtons]::OK,
						[System.Windows.Forms.MessageBoxIcon]::Warning)
					return
				}
				Add-Type -AssemblyName System.Windows.Forms
				Add-Type -AssemblyName System.Drawing

				# ── Résoudre le problème admin/HKCU ───────────────────────────────────────
				# MultInstall tourne en admin → reg.exe HKCU modifie le registre ADMIN,
				# pas celui de l'utilisateur connecté. On cible HKU\{SID} de l'utilisateur réel.
				$realUser = (Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue).UserName
				$userSID  = $null
				if ($realUser) {
					try {
						$userSID = (New-Object System.Security.Principal.NTAccount($realUser)).Translate(
							[System.Security.Principal.SecurityIdentifier]).Value
					} catch { $userSID = $null }
				}
				# Chemins registre via le provider complet "Registry::" -> aucun lecteur PSDrive requis
				# (le lecteur HKU: pouvait manquer au moment du clic -> erreur). HKEY_USERS\<SID> = vrai utilisateur.
				$hkuRoot = if ($userSID) { "Registry::HKEY_USERS\$userSID" } else { "Registry::HKEY_CURRENT_USER" }

				$clsidPath   = "$hkuRoot\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32"
				# MultInstall tourne en admin : HKEY_CURRENT_USER = ruche admin, pas l'utilisateur connecte.
				# On cible donc la ruche du vrai utilisateur (HKEY_USERS\<SID>) pour les boutons "PC" aussi.
				$clsidPathPC = "$hkuRoot\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32"
				$extPath     = "$hkuRoot\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"

                # Couleurs en-tete
                $hdrC1 = [System.Drawing.Color]::FromArgb(79, 70, 229)
                $hdrC2 = [System.Drawing.Color]::FromArgb(37, 99, 235)

                $form = New-Object System.Windows.Forms.Form
                $form.Text = 'Configurations diverses'
                $form.ClientSize = New-Object System.Drawing.Size(480, 492)
                $form.StartPosition = 'CenterScreen'
                $form.FormBorderStyle = 'None'
                $form.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
                $form.Tag = @{ ClsidPath = $clsidPath; ClsidPathPC = $clsidPathPC; ExtPath = $extPath }

                # Coins arrondis
                $cmGp = New-Object System.Drawing.Drawing2D.GraphicsPath
                $cmR = 16
                $cmGp.AddArc(0, 0, $cmR, $cmR, 180, 90)
                $cmGp.AddArc(480 - $cmR, 0, $cmR, $cmR, 270, 90)
                $cmGp.AddArc(480 - $cmR, 492 - $cmR, $cmR, $cmR, 0, 90)
                $cmGp.AddArc(0, 492 - $cmR, $cmR, $cmR, 90, 90)
                $cmGp.CloseAllFigures()
                $form.Region = New-Object System.Drawing.Region($cmGp)

                # En-tete degrade
                $cmHeader = New-Object System.Windows.Forms.Panel
                $cmHeader.Size = New-Object System.Drawing.Size(480, 64)
                $cmHeader.Location = New-Object System.Drawing.Point(0, 0)
                $cmHeader.Add_Paint({
                        param($s, $e)
                        $g = $e.Graphics
                        $rc = New-Object System.Drawing.Rectangle(0, 0, $s.Width, $s.Height)
                        $brsh = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rc, $hdrC1, $hdrC2, [System.Single]0)
                        $g.FillRectangle($brsh, $rc); $brsh.Dispose()
                        $tf = New-Object System.Drawing.Font('Segoe UI Semibold', 13)
                        $tb = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
                        $g.DrawString('Configurations diverses', $tf, $tb, [System.Single]18, [System.Single]19)
                        $tf.Dispose(); $tb.Dispose()
                    })
                $form.Controls.Add($cmHeader)

                # Bouton fermer
                $cmClose = New-Object System.Windows.Forms.Button
                $cmClose.Text = 'X'
                $cmClose.Size = New-Object System.Drawing.Size(30, 26)
                $cmClose.Location = New-Object System.Drawing.Point(444, 8)
                $cmClose.FlatStyle = 'Flat'
                $cmClose.FlatAppearance.BorderSize = 0
                $cmClose.BackColor = [System.Drawing.Color]::Transparent
                $cmClose.ForeColor = [System.Drawing.Color]::White
                $cmClose.Add_Click({ $form.Close() })
                $cmHeader.Controls.Add($cmClose)

                # Labels de section
                foreach ($lbl in @(
                    @{ Text = 'PC autonome'; Y = 76 },
                    @{ Text = 'Domaine / multi-utilisateurs'; Y = 156 },
                    @{ Text = 'Explorateur et systeme'; Y = 236 },
                    @{ Text = 'Securite (Windows 11)'; Y = 396 }
                )) {
                    $l = New-Object System.Windows.Forms.Label
                    $l.Text = $lbl.Text
                    $l.Location = New-Object System.Drawing.Point(22, $lbl.Y)
                    $l.AutoSize = $true
                    $l.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
                    $l.BackColor = [System.Drawing.Color]::Transparent
                    $l.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 8)
                    $form.Controls.Add($l)
                }

                # Menu contextuel copier
                $contextMenu = New-Object System.Windows.Forms.ContextMenu
                $menuItemCopy = New-Object System.Windows.Forms.MenuItem
                $menuItemCopy.Text = "Copier le code"
                $contextMenu.MenuItems.Add($menuItemCopy) | Out-Null

                $blue   = [System.Drawing.Color]::FromArgb(37, 99, 235)
                $indigo = [System.Drawing.Color]::FromArgb(79, 70, 229)
                $green  = [System.Drawing.Color]::FromArgb(22, 163, 74)
                $orange = [System.Drawing.Color]::FromArgb(234, 88, 12)
                $red    = [System.Drawing.Color]::FromArgb(220, 38, 38)
                $slate  = [System.Drawing.Color]::FromArgb(71, 85, 105)

                $buttons = @(
                    @{ Text='Win10 (PC)'; X=20; Y=98; Color=$blue; Action={ New-Item -Path $clsidPathPC -Force -ErrorAction SilentlyContinue | Out-Null; Set-ItemProperty -Path $clsidPathPC -Name '(default)' -Value '' -ErrorAction SilentlyContinue; Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 500; Start-Process explorer; [System.Windows.Forms.MessageBox]::Show("Menu Win10 active (PC). Explorer redemarre.","OK") } },
                    @{ Text='Win11 (PC)'; X=250; Y=98; Color=$blue; Action={ Remove-Item -Path $clsidPathPC -Recurse -Force -ErrorAction SilentlyContinue; Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 500; Start-Process explorer; [System.Windows.Forms.MessageBox]::Show("Menu Win11 restaure (PC). Explorer redemarre.","OK") } },
                    @{ Text='Win10 (Domaine)'; X=20; Y=178; Color=$indigo; Action={ New-Item -Path $clsidPath -Force -ErrorAction SilentlyContinue | Out-Null; Set-ItemProperty -Path $clsidPath -Name '(default)' -Value '' -ErrorAction SilentlyContinue; Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 500; Start-Process explorer; [System.Windows.Forms.MessageBox]::Show("Menu Win10 active (domaine). Explorer redemarre.","OK") } },
                    @{ Text='Win11 (Domaine)'; X=250; Y=178; Color=$indigo; Action={ Remove-Item -Path $clsidPath -Recurse -Force -ErrorAction SilentlyContinue; Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 500; Start-Process explorer; [System.Windows.Forms.MessageBox]::Show("Menu Win11 restaure (domaine). Explorer redemarre.","OK") } },
                    @{ Text='Afficher extensions'; X=20; Y=258; Color=$green; Action={ Set-ItemProperty -Path $extPath -Name 'HideFileExt' -Value 0 -ErrorAction SilentlyContinue; Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 500; Start-Process explorer; [System.Windows.Forms.MessageBox]::Show("Extensions affichees. Explorer redemarre.","OK") } },
                    @{ Text='Masquer extensions'; X=250; Y=258; Color=$orange; Action={ Set-ItemProperty -Path $extPath -Name 'HideFileExt' -Value 1 -ErrorAction SilentlyContinue; Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 500; Start-Process explorer; [System.Windows.Forms.MessageBox]::Show("Extensions masquees. Explorer redemarre.","OK") } },
                    @{ Text='Desactiver UAC'; X=20; Y=320; Color=$red; Action={
                        $confirm = [System.Windows.Forms.MessageBox]::Show(
                            "Desactiver l'UAC reduit fortement la securite du systeme (les programmes pourront s'executer en admin sans confirmation). Continuer ?",
                            "Confirmation requise",
                            [System.Windows.Forms.MessageBoxButtons]::YesNo,
                            [System.Windows.Forms.MessageBoxIcon]::Warning)
                        if ($confirm -eq [System.Windows.Forms.DialogResult]::Yes) {
                            Set-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System" -Name 'EnableLUA' -Value 0 -ErrorAction SilentlyContinue
                            [System.Windows.Forms.MessageBox]::Show("UAC desactive. Redemarrage requis.","OK")
                        }
                    } },
                    @{ Text='Fermer'; X=250; Y=320; Color=$slate; Action={ $form.Close() } },
                    @{ Text='Verifier / Desactiver Smart App Control'; X=20; Y=418; W=440; Color=$red; Action={
                        $ciPath = "HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy"
                        $state = (Get-ItemProperty -Path $ciPath -Name 'VerifiedAndReputablePolicyState' -ErrorAction SilentlyContinue).VerifiedAndReputablePolicyState
                        # 0 = Desactive, 1 = Applique (verrouille), 2 = Evaluation (encore modifiable)
                        if ($null -eq $state -or $state -eq 0) {
                            [System.Windows.Forms.MessageBox]::Show("Le Controle intelligent des applications est deja desactive (ou absent sur ce systeme).","Smart App Control")
                        }
                        elseif ($state -eq 1) {
                            [System.Windows.Forms.MessageBox]::Show("Le Controle intelligent des applications est verrouille en mode 'Applique' sur ce PC.`nIl ne peut plus etre desactive sans reinstaller Windows.","Smart App Control",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
                        }
                        else {
                            $confirm = [System.Windows.Forms.MessageBox]::Show(
                                "Le Controle intelligent des applications est en mode 'Evaluation' (encore desactivable).`nLe desactiver maintenant evite les blocages sur les outils tiers utilises par MultInstall. Continuer ?",
                                "Confirmation requise",
                                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                                [System.Windows.Forms.MessageBoxIcon]::Warning)
                            if ($confirm -eq [System.Windows.Forms.DialogResult]::Yes) {
                                Set-ItemProperty -Path $ciPath -Name 'VerifiedAndReputablePolicyState' -Value 0 -ErrorAction SilentlyContinue
                                [System.Windows.Forms.MessageBox]::Show("Controle intelligent des applications desactive. Redemarrage recommande.","OK")
                            }
                        }
                    } }
                )

                $script:LastRightClickedButton = $null
                foreach ($btnCfg in $buttons) {
                    $btn = New-Object RoundButton
                    $btnW = if ($btnCfg.W) { $btnCfg.W } else { 210 }
                    $btn.Size = New-Object System.Drawing.Size($btnW, 44)
                    $btn.Location = New-Object System.Drawing.Point($btnCfg.X, $btnCfg.Y)
                    $btn.Text = $btnCfg.Text
                    $btn.BackColor = $btnCfg.Color
                    $btn.ForeColor = [System.Drawing.Color]::White
                    $btn.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9)
                    $btn.UseMnemonic = $false
                    $btn.Tag = $btnCfg.Action
                    $btn.ContextMenu = $contextMenu
                    $act = $btnCfg.Action.GetNewClosure()
                    $btn.Add_Click({ param($s, $e) try { & $act } catch { [System.Windows.Forms.MessageBox]::Show("Erreur : " + $_.Exception.Message) } }.GetNewClosure())
                    $btn.Add_MouseDown({ param($sender, $e) if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Right) { $script:LastRightClickedButton = $sender } })
                    $form.Controls.Add($btn)
                }

                # Handler copier code (rendu autonome)
                $menuItemCopy.Add_Click({
                        if ($script:LastRightClickedButton -and $script:LastRightClickedButton.Tag) {
                            $code = [string]$script:LastRightClickedButton.Tag
                            $code = $code -replace '\$clsidPathPC', ("'" + $clsidPathPC + "'")
                            $code = $code -replace '\$clsidPath', ("'" + $clsidPath + "'")
                            $code = $code -replace '\$extPath', ("'" + $extPath + "'")
                            $code = "Add-Type -AssemblyName System.Windows.Forms`r`n" + $code.Trim()
                            [System.Windows.Forms.Clipboard]::SetText($code)
                            [System.Windows.Forms.MessageBox]::Show("Code copie (pret a coller dans PowerShell).")
                        }
                    })

                # Deplacement de la fenetre
                $script:cmDrag = $false
                $dd = { $script:cmDrag = $true; $script:cmStart = [System.Windows.Forms.Cursor]::Position; $script:cmLoc = $form.Location }
                $dm = { if ($script:cmDrag) { $cc = [System.Windows.Forms.Cursor]::Position; $form.Location = [System.Drawing.Point]::new($script:cmLoc.X + ($cc.X - $script:cmStart.X), $script:cmLoc.Y + ($cc.Y - $script:cmStart.Y)) } }
                $du = { $script:cmDrag = $false }
                $form.Add_MouseDown($dd); $form.Add_MouseMove($dm); $form.Add_MouseUp($du)
                $cmHeader.Add_MouseDown($dd); $cmHeader.Add_MouseMove($dm); $cmHeader.Add_MouseUp($du)

                $form.Add_Shown({ $form.Activate() })
                [void]$form.ShowDialog()
				
				})
		}
		elseif ($i -eq 40)
		{
			$button.Text = "Wtool"
			$button.BackColor = [System.Drawing.Color]::LightGreen
			$button.ForeColor = [System.Drawing.Color]::Gray
			$button.Add_Click({
					# Chemin où le fichier sera sauvegardé
					$output = "$env:TEMP\Wtool.exe"
					
					# URL du fichier à télécharger
					$url = "https://stephaninformatique.fr/pws/Wtool.exe"
					
					# Toujours re-telecharger pour eviter un cache corrompu
					if (Test-Path -Path $output) { Remove-Item -Path $output -Force }

					try
					{
						Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30
					}
					catch
					{
						$textBox.AppendText("Erreur lors du telechargement : $_" + [Environment]::NewLine)
						return
					}

					if (-Not (Test-Path -Path $output))
					{
						$textBox.AppendText("Echec du telechargement du fichier." + [Environment]::NewLine)
						return
					}

					$textBox.AppendText("Le fichier a ete telecharge avec succes." + [Environment]::NewLine)

					try
					{
						Start-Process -FilePath $output -Wait
					}
					catch
					{
						$textBox.AppendText("Erreur lors du lancement de l'installateur : $_" + [Environment]::NewLine)
						return
					}
					
					# Recherche dynamique sur tout C:\ (profondeur 5)
					$wtoolExe = Get-ChildItem -Path "C:\" -Filter "WTools.exe" -Recurse -Depth 5 -ErrorAction SilentlyContinue |
						Select-Object -First 1
					if ($wtoolExe) {
						Start-Process -FilePath $wtoolExe.FullName
					} else {
						$textBox.AppendText("WTools.exe introuvable sur C:\. Verifiez l'installation." + [Environment]::NewLine)
					}
				})
		}
		
		
		elseif ($i -eq 41)
		{
			# Si c'est le deuxième bouton
			
			$button.Text = "SSID Récup"
			# Personnalisez le fond et la couleur du texte
			$button.BackColor = [System.Drawing.Color]::LightGreen
			$button.ForeColor = [System.Drawing.Color]::Gray
			$button.Add_Click({
					Add-Type -AssemblyName System.Windows.Forms
					Add-Type -AssemblyName System.Drawing

					# ── Fenêtre principale ────────────────────────────────────────────────
					$wf = New-Object System.Windows.Forms.Form
					$wf.Text = "WiFi — Profils et Clés"
					$wf.Size = New-Object System.Drawing.Size(600, 520)
					$wf.StartPosition = "CenterScreen"
					$wf.BackColor = [System.Drawing.Color]::FromArgb(243, 244, 246)
					$wf.MinimumSize = New-Object System.Drawing.Size(500, 420)

					# ── Topbar ────────────────────────────────────────────────────────────
					$top = New-Object System.Windows.Forms.Panel
					$top.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
					$top.Dock = [System.Windows.Forms.DockStyle]::Top
					$top.Height = 48
					$lblT = New-Object System.Windows.Forms.Label
					$lblT.Text = " WiFi — Profils et Clés"
					$lblT.ForeColor = [System.Drawing.Color]::White
					$lblT.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
					$lblT.AutoSize = $true; $lblT.Left = 10
					$lblT.Top = [int]((48 - 20) / 2)
					$top.Controls.Add($lblT)
					$wf.Controls.Add($top)

					# ── ListView des profils ──────────────────────────────────────────────
					$lv = New-Object System.Windows.Forms.ListView
					$lv.View = [System.Windows.Forms.View]::Details
					$lv.FullRowSelect = $true
					$lv.GridLines = $true
					$lv.Font = New-Object System.Drawing.Font("Segoe UI", 9)
					$lv.Dock = [System.Windows.Forms.DockStyle]::Fill
					$lv.Columns.Add("Profil WiFi", 250) | Out-Null
					$lv.Columns.Add("Type", 100) | Out-Null
					$lv.Columns.Add("Mot de passe", 200) | Out-Null

					# ── Panel gauche (liste) ──────────────────────────────────────────────
					$pLeft = New-Object System.Windows.Forms.Panel
					$pLeft.Dock = [System.Windows.Forms.DockStyle]::Fill
					$pLeft.Controls.Add($lv)

					# ── Panel boutons (droite) ────────────────────────────────────────────
					$pRight = New-Object System.Windows.Forms.Panel
					$pRight.Width = 160
					$pRight.Dock = [System.Windows.Forms.DockStyle]::Right
					$pRight.BackColor = [System.Drawing.Color]::FromArgb(248, 249, 250)
					$pRight.Padding = New-Object System.Windows.Forms.Padding(10)

					function New-WiFiBtn($text, $r, $g, $b) {
						$b2 = New-Object System.Windows.Forms.Button
						$b2.Text = $text; $b2.Width = 138; $b2.Height = 36
						$b2.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)
						$b2.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
						$b2.FlatAppearance.BorderSize = 0
						$b2.BackColor = [System.Drawing.Color]::FromArgb($r, $g, $b)
						$b2.ForeColor = [System.Drawing.Color]::White
						$b2.Cursor = [System.Windows.Forms.Cursors]::Hand
						$b2.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 8)
						return $b2
					}

					$btnRefresh = New-WiFiBtn "Actualiser"         37  99 235
					$btnShowPwd = New-WiFiBtn "Voir mot de passe"   88  28 135
					$btnExport  = New-WiFiBtn "Exporter tout"       22 163  74
					$btnExportSel = New-WiFiBtn "Exporter selection"  2 132 199
					$btnImport  = New-WiFiBtn "Importer"           194  65  12
					$btnClose2  = New-WiFiBtn "Fermer"              55  65  81

					$y = 12
					foreach ($b3 in @($btnRefresh, $btnShowPwd, $btnExport, $btnExportSel, $btnImport, $btnClose2)) {
						$b3.Top = $y; $b3.Left = 11; $y += 44
						$pRight.Controls.Add($b3)
					}

					# ── Status bar ────────────────────────────────────────────────────────
					$ss = New-Object System.Windows.Forms.StatusStrip
					$sl = New-Object System.Windows.Forms.ToolStripStatusLabel
					$sl.Text = "Cliquez sur Actualiser pour charger les profils"
					$ss.Items.Add($sl) | Out-Null
					$wf.Controls.Add($ss)

					# ── Splitter layout ────────────────────────────────────────────────────
					$pMain = New-Object System.Windows.Forms.Panel
					$pMain.Dock = [System.Windows.Forms.DockStyle]::Fill
					$pMain.Controls.Add($pLeft)
					$pMain.Controls.Add($pRight)
					$wf.Controls.Add($pMain)

					# ── Helper : charger les profils ──────────────────────────────────────
					$loadProfiles = {
						$lv.Items.Clear()
						$sl.Text = "Chargement..."
						[System.Windows.Forms.Application]::DoEvents()
						# Approche robuste : on split sur le premier ":" et on filtre
						# les lignes contenant "profil" ou "profile" (toutes locales)
						$raw = netsh wlan show profiles 2>$null
						$profiles = $raw | Where-Object {
							$_ -match "(?i)(profil|profile).{0,30}:"
						} | ForEach-Object {
							$parts = $_ -split ":\s*", 2
							if ($parts.Count -eq 2) { $parts[1].Trim() }
						} | Where-Object { $_ -and $_.Length -gt 1 }
						foreach ($p in $profiles) {
							$item = New-Object System.Windows.Forms.ListViewItem($p)
							$item.SubItems.Add("WiFi") | Out-Null
							$item.SubItems.Add("") | Out-Null
							$lv.Items.Add($item) | Out-Null
						}
						$sl.Text = "$($lv.Items.Count) profil(s) trouve(s)"
					}.GetNewClosure()

					# ── Actions ───────────────────────────────────────────────────────────
					$btnRefresh.Add_Click({ & $loadProfiles })

					$btnShowPwd.Add_Click({
						if ($lv.SelectedItems.Count -eq 0) {
							[System.Windows.Forms.MessageBox]::Show("Selectionnez un profil dans la liste.", "Info")
							return
						}
						$name = $lv.SelectedItems[0].Text
						$raw = netsh wlan show profile name="$name" key=clear 2>$null
						$pwd = ($raw | Select-String "Contenu de la cl|Key Content") -replace ".*:\s*",""
						if (-not $pwd) { $pwd = "(pas de mot de passe ou WPA-Enterprise)" }
						$lv.SelectedItems[0].SubItems[2].Text = $pwd.Trim()
						[System.Windows.Forms.MessageBox]::Show("$name`n`nMot de passe : $($pwd.Trim())", "Mot de passe WiFi")
					}.GetNewClosure())

					$btnExport.Add_Click({
						$fb = New-Object System.Windows.Forms.FolderBrowserDialog
						$fb.Description = "Choisissez le dossier de destination"
						if ($fb.ShowDialog() -eq "OK") {
							$dest = $fb.SelectedPath; $n = 0
							foreach ($item in $lv.Items) {
								netsh wlan export profile name="$($item.Text)" folder="$dest" key=clear 2>$null
								$n++
							}
							$sl.Text = "$n profil(s) exporte(s) vers $dest"
							[System.Windows.Forms.MessageBox]::Show("$n profil(s) exporté(s).`nDossier : $dest", "Export terminé")
						}
					}.GetNewClosure())

					$btnExportSel.Add_Click({
						if ($lv.SelectedItems.Count -eq 0) {
							[System.Windows.Forms.MessageBox]::Show("Selectionnez au moins un profil.", "Info")
							return
						}
						$fb = New-Object System.Windows.Forms.FolderBrowserDialog
						if ($fb.ShowDialog() -eq "OK") {
							$dest = $fb.SelectedPath; $n = 0
							foreach ($item in $lv.SelectedItems) {
								netsh wlan export profile name="$($item.Text)" folder="$dest" key=clear 2>$null
								$n++
							}
							$sl.Text = "$n profil(s) exporte(s)"
							[System.Windows.Forms.MessageBox]::Show("$n profil(s) exporté(s) vers $dest", "Export terminé")
						}
					}.GetNewClosure())

					$btnImport.Add_Click({
						$fb = New-Object System.Windows.Forms.FolderBrowserDialog
						$fb.Description = "Choisissez le dossier contenant les fichiers XML"
						if ($fb.ShowDialog() -eq "OK") {
							$files = Get-ChildItem -Path $fb.SelectedPath -Filter "*.xml" -ErrorAction SilentlyContinue
							if (-not $files) {
								[System.Windows.Forms.MessageBox]::Show("Aucun fichier XML trouvé dans ce dossier.", "Info")
								return
							}
							$n = 0
							foreach ($f in $files) {
								netsh wlan add profile filename="$($f.FullName)" user=all 2>$null
								$n++
							}
							$sl.Text = "$n profil(s) importé(s)"
							[System.Windows.Forms.MessageBox]::Show("$n profil(s) importé(s).", "Import terminé")
							& $loadProfiles
						}
					}.GetNewClosure())

					$btnClose2.Add_Click({ $wf.Close() })

					$wf.Add_Shown({ & $loadProfiles })
					[void]$wf.ShowDialog()
				})
		}
		elseif ($i -eq 53)
		{
			$button.Text = "Outils ++"
			$button.BackColor = [System.Drawing.Color]::FromArgb(16, 185, 129)
			$button.ForeColor = [System.Drawing.Color]::White
			$button.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 8)
			$button.Add_Click({
				Add-Type -AssemblyName System.Windows.Forms, System.Drawing
				$fSub = New-Object System.Windows.Forms.Form
				$fSub.Text = "Outils ++"
				$fSub.ClientSize = New-Object System.Drawing.Size(640, 378)
				$fSub.StartPosition = "CenterScreen"
				$fSub.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59)
				$fSub.FormBorderStyle = "FixedDialog"
				$fSub.MaximizeBox = $false

				$lbT = New-Object System.Windows.Forms.Label
				$lbT.Text = "  Outils ++"
				$lbT.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 13)
				$lbT.ForeColor = [System.Drawing.Color]::White
				$lbT.Size = New-Object System.Drawing.Size(620, 40)
				$lbT.Location = New-Object System.Drawing.Point(10, 8)
				$lbT.TextAlign = "MiddleLeft"
				$fSub.Controls.Add($lbT)

				function New-SubBtn2($text, $r, $g, $b, $col, $row) {
					$bw=188; $bh=62; $sx=12; $sy=58; $gx=8; $gy=8
					$btn = New-Object System.Windows.Forms.Button
					$btn.Text = $text
					$btn.Size = New-Object System.Drawing.Size($bw, $bh)
					$btn.Location = New-Object System.Drawing.Point(($sx + $col*($bw+$gx)), ($sy + $row*($bh+$gy)))
					$btn.BackColor = [System.Drawing.Color]::FromArgb($r, $g, $b)
					$btn.ForeColor = [System.Drawing.Color]::White
					$btn.FlatStyle = "Flat"
					$btn.FlatAppearance.BorderSize = 0
					$btn.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)
					$btn.Cursor = "Hand"
					$fSub.Controls.Add($btn)
					return $btn
				}

				$b53 = New-SubBtn2 "Cle Produit"      16  185 129  0 0
				$b54 = New-SubBtn2 "Test Reseau"      59  130 246  1 0
				$b55 = New-SubBtn2 "IP Config+"       14  165 233  2 0
				$b56 = New-SubBtn2 "BitLocker"       220   38  38  0 1
				$b57 = New-SubBtn2 "MalwareBytes"     30   41  59  1 1
				$b58 = New-SubBtn2 "Ports Ouverts"   124   45  18  2 1
				$b59 = New-SubBtn2 "Startup Manager" 245  158  11  0 2
				$b60 = New-SubBtn2 "Services Windows" 79   70 229  1 2
				$b61 = New-SubBtn2 "Scan Reseau"       6   78  59  2 2

				# ── Cle Produit ──────────────────────────────────────────────
				$b53.Add_Click({
					Add-Type -AssemblyName System.Windows.Forms, System.Drawing
					$ntKey   = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
					$build   = [int]$ntKey.CurrentBuildNumber
					$edition = $ntKey.EditionID
					$dispVer = $ntKey.DisplayVersion
					$winVer  = if ($build -ge 22000) { "Windows 11 $edition ($dispVer)" } else { "Windows 10 $edition ($dispVer)" }
					$winKey = try { (Get-WmiObject -query 'select * from SoftwareLicensingService').OA3xOriginalProductKey } catch { $null }
					if (-not $winKey) { $winKey = try { (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SoftwareProtectionPlatform').BackupProductKeyDefault } catch { $null } }
					if (-not $winKey) {
						try {
							$dpid4 = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').DigitalProductId4
							if ($dpid4 -and $dpid4.Length -ge 67) {
								$map = 'BCDFGHJKMPQRTVWXY2346789'
								$bytes = $dpid4[52..66]
								$wkey = ''; $ki = 24
								do {
									$cur = 0; $j = 14
									do { $cur = $cur * 256 -bxor $bytes[$j]; $bytes[$j] = [math]::Floor($cur/24); $cur = $cur%24; $j-- } while ($j -ge 0)
									$wkey = $map[$cur] + $wkey
									if ((24-$ki) % 5 -eq 0 -and $ki -ne 0) { $wkey = '-' + $wkey }
									$ki--
								} while ($ki -ge 0)
								$winKey = $wkey
							}
						} catch { }
					}
					if (-not $winKey) { $winKey = "Non disponible (licence numerique ou KMS)" }
					$officeLabel = "Non installe"; $officeKey = "Non disponible"; $officeStatus = ""; $officeChannel = ""
					$gvlkMap = @{
						'ProPlus2024'='FXKVE-B26FN-MKKQP-2PT3X-D9BWM'; 'Standard2024'='V28N4-JG22K-W66P8-VTMGK-H7X33'
						'ProPlus2021'='FTNWT-C6WBT-8TTGW-BCY3V-JD2RK'; 'Standard2021'='KDX7X-BNVR8-TXXGX-4Q7Y8-78VT3'
						'ProPlus2019'='NMMKJ-6RK4F-KMJVX-8D9MJ-6MWKP'; 'Standard2019'='6NWWJ-YQWMR-QKGCB-6TMB3-9D9HK'
						'ProPlus2016'='XQNVK-8JYDB-WJ9W3-YJ8YR-WFG99'; 'Standard2016'='JNRGM-WHDWX-FJJG3-K47QV-DRTFM'
					}
					$oLic = $null
					try { $oLic = Get-WmiObject -Query "SELECT Name,LicenseStatus,ProductKeyChannel,PartialProductKey FROM SoftwareLicensingProduct WHERE ApplicationId='0ff1ce15-a989-479d-af46-f275c6370663' AND LicenseStatus=1" -ErrorAction Stop | Select-Object -First 1 } catch { }
					if ($oLic) {
						$officeLabel = $oLic.Name -replace '\s*\(.*\)\s*$',''; $officeChannel = "$($oLic.ProductKeyChannel)"; $last5 = "$($oLic.PartialProductKey)"
						$relId = ""; $c2rConf = try { Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration' -ErrorAction Stop } catch { $null }
						if ($c2rConf -and $c2rConf.ProductReleaseIds) { $relId = "$($c2rConf.ProductReleaseIds)" }
						if ($officeChannel -eq "Volume:GVLK") {
							$gvlk = ""
							foreach ($year in @('2024','2021','2019','2016')) {
								foreach ($ed2 in @('ProPlus','Standard')) {
									$k = "$ed2$year"
									if ($gvlkMap.ContainsKey($k) -and ($relId -match $k -or $officeLabel -match $ed2 -and $officeLabel -match $year)) { $gvlk = $gvlkMap[$k]; break }
								}
								if ($gvlk) { break }
							}
							if (-not $gvlk) { foreach ($year in @('2024','2021','2019','2016')) { if ($officeLabel -match $year) { $key2 = if ($officeLabel -match 'Plus') { "ProPlus$year" } else { "Standard$year" }; if ($gvlkMap.ContainsKey($key2)) { $gvlk = $gvlkMap[$key2]; break } } } }
							if ($gvlk) { $officeKey = "$gvlk  [GVLK - cle generique VL publique]"; $officeStatus = "Active via KMS (Volume License - GVLK)" }
							else { $officeKey = "****-*****-*****-*****-$last5  [KMS GVLK]"; $officeStatus = "Active via KMS (Volume License)" }
						} elseif ($officeChannel -eq "Volume:MAK") {
							$officeKey = "****-*****-*****-*****-$last5  [MAK - 5 derniers chars]"; $officeStatus = "Active via MAK (Multiple Activation Key)"
						} else {
							$officeKey = "****-*****-*****-*****-$last5"; $officeStatus = if ($officeChannel) { "Active ($officeChannel)" } else { "Active" }
						}
					} else {
						$osppPaths = @("$env:ProgramFiles\Microsoft Office\Office16\OSPP.VBS","$env:ProgramFiles(x86)\Microsoft Office\Office16\OSPP.VBS","$env:ProgramFiles\Microsoft Office\root\Office16\OSPP.VBS")
						$osppPath = $osppPaths | Where-Object { Test-Path $_ } | Select-Object -First 1
						if ($osppPath) {
							$osppOut = & cscript //nologo $osppPath /dstatus 2>&1; $osppText = ($osppOut -join "`n")
							$nameM = [regex]::Match($osppText,'(?:LICENSE NAME|NOM DE LA LICENCE)[^\r\n:]*:\s*(.+)','IgnoreCase')
							$statM = [regex]::Match($osppText,'(?:LICENSE STATUS|STATUT)[^\r\n:]*:\s*(.+)','IgnoreCase')
							$last5M = [regex]::Match($osppText,'(?:Last 5 characters|5 derniers|Derniers 5)[^\r\n:]*:\s*([A-Z0-9]{5})','IgnoreCase')
							$chanM = [regex]::Match($osppText,'(?:License channel|Canal)[^\r\n:]*:\s*(.+)','IgnoreCase')
							if ($nameM.Success)  { $officeLabel  = $nameM.Groups[1].Value.Trim() }
							if ($statM.Success)  { $officeStatus = ($statM.Groups[1].Value.Trim() -replace '-','').Trim() }
							if ($chanM.Success)  { $officeChannel = $chanM.Groups[1].Value.Trim() }
							if ($last5M.Success) { $officeKey = "****-*****-*****-*****-$($last5M.Groups[1].Value)" }
						}
						if ($officeLabel -eq "Non installe") {
							$c2r = try { Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration' -ErrorAction Stop } catch { $null }
							if ($c2r -and $c2r.ProductReleaseIds) { $officeLabel = "$($c2r.ProductReleaseIds)" -replace ',',' / ' }
						}
					}
					$f = New-Object System.Windows.Forms.Form
					$f.Text = "Cles Produit Windows & Office"; $f.Size = New-Object System.Drawing.Size(700,310)
					$f.StartPosition = "CenterScreen"; $f.BackColor = [System.Drawing.Color]::FromArgb(243,244,246)
					$tlp = New-Object System.Windows.Forms.TableLayoutPanel
					$tlp.Dock = "Fill"; $tlp.RowCount = 6; $tlp.ColumnCount = 2
					$tlp.Padding = New-Object System.Windows.Forms.Padding(16)
					$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,26)))
					$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,74)))
					function Add-KV2($parent,$row2,$k,$v) {
						$lk = New-Object System.Windows.Forms.Label; $lk.Text=$k
						$lk.Font=New-Object System.Drawing.Font("Segoe UI Semibold",9); $lk.Dock="Fill"; $lk.TextAlign="MiddleLeft"
						$lv = New-Object System.Windows.Forms.TextBox; $lv.Text=$v
						$lv.Font=New-Object System.Drawing.Font("Consolas",9); $lv.ReadOnly=$true; $lv.Dock="Fill"
						$lv.BackColor=[System.Drawing.Color]::White
						$parent.Controls.Add($lk,0,$row2); $parent.Controls.Add($lv,1,$row2)
					}
					Add-KV2 $tlp 0 "Windows" $winVer
					Add-KV2 $tlp 1 "Cle Windows" $winKey
					Add-KV2 $tlp 2 "Office detecte" $officeLabel
					Add-KV2 $tlp 3 "Cle / Canal" $officeKey
					Add-KV2 $tlp 4 "Statut licence" $(if($officeStatus){$officeStatus}else{"N/A"})
					$btnCopy = New-Object System.Windows.Forms.Button; $btnCopy.Text = "Copier tout"; $btnCopy.Dock = "Fill"
					$btnCopy.FlatStyle = "Flat"; $btnCopy.BackColor=[System.Drawing.Color]::FromArgb(16,185,129); $btnCopy.ForeColor=[System.Drawing.Color]::White
					$btnCopy.Add_Click({
						$txt  = "=== Rapport Cles Produit ===`n"
						$txt += "Windows     : $winVer`n"
						$txt += "Cle Windows : $winKey`n"
						$txt += "Office      : $officeLabel`n"
						$txt += "Cle Office  : $officeKey`n"
						$txt += "Canal       : $officeChannel`n"
						$txt += "Statut      : $officeStatus`n"
						[System.Windows.Forms.Clipboard]::SetText($txt)
						[System.Windows.Forms.MessageBox]::Show("Copie dans le presse-papiers !","OK")
					})
					$tlp.Controls.Add($btnCopy,0,5); $tlp.SetColumnSpan($btnCopy,2)
					$f.Controls.Add($tlp); [void]$f.ShowDialog()
				})

				# ── Test Reseau ───────────────────────────────────────────────
				$b54.Add_Click({
					Add-Type -AssemblyName System.Windows.Forms, System.Drawing
					$f = New-Object System.Windows.Forms.Form
					$f.Text = "Test Reseau"; $f.Size = New-Object System.Drawing.Size(640,520)
					$f.StartPosition = "CenterScreen"; $f.BackColor = [System.Drawing.Color]::FromArgb(15,23,42)
					$tlp = New-Object System.Windows.Forms.TableLayoutPanel
					$tlp.Dock = "Fill"; $tlp.RowCount = 2; $tlp.ColumnCount = 1
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,60)))
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$f.Controls.Add($tlp)
					$pTop = New-Object System.Windows.Forms.Panel; $pTop.Dock="Fill"; $pTop.BackColor=[System.Drawing.Color]::FromArgb(30,41,59)
					$tlp.Controls.Add($pTop,0,0)
					$rtb = New-Object System.Windows.Forms.RichTextBox
					$rtb.Dock="Fill"; $rtb.BackColor=[System.Drawing.Color]::FromArgb(15,23,42)
					$rtb.ForeColor=[System.Drawing.Color]::FromArgb(209,213,219)
					$rtb.Font=New-Object System.Drawing.Font("Consolas",9); $rtb.ReadOnly=$true
					$tlp.Controls.Add($rtb,0,1)
					function BtnTR($text,$color) {
						$b=New-Object System.Windows.Forms.Button; $b.Text=$text; $b.Height=40; $b.Font=New-Object System.Drawing.Font("Segoe UI Semibold",8)
						$b.FlatStyle="Flat"; $b.FlatAppearance.BorderSize=0; $b.BackColor=$color; $b.ForeColor=[System.Drawing.Color]::White; $b.Cursor="Hand"
						$pTop.Controls.Add($b); return $b
					}
					$bPing  = BtnTR "Ping Google" ([System.Drawing.Color]::FromArgb(37,99,235))
					$bDNS   = BtnTR "DNS Lookup"  ([System.Drawing.Color]::FromArgb(16,185,129))
					$bTrace = BtnTR "Traceroute"  ([System.Drawing.Color]::FromArgb(245,158,11))
					$bClear = BtnTR "Effacer"     ([System.Drawing.Color]::FromArgb(55,65,81))
					$x = 8
					foreach ($b in @($bPing,$bDNS,$bTrace,$bClear)) { $b.Location=New-Object System.Drawing.Point($x,10); $b.Width=120; $x+=128 }
					$log2 = { param($msg,$cl="White")
						$rtb.SelectionStart=$rtb.TextLength; $rtb.SelectionLength=0
						$rtb.SelectionColor=switch($cl){"Green"{[System.Drawing.Color]::FromArgb(74,222,128)}"Yellow"{[System.Drawing.Color]::FromArgb(251,191,36)}"Red"{[System.Drawing.Color]::FromArgb(248,113,113)}default{[System.Drawing.Color]::FromArgb(209,213,219)}}
						$rtb.AppendText("$msg`n"); $rtb.ScrollToCaret(); [System.Windows.Forms.Application]::DoEvents()
					}
					$bPing.Add_Click({ & $log2 "=== Ping 8.8.8.8 ===" "Yellow"; $res = ping 8.8.8.8 -n 4 2>&1; $res | ForEach-Object { $c=if($_-match "temps<|ms"){"Green"}elseif($_-match "delai|Timeout"){"Red"}else{"White"}; & $log2 $_ $c } }.GetNewClosure())
					$bDNS.Add_Click({
						& $log2 "=== DNS Lookup ===" "Yellow"
						try { $r=Resolve-DnsName google.com -ErrorAction Stop; & $log2 "google.com -> $($r.IPAddress -join ', ')" "Green" } catch { & $log2 "Erreur DNS: $_" "Red" }
						try { $r=Resolve-DnsName cloudflare.com -ErrorAction Stop; & $log2 "cloudflare.com -> $($r.IPAddress -join ', ')" "Green" } catch { & $log2 "Erreur DNS: $_" "Red" }
						$dns=(Get-DnsClientServerAddress -AddressFamily IPv4 | Where-Object{$_.ServerAddresses} | Select-Object -First 1).ServerAddresses
						& $log2 "DNS configures: $($dns -join ', ')" "White"
					}.GetNewClosure())
					$bTrace.Add_Click({ & $log2 "=== Traceroute vers 8.8.8.8 ===" "Yellow"; $t=tracert -d -h 15 8.8.8.8 2>&1; $t | ForEach-Object { & $log2 $_ "White" } }.GetNewClosure())
					$bClear.Add_Click({ $rtb.Clear() })
					& $log2 "Test Reseau pret. Cliquez un bouton." "Green"
					[void]$f.ShowDialog()
				})

				# ── IP Config+ ────────────────────────────────────────────────
				$b55.Add_Click({
					Add-Type -AssemblyName System.Windows.Forms, System.Drawing
					$f = New-Object System.Windows.Forms.Form
					$f.Text = "IP Config+"; $f.Size = New-Object System.Drawing.Size(700,500)
					$f.StartPosition = "CenterScreen"; $f.BackColor = [System.Drawing.Color]::FromArgb(243,244,246)
					$tlp = New-Object System.Windows.Forms.TableLayoutPanel
					$tlp.Dock="Fill"; $tlp.RowCount=2; $tlp.ColumnCount=1
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,50)))
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$f.Controls.Add($tlp)
					$pAct=New-Object System.Windows.Forms.Panel; $pAct.Dock="Fill"; $pAct.BackColor=[System.Drawing.Color]::FromArgb(30,41,59)
					$tlp.Controls.Add($pAct,0,0)
					$dgv=New-Object System.Windows.Forms.DataGridView
					$dgv.Dock="Fill"; $dgv.ReadOnly=$true; $dgv.AllowUserToAddRows=$false
					$dgv.AutoSizeColumnsMode="Fill"; $dgv.SelectionMode="FullRowSelect"; $dgv.RowHeadersVisible=$false
					$dgv.BackgroundColor=[System.Drawing.Color]::White; $dgv.Font=New-Object System.Drawing.Font("Consolas",8)
					$dgv.ColumnHeadersDefaultCellStyle.BackColor=[System.Drawing.Color]::FromArgb(15,23,42)
					$dgv.ColumnHeadersDefaultCellStyle.ForeColor=[System.Drawing.Color]::White
					$dgv.EnableHeadersVisualStyles=$false; $tlp.Controls.Add($dgv,0,1)
					function Make-BtnIP($text,$color,$x) {
						$b=New-Object System.Windows.Forms.Button; $b.Text=$text; $b.Size=New-Object System.Drawing.Size(140,32)
						$b.Location=New-Object System.Drawing.Point($x,9); $b.Font=New-Object System.Drawing.Font("Segoe UI Semibold",8)
						$b.FlatStyle="Flat"; $b.FlatAppearance.BorderSize=0; $b.BackColor=$color; $b.ForeColor=[System.Drawing.Color]::White; $b.Cursor="Hand"
						$pAct.Controls.Add($b); return $b
					}
					$bRefresh  = Make-BtnIP "Actualiser"    ([System.Drawing.Color]::FromArgb(37,99,235))  8
					$bFlushDNS = Make-BtnIP "Flush DNS"     ([System.Drawing.Color]::FromArgb(234,179,8))  156
					$bRenewIP  = Make-BtnIP "Renouveler IP" ([System.Drawing.Color]::FromArgb(16,185,129)) 304
					$bCloseIP  = Make-BtnIP "Fermer"        ([System.Drawing.Color]::FromArgb(55,65,81))   452
					function Refresh-TableIP {
						$dt=New-Object System.Data.DataTable
						"Carte","IPv4","IPv6","Masque","Passerelle","MAC","DNS","DHCP" | ForEach-Object { $dt.Columns.Add($_) | Out-Null }
						Get-CimInstance Win32_NetworkAdapterConfiguration -ErrorAction SilentlyContinue | Where-Object {$_.IPEnabled} | ForEach-Object {
							$ip4=($_.IPAddress|Where-Object{$_ -match '^\d'}|Select-Object -First 1)
							$ip6=($_.IPAddress|Where-Object{$_ -match ':'}|Select-Object -First 1)
							$mask=($_.IPSubnet|Select-Object -First 1)
							$gw=($_.DefaultIPGateway|Select-Object -First 1)
							$dns=(($_.DNSServerSearchOrder) -join ' / ')
							$dt.Rows.Add([string]$_.Description,[string]$ip4,[string]$ip6,[string]$mask,[string]$gw,[string]$_.MACAddress,[string]$dns,$(if($_.DHCPEnabled){"Oui"}else{"Non"})) | Out-Null
						}
						$dgv.DataSource=$dt
					}
					Refresh-TableIP
					$bRefresh.Add_Click({ Refresh-TableIP })
					$bFlushDNS.Add_Click({ ipconfig /flushdns 2>&1 | Out-Null; [System.Windows.Forms.MessageBox]::Show("Cache DNS vide.","Flush DNS") })
					$bRenewIP.Add_Click({ ipconfig /release 2>&1 | Out-Null; ipconfig /renew 2>&1 | Out-Null; Refresh-TableIP; [System.Windows.Forms.MessageBox]::Show("IP renouvelee.","Renouveler IP") })
					$bCloseIP.Add_Click({ $f.Close() })
					[void]$f.ShowDialog()
				})

				# ── BitLocker ─────────────────────────────────────────────────
				$b56.Add_Click({
					Add-Type -AssemblyName System.Windows.Forms, System.Drawing
					$f = New-Object System.Windows.Forms.Form
					$f.Text = "BitLocker — Statut & Gestion"; $f.Size = New-Object System.Drawing.Size(680,440)
					$f.StartPosition = "CenterScreen"; $f.BackColor = [System.Drawing.Color]::FromArgb(243,244,246)
					$tlp=New-Object System.Windows.Forms.TableLayoutPanel; $tlp.Dock="Fill"; $tlp.RowCount=2; $tlp.ColumnCount=1
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,50)))
					$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$f.Controls.Add($tlp)
					$dgv=New-Object System.Windows.Forms.DataGridView; $dgv.Dock="Fill"; $dgv.ReadOnly=$true; $dgv.AllowUserToAddRows=$false
					$dgv.AutoSizeColumnsMode="Fill"; $dgv.SelectionMode="FullRowSelect"; $dgv.RowHeadersVisible=$false
					$dgv.BackgroundColor=[System.Drawing.Color]::White; $dgv.Font=New-Object System.Drawing.Font("Segoe UI",9)
					$dgv.ColumnHeadersDefaultCellStyle.BackColor=[System.Drawing.Color]::FromArgb(15,23,42)
					$dgv.ColumnHeadersDefaultCellStyle.ForeColor=[System.Drawing.Color]::White
					$dgv.EnableHeadersVisualStyles=$false; $tlp.Controls.Add($dgv,0,0)
					$pBot=New-Object System.Windows.Forms.Panel; $pBot.Dock="Fill"; $pBot.BackColor=[System.Drawing.Color]::FromArgb(30,41,59)
					$tlp.Controls.Add($pBot,0,1)
					function Load-BL {
						$dt=New-Object System.Data.DataTable
						"Lecteur","Statut","Methode","Protection","% Chiffre" | ForEach-Object { $dt.Columns.Add($_) | Out-Null }
						try { Get-BitLockerVolume -ErrorAction Stop | ForEach-Object { $dt.Rows.Add($_.MountPoint,$_.VolumeStatus,$_.EncryptionMethod,$_.ProtectionStatus,"$($_.EncryptionPercentage)%") | Out-Null } }
						catch { $dt.Rows.Add("Erreur","BitLocker non disponible ou droits insuffisants","","","") | Out-Null }
						$dgv.DataSource=$dt
					}
					Load-BL
					$bRef=New-Object System.Windows.Forms.Button; $bRef.Text="Actualiser"; $bRef.Size=New-Object System.Drawing.Size(130,32); $bRef.Location=New-Object System.Drawing.Point(8,9)
					$bRef.FlatStyle="Flat"; $bRef.FlatAppearance.BorderSize=0; $bRef.BackColor=[System.Drawing.Color]::FromArgb(37,99,235); $bRef.ForeColor=[System.Drawing.Color]::White
					$bRef.Add_Click({ Load-BL })
					$bManage=New-Object System.Windows.Forms.Button; $bManage.Text="Gerer (Panneau de config)"; $bManage.Size=New-Object System.Drawing.Size(200,32); $bManage.Location=New-Object System.Drawing.Point(146,9)
					$bManage.FlatStyle="Flat"; $bManage.FlatAppearance.BorderSize=0; $bManage.BackColor=[System.Drawing.Color]::FromArgb(220,38,38); $bManage.ForeColor=[System.Drawing.Color]::White
					$bManage.Add_Click({ Start-Process "control" -ArgumentList "/name Microsoft.BitLockerDriveEncryption" })
					$bClose2=New-Object System.Windows.Forms.Button; $bClose2.Text="Fermer"; $bClose2.Size=New-Object System.Drawing.Size(90,32); $bClose2.Location=New-Object System.Drawing.Point(354,9)
					$bClose2.FlatStyle="Flat"; $bClose2.FlatAppearance.BorderSize=0; $bClose2.BackColor=[System.Drawing.Color]::FromArgb(55,65,81); $bClose2.ForeColor=[System.Drawing.Color]::White
					$bClose2.Add_Click({ $f.Close() })
					$pBot.Controls.AddRange(@($bRef,$bManage,$bClose2))
					[void]$f.ShowDialog()
				})

				# ── MalwareBytes ──────────────────────────────────────────────
				$b57.Add_Click({
					Add-Type -AssemblyName System.Windows.Forms
					$mbPaths = @("$env:ProgramFiles\Malwarebytes\Anti-Malware\mbam.exe","$env:ProgramFiles(x86)\Malwarebytes\Anti-Malware\mbam.exe")
					$found = $mbPaths | Where-Object { Test-Path $_ } | Select-Object -First 1
					if ($found) { Start-Process $found; return }
					$r = [System.Windows.Forms.MessageBox]::Show("Malwarebytes non installe. Telecharger ?","Malwarebytes",[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
					if ($r -eq "Yes") {
						$out = "$env:TEMP\MBSetup.exe"
						try { Invoke-WebRequest "https://downloads.malwarebytes.com/file/mb-windows" -OutFile $out -UseBasicParsing -TimeoutSec 60; Start-Process $out }
						catch { [System.Windows.Forms.MessageBox]::Show("Erreur telechargement : $_") }
					}
				})

				# ── Ports Ouverts ─────────────────────────────────────────────
				$b58.Add_Click({
					Add-Type -AssemblyName System.Windows.Forms, System.Drawing
					$f=New-Object System.Windows.Forms.Form; $f.Text="Ports ouverts — Connexions actives"
					$f.Size=New-Object System.Drawing.Size(900,580); $f.StartPosition="CenterScreen"; $f.BackColor=[System.Drawing.Color]::FromArgb(243,244,246)
					$tlp=New-Object System.Windows.Forms.TableLayoutPanel; $tlp.Dock="Fill"; $tlp.RowCount=2; $tlp.ColumnCount=1
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,50)))
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$f.Controls.Add($tlp)
					$pTop=New-Object System.Windows.Forms.Panel; $pTop.Dock="Fill"; $pTop.BackColor=[System.Drawing.Color]::FromArgb(30,41,59); $tlp.Controls.Add($pTop,0,0)
					$dgv=New-Object System.Windows.Forms.DataGridView; $dgv.Dock="Fill"; $dgv.ReadOnly=$true; $dgv.AllowUserToAddRows=$false
					$dgv.AutoSizeColumnsMode="Fill"; $dgv.SelectionMode="FullRowSelect"; $dgv.RowHeadersVisible=$false
					$dgv.BackgroundColor=[System.Drawing.Color]::White; $dgv.Font=New-Object System.Drawing.Font("Consolas",8)
					$dgv.ColumnHeadersDefaultCellStyle.BackColor=[System.Drawing.Color]::FromArgb(15,23,42)
					$dgv.ColumnHeadersDefaultCellStyle.ForeColor=[System.Drawing.Color]::White
					$dgv.EnableHeadersVisualStyles=$false; $tlp.Controls.Add($dgv,0,1)
					function Load-PO {
					 try {
						$dt=New-Object System.Data.DataTable
						"Proto","IP Locale","Port Local","IP Distante","Port Distant","Etat","PID","Processus" | ForEach-Object { $dt.Columns.Add($_) | Out-Null }
						$conns=netstat -ano 2>&1 | Select-String "(TCP|UDP)\s"
						$procs=Get-Process -ErrorAction SilentlyContinue | Group-Object Id -AsHashTable -AsString
						foreach ($c in $conns) {
							$p=$c.ToString().Trim() -split '\s+'
							if ($p.Count -lt 4) { continue }
							$proto=$p[0]; $local=$p[1]; $remote=$p[2]
							$state=if($proto -eq "TCP"){$p[3]}else{""}; $pid_=if($proto -eq "TCP"){$p[4]}else{$p[3]}
							$localPort=if($local -match ':(\d+)$'){$Matches[1]}else{""}
							$remotePort=if($remote -match ':(\d+)$'){$Matches[1]}else{""}
							$localIP=$local -replace ':\d+$',''; $remoteIP=$remote -replace ':\d+$',''
							$procName=if($procs[$pid_]){$procs[$pid_][0].ProcessName}else{"PID:$pid_"}
							$dt.Rows.Add($proto,$localIP,$localPort,$remoteIP,$remotePort,$state,$pid_,$procName) | Out-Null
						}
						$dgv.DataSource=$dt
					 } catch { [System.Windows.Forms.MessageBox]::Show("Erreur chargement ports: $_") }
					}
					Load-PO
					$bRef=New-Object System.Windows.Forms.Button; $bRef.Text="Actualiser"; $bRef.Size=New-Object System.Drawing.Size(120,32); $bRef.Location=New-Object System.Drawing.Point(8,9)
					$bRef.FlatStyle="Flat"; $bRef.FlatAppearance.BorderSize=0; $bRef.BackColor=[System.Drawing.Color]::FromArgb(37,99,235); $bRef.ForeColor=[System.Drawing.Color]::White
					$bRef.Add_Click({ Load-PO })
					$bClose=New-Object System.Windows.Forms.Button; $bClose.Text="Fermer"; $bClose.Size=New-Object System.Drawing.Size(90,32); $bClose.Location=New-Object System.Drawing.Point(136,9)
					$bClose.FlatStyle="Flat"; $bClose.FlatAppearance.BorderSize=0; $bClose.BackColor=[System.Drawing.Color]::FromArgb(55,65,81); $bClose.ForeColor=[System.Drawing.Color]::White
					$bClose.Add_Click({ $f.Close() })
					$pTop.Controls.AddRange(@($bRef,$bClose))
					[void]$f.ShowDialog()
				})

				# ── Startup Manager ───────────────────────────────────────────
				$b59.Add_Click({
					Add-Type -AssemblyName System.Windows.Forms, System.Drawing
					$f=New-Object System.Windows.Forms.Form; $f.Text="Startup Manager — Programmes au demarrage"
					$f.Size=New-Object System.Drawing.Size(820,520); $f.StartPosition="CenterScreen"; $f.BackColor=[System.Drawing.Color]::FromArgb(243,244,246)
					$tlp=New-Object System.Windows.Forms.TableLayoutPanel; $tlp.Dock="Fill"; $tlp.RowCount=2; $tlp.ColumnCount=1
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,50)))
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$f.Controls.Add($tlp)
					$pTop=New-Object System.Windows.Forms.Panel; $pTop.Dock="Fill"; $pTop.BackColor=[System.Drawing.Color]::FromArgb(30,41,59); $tlp.Controls.Add($pTop,0,0)
					$dgv=New-Object System.Windows.Forms.DataGridView; $dgv.Dock="Fill"; $dgv.AllowUserToAddRows=$false
					$dgv.AutoSizeColumnsMode="Fill"; $dgv.SelectionMode="FullRowSelect"; $dgv.RowHeadersVisible=$false
					$dgv.BackgroundColor=[System.Drawing.Color]::White; $dgv.Font=New-Object System.Drawing.Font("Segoe UI",9)
					$dgv.ColumnHeadersDefaultCellStyle.BackColor=[System.Drawing.Color]::FromArgb(15,23,42)
					$dgv.ColumnHeadersDefaultCellStyle.ForeColor=[System.Drawing.Color]::White
					$dgv.EnableHeadersVisualStyles=$false; $tlp.Controls.Add($dgv,0,1)
					$script:startupItems = @()
					function Load-SM {
						$script:startupItems = @()
						$regPaths = @(
							@{Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'; Hive='HKLM (tous)'},
							@{Path='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'; Hive='HKCU (utilisateur)'},
							@{Path='HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'; Hive='HKLM x86'}
						)
						foreach ($rp in $regPaths) {
							if (Test-Path $rp.Path) {
								$props = Get-ItemProperty $rp.Path -ErrorAction SilentlyContinue
								if ($props) {
									$props | Get-Member -MemberType NoteProperty -ErrorAction SilentlyContinue |
									Where-Object {$_.Name -notmatch '^PS'} | ForEach-Object {
										$val=$props.$($_.Name)
										$script:startupItems += [PSCustomObject]@{Nom=$_.Name; Commande=$val; Source=$rp.Hive; Chemin=$rp.Path; Actif="Oui"}
									}
								}
							}
						}
						$startupFolder = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"
						Get-ChildItem $startupFolder -ErrorAction SilentlyContinue | ForEach-Object {
							$script:startupItems += [PSCustomObject]@{Nom=$_.Name; Commande=$_.FullName; Source="Dossier Demarrage"; Chemin=$_.FullName; Actif="Oui"}
						}
						$dt=New-Object System.Data.DataTable
						"Nom","Source","Commande","Actif" | ForEach-Object { $dt.Columns.Add($_) | Out-Null }
						$script:startupItems | ForEach-Object { $dt.Rows.Add($_.Nom,$_.Source,$_.Commande,$_.Actif) | Out-Null }
						$dgv.DataSource=$dt
					}
					Load-SM
					$bRef=New-Object System.Windows.Forms.Button; $bRef.Text="Actualiser"; $bRef.Size=New-Object System.Drawing.Size(110,32); $bRef.Location=New-Object System.Drawing.Point(8,9)
					$bRef.FlatStyle="Flat"; $bRef.FlatAppearance.BorderSize=0; $bRef.BackColor=[System.Drawing.Color]::FromArgb(37,99,235); $bRef.ForeColor=[System.Drawing.Color]::White
					$bRef.Add_Click({ Load-SM })
					$bDel=New-Object System.Windows.Forms.Button; $bDel.Text="Supprimer selection"; $bDel.Size=New-Object System.Drawing.Size(160,32); $bDel.Location=New-Object System.Drawing.Point(126,9)
					$bDel.FlatStyle="Flat"; $bDel.FlatAppearance.BorderSize=0; $bDel.BackColor=[System.Drawing.Color]::FromArgb(220,38,38); $bDel.ForeColor=[System.Drawing.Color]::White
					$bDel.Add_Click({
						if ($dgv.SelectedRows.Count -eq 0) { return }
						$row2=$dgv.SelectedRows[0]; $nom=$row2.Cells[0].Value; $source=$row2.Cells[1].Value
						$item=$script:startupItems | Where-Object {$_.Nom -eq $nom -and $_.Source -eq $source} | Select-Object -First 1
						if (-not $item) { return }
						$r=[System.Windows.Forms.MessageBox]::Show("Supprimer '$nom' du demarrage ?","Confirmation",[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning)
						if ($r -ne "Yes") { return }
						if ($item.Source -like "Dossier*") { Remove-Item $item.Chemin -Force -ErrorAction SilentlyContinue }
						else { Remove-ItemProperty -Path $item.Chemin -Name $item.Nom -ErrorAction SilentlyContinue }
						Load-SM
					})
					$bMsConfig=New-Object System.Windows.Forms.Button; $bMsConfig.Text="Ouvrir msconfig"; $bMsConfig.Size=New-Object System.Drawing.Size(130,32); $bMsConfig.Location=New-Object System.Drawing.Point(294,9)
					$bMsConfig.FlatStyle="Flat"; $bMsConfig.FlatAppearance.BorderSize=0; $bMsConfig.BackColor=[System.Drawing.Color]::FromArgb(55,65,81); $bMsConfig.ForeColor=[System.Drawing.Color]::White
					$bMsConfig.Add_Click({ Start-Process msconfig })
					$bClose=New-Object System.Windows.Forms.Button; $bClose.Text="Fermer"; $bClose.Size=New-Object System.Drawing.Size(90,32); $bClose.Location=New-Object System.Drawing.Point(432,9)
					$bClose.FlatStyle="Flat"; $bClose.FlatAppearance.BorderSize=0; $bClose.BackColor=[System.Drawing.Color]::FromArgb(55,65,81); $bClose.ForeColor=[System.Drawing.Color]::White
					$bClose.Add_Click({ $f.Close() })
					$pTop.Controls.AddRange(@($bRef,$bDel,$bMsConfig,$bClose))
					[void]$f.ShowDialog()
				})

				# ── Services Windows ──────────────────────────────────────────
				$b60.Add_Click({
					Add-Type -AssemblyName System.Windows.Forms, System.Drawing
					$f=New-Object System.Windows.Forms.Form; $f.Text="Services Windows — Gestion rapide"
					$f.Size=New-Object System.Drawing.Size(860,540); $f.StartPosition="CenterScreen"; $f.BackColor=[System.Drawing.Color]::FromArgb(243,244,246)
					$tlp=New-Object System.Windows.Forms.TableLayoutPanel; $tlp.Dock="Fill"; $tlp.RowCount=2; $tlp.ColumnCount=1
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,50)))
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$f.Controls.Add($tlp)
					$pTop=New-Object System.Windows.Forms.Panel; $pTop.Dock="Fill"; $pTop.BackColor=[System.Drawing.Color]::FromArgb(30,41,59); $tlp.Controls.Add($pTop,0,0)
					$dgv=New-Object System.Windows.Forms.DataGridView; $dgv.Dock="Fill"; $dgv.AllowUserToAddRows=$false
					$dgv.AutoSizeColumnsMode="Fill"; $dgv.SelectionMode="FullRowSelect"; $dgv.RowHeadersVisible=$false
					$dgv.BackgroundColor=[System.Drawing.Color]::White; $dgv.Font=New-Object System.Drawing.Font("Segoe UI",9)
					$dgv.ColumnHeadersDefaultCellStyle.BackColor=[System.Drawing.Color]::FromArgb(15,23,42)
					$dgv.ColumnHeadersDefaultCellStyle.ForeColor=[System.Drawing.Color]::White
					$dgv.EnableHeadersVisualStyles=$false; $tlp.Controls.Add($dgv,0,1)
					function Load-SvcWin {
						try {
							$dt=New-Object System.Data.DataTable
							"Nom","Etat","Demarrage","Description" | ForEach-Object { $dt.Columns.Add($_) | Out-Null }
							$wmi=@{}
							Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | ForEach-Object { $wmi[$_.Name]=$_ }
							Get-Service -ErrorAction SilentlyContinue | Sort-Object DisplayName | ForEach-Object {
								$w=$wmi[$_.Name]
								$start=if($w){[string]$w.StartMode}else{""}
								$desc=if($w){[string]$w.Description}else{""}
								$dt.Rows.Add([string]$_.DisplayName,[string]$_.Status,$start,$desc) | Out-Null
							}
							$dgv.DataSource=$dt
						} catch {
							[System.Windows.Forms.MessageBox]::Show("Erreur chargement services: $_")
						}
					}
					Load-SvcWin
					$bStartSvc=New-Object System.Windows.Forms.Button; $bStartSvc.Text="Demarrer"; $bStartSvc.Size=New-Object System.Drawing.Size(100,32); $bStartSvc.Location=New-Object System.Drawing.Point(8,9)
					$bStartSvc.FlatStyle="Flat"; $bStartSvc.FlatAppearance.BorderSize=0; $bStartSvc.BackColor=[System.Drawing.Color]::FromArgb(22,163,74); $bStartSvc.ForeColor=[System.Drawing.Color]::White
					$bStartSvc.Add_Click({
						if ($dgv.SelectedRows.Count -eq 0) { return }
						$name=$dgv.SelectedRows[0].Cells[0].Value
						try { $svc=Get-Service | Where-Object {$_.DisplayName -eq $name} | Select-Object -First 1; Start-Service $svc.Name -ErrorAction Stop; Load-SvcWin } catch { [System.Windows.Forms.MessageBox]::Show("Erreur: $_") }
					})
					$bStopSvc=New-Object System.Windows.Forms.Button; $bStopSvc.Text="Arreter"; $bStopSvc.Size=New-Object System.Drawing.Size(100,32); $bStopSvc.Location=New-Object System.Drawing.Point(116,9)
					$bStopSvc.FlatStyle="Flat"; $bStopSvc.FlatAppearance.BorderSize=0; $bStopSvc.BackColor=[System.Drawing.Color]::FromArgb(220,38,38); $bStopSvc.ForeColor=[System.Drawing.Color]::White
					$bStopSvc.Add_Click({
						if ($dgv.SelectedRows.Count -eq 0) { return }
						$name=$dgv.SelectedRows[0].Cells[0].Value
						try { $svc=Get-Service | Where-Object {$_.DisplayName -eq $name} | Select-Object -First 1; Stop-Service $svc.Name -Force -ErrorAction Stop; Load-SvcWin } catch { [System.Windows.Forms.MessageBox]::Show("Erreur: $_") }
					})
					$bRefSvc=New-Object System.Windows.Forms.Button; $bRefSvc.Text="Actualiser"; $bRefSvc.Size=New-Object System.Drawing.Size(100,32); $bRefSvc.Location=New-Object System.Drawing.Point(224,9)
					$bRefSvc.FlatStyle="Flat"; $bRefSvc.FlatAppearance.BorderSize=0; $bRefSvc.BackColor=[System.Drawing.Color]::FromArgb(37,99,235); $bRefSvc.ForeColor=[System.Drawing.Color]::White
					$bRefSvc.Add_Click({ Load-SvcWin })
					$bServMsc=New-Object System.Windows.Forms.Button; $bServMsc.Text="services.msc"; $bServMsc.Size=New-Object System.Drawing.Size(110,32); $bServMsc.Location=New-Object System.Drawing.Point(332,9)
					$bServMsc.FlatStyle="Flat"; $bServMsc.FlatAppearance.BorderSize=0; $bServMsc.BackColor=[System.Drawing.Color]::FromArgb(55,65,81); $bServMsc.ForeColor=[System.Drawing.Color]::White
					$bServMsc.Add_Click({ Start-Process services.msc })
					$bCloseSvc=New-Object System.Windows.Forms.Button; $bCloseSvc.Text="Fermer"; $bCloseSvc.Size=New-Object System.Drawing.Size(90,32); $bCloseSvc.Location=New-Object System.Drawing.Point(450,9)
					$bCloseSvc.FlatStyle="Flat"; $bCloseSvc.FlatAppearance.BorderSize=0; $bCloseSvc.BackColor=[System.Drawing.Color]::FromArgb(55,65,81); $bCloseSvc.ForeColor=[System.Drawing.Color]::White
					$bCloseSvc.Add_Click({ $f.Close() })
					$pTop.Controls.AddRange(@($bStartSvc,$bStopSvc,$bRefSvc,$bServMsc,$bCloseSvc))
					[void]$f.ShowDialog()
				})

				# ── Scan Reseau ───────────────────────────────────────────────
				$b61.Add_Click({
					Add-Type -AssemblyName System.Windows.Forms, System.Drawing
					$f=New-Object System.Windows.Forms.Form; $f.Text="Scan Reseau — Trafic & Connexions"
					$f.Size=New-Object System.Drawing.Size(1000,600); $f.StartPosition="CenterScreen"; $f.BackColor=[System.Drawing.Color]::FromArgb(15,23,42)
					$tlp=New-Object System.Windows.Forms.TableLayoutPanel; $tlp.Dock="Fill"; $tlp.RowCount=3; $tlp.ColumnCount=1
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,52)))
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,50)))
					$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,50)))
					$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$f.Controls.Add($tlp)
					$hdr=New-Object System.Windows.Forms.Panel; $hdr.BackColor=[System.Drawing.Color]::FromArgb(6,78,59); $hdr.Dock="Fill"
					$tlpHdr=New-Object System.Windows.Forms.TableLayoutPanel; $tlpHdr.Dock="Fill"; $tlpHdr.RowCount=1; $tlpHdr.ColumnCount=2
					$tlpHdr.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
					$tlpHdr.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute,440)))
					$tlpHdr.BackColor=[System.Drawing.Color]::FromArgb(6,78,59)
					$lbH=New-Object System.Windows.Forms.Label; $lbH.Text="  Scan Reseau — Trafic temps reel, connexions actives, anomalies"
					$lbH.ForeColor=[System.Drawing.Color]::White; $lbH.Font=New-Object System.Drawing.Font("Segoe UI Semibold",10); $lbH.Dock="Fill"; $lbH.TextAlign="MiddleLeft"
					$tlpHdr.Controls.Add($lbH,0,0)
					$hdr.Controls.Add($tlpHdr); $tlp.Controls.Add($hdr,0,0)
					$dgvSR=New-Object System.Windows.Forms.DataGridView; $dgvSR.Dock="Fill"; $dgvSR.ReadOnly=$true; $dgvSR.AllowUserToAddRows=$false
					$dgvSR.SelectionMode="FullRowSelect"; $dgvSR.RowHeadersVisible=$false; $dgvSR.AutoSizeColumnsMode="None"
					$dgvSR.BackgroundColor=[System.Drawing.Color]::FromArgb(30,41,59); $dgvSR.GridColor=[System.Drawing.Color]::FromArgb(55,65,81)
					$dgvSR.DefaultCellStyle.BackColor=[System.Drawing.Color]::FromArgb(30,41,59); $dgvSR.DefaultCellStyle.ForeColor=[System.Drawing.Color]::FromArgb(209,213,219)
					$dgvSR.Font=New-Object System.Drawing.Font("Consolas",8)
					$dgvSR.ColumnHeadersDefaultCellStyle.BackColor=[System.Drawing.Color]::FromArgb(6,78,59); $dgvSR.ColumnHeadersDefaultCellStyle.ForeColor=[System.Drawing.Color]::White
					$dgvSR.EnableHeadersVisualStyles=$false
					$colDefs = @(("Proto",55),("IP Locale",145),("Port",55),("IP Distante",145),("Port Dist",55),("Etat",110),("Processus",150),("PID",55))
					foreach ($cd in $colDefs) {
						$c=New-Object System.Windows.Forms.DataGridViewTextBoxColumn; $c.HeaderText=$cd[0]; $c.Name=$cd[0]; $c.Width=$cd[1]; $c.MinimumWidth=40
						$dgvSR.Columns.Add($c) | Out-Null
					}
					$dgvSR.Columns["Processus"].AutoSizeMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
					$tlp.Controls.Add($dgvSR,0,1)
					$rtbSR=New-Object System.Windows.Forms.RichTextBox; $rtbSR.Dock="Fill"; $rtbSR.ReadOnly=$true
					$rtbSR.BackColor=[System.Drawing.Color]::FromArgb(15,23,42); $rtbSR.ForeColor=[System.Drawing.Color]::FromArgb(209,213,219)
					$rtbSR.Font=New-Object System.Drawing.Font("Consolas",8); $rtbSR.BorderStyle="None"
					$tlp.Controls.Add($rtbSR,0,2)
					$script:scanning=$false; $script:prevStats=@{}
					function Refresh-GridSR {
						$dgvSR.SuspendLayout()
						try {
							$dgvSR.Rows.Clear()
							$procs = Get-Process -ErrorAction SilentlyContinue | Group-Object Id -AsHashTable -AsString
							try { Get-NetTCPConnection -ErrorAction SilentlyContinue | ForEach-Object { $pName = if ($procs["$($_.OwningProcess)"]) { $procs["$($_.OwningProcess)"][0].ProcessName } else { "?" }; $dgvSR.Rows.Add("TCP",[string]$_.LocalAddress,[string]$_.LocalPort,[string]$_.RemoteAddress,[string]$_.RemotePort,[string]$_.State,$pName,[string]$_.OwningProcess) | Out-Null } } catch {}
							try { Get-NetUDPEndpoint -ErrorAction SilentlyContinue | ForEach-Object { $pName = if ($procs["$($_.OwningProcess)"]) { $procs["$($_.OwningProcess)"][0].ProcessName } else { "?" }; $dgvSR.Rows.Add("UDP",[string]$_.LocalAddress,[string]$_.LocalPort,"*","*","",$pName,[string]$_.OwningProcess) | Out-Null } } catch {}
						} finally { $dgvSR.ResumeLayout() }
					}
					function Check-AnomaliesSR {
						$rtbSR.Clear(); $ts=Get-Date -Format "HH:mm:ss"
						$stats=Get-NetAdapterStatistics -ErrorAction SilentlyContinue
						foreach ($s in $stats) {
							$key=$s.Name; $prev=$script:prevStats[$key]
							if ($prev) {
								$sentDiff=[math]::Round(($s.SentBytes-$prev.SentBytes)/1KB,1); $recvDiff=[math]::Round(($s.ReceivedBytes-$prev.ReceivedBytes)/1KB,1)
								$color=if($sentDiff-gt 500-or$recvDiff-gt 500){"Red"}elseif($sentDiff-gt 50-or$recvDiff-gt 50){"Yellow"}else{"Green"}
								$rtbSR.SelectionColor=switch($color){"Red"{[System.Drawing.Color]::FromArgb(248,113,113)}"Yellow"{[System.Drawing.Color]::FromArgb(251,191,36)}default{[System.Drawing.Color]::FromArgb(74,222,128)}}
								$rtbSR.AppendText("[$ts] $($s.Name) : ENV $sentDiff KB/s | RECV $recvDiff KB/s`n")
							}
							$script:prevStats[$key]=$s
						}
						$total = $dgvSR.Rows.Count
						$byProc = $dgvSR.Rows | Where-Object { -not $_.IsNewRow } | Group-Object { $_.Cells["Processus"].Value } | Sort-Object Count -Desc | Select-Object -First 5
						$rtbSR.SelectionColor=[System.Drawing.Color]::FromArgb(103,232,249)
						$rtbSR.AppendText("--- Top connexions par processus ($total total) ---`n")
						foreach ($g in $byProc) { $rtbSR.SelectionColor=[System.Drawing.Color]::FromArgb(209,213,219); $rtbSR.AppendText("  $($g.Name): $($g.Count) connexions`n") }
						$threshold=20
						foreach ($g in $byProc) { if ($g.Count -gt $threshold) { $rtbSR.SelectionColor=[System.Drawing.Color]::FromArgb(248,113,113); $rtbSR.AppendText("ANOMALIE: $($g.Name) a $($g.Count) connexions !`n") } }
					}
					$timerSR=New-Object System.Windows.Forms.Timer; $timerSR.Interval=3000
					$timerSR.Add_Tick({ if (-not $script:scanning) { return }; Refresh-GridSR; Check-AnomaliesSR })
					$pBtns=New-Object System.Windows.Forms.Panel; $pBtns.Dock="Fill"; $pBtns.BackColor=[System.Drawing.Color]::FromArgb(6,78,59)
					$tlpHdr.Controls.Add($pBtns,1,0)
					$bStartSR=New-Object System.Windows.Forms.Button; $bStartSR.Text="▶ Demarrer"; $bStartSR.Size=New-Object System.Drawing.Size(130,36); $bStartSR.Location=New-Object System.Drawing.Point(4,7)
					$bStartSR.FlatStyle="Flat"; $bStartSR.FlatAppearance.BorderSize=0; $bStartSR.BackColor=[System.Drawing.Color]::FromArgb(22,163,74); $bStartSR.ForeColor=[System.Drawing.Color]::White
					$bStop2SR=New-Object System.Windows.Forms.Button; $bStop2SR.Text="■ Arreter"; $bStop2SR.Size=New-Object System.Drawing.Size(110,36); $bStop2SR.Location=New-Object System.Drawing.Point(142,7)
					$bStop2SR.FlatStyle="Flat"; $bStop2SR.FlatAppearance.BorderSize=0; $bStop2SR.BackColor=[System.Drawing.Color]::FromArgb(220,38,38); $bStop2SR.ForeColor=[System.Drawing.Color]::White
					$bFermerSR=New-Object System.Windows.Forms.Button; $bFermerSR.Text="✕ Fermer"; $bFermerSR.Size=New-Object System.Drawing.Size(100,36); $bFermerSR.Location=New-Object System.Drawing.Point(260,7)
					$bFermerSR.FlatStyle="Flat"; $bFermerSR.FlatAppearance.BorderSize=0; $bFermerSR.BackColor=[System.Drawing.Color]::FromArgb(55,65,81); $bFermerSR.ForeColor=[System.Drawing.Color]::White
					$bStartSR.Add_Click({ $script:scanning=$true; $timerSR.Start(); $bStartSR.Enabled=$false; $bStop2SR.Enabled=$true })
					$bStop2SR.Add_Click({ $script:scanning=$false; $timerSR.Stop(); $bStartSR.Enabled=$true; $bStop2SR.Enabled=$false })
					$bFermerSR.Add_Click({ $timerSR.Stop(); $f.Close() })
					$bStop2SR.Enabled=$false
					$pBtns.Controls.AddRange(@($bStartSR,$bStop2SR,$bFermerSR))
					$f.Add_FormClosing({ $timerSR.Stop() })
					Refresh-GridSR
					$rtbSR.AppendText("$($dgvSR.Rows.Count) connexions chargees. Cliquez Demarrer pour le scan en temps reel (refresh 3s).`n")
					[void]$f.ShowDialog()
				})

				$b62 = New-SubBtn2 "CrystalDiskInfo"  99  102 241  0 3
				$b63 = New-SubBtn2 "Rapport Batterie" 234  179   8  1 3

				# ── CrystalDiskInfo ──────────────────────────────────────────────────────────────
				$b62.Add_Click({
					Add-Type -AssemblyName System.Windows.Forms
					$paths = @(
						"$env:ProgramFiles\CrystalDiskInfo\DiskInfo64.exe",
						"$env:ProgramFiles(x86)\CrystalDiskInfo\DiskInfo.exe",
						"$env:LOCALAPPDATA\CrystalDiskInfo\DiskInfo64.exe"
					)
					$found = $paths | Where-Object { Test-Path $_ } | Select-Object -First 1
					if ($found) { Start-Process $found; return }
					$r = [System.Windows.Forms.MessageBox]::Show(
						"CrystalDiskInfo non trouve. Installer via winget ?",
						"CrystalDiskInfo", [System.Windows.Forms.MessageBoxButtons]::YesNo,
						[System.Windows.Forms.MessageBoxIcon]::Question)
					if ($r -eq "Yes") {
						try {
							$proc = Start-Process winget -ArgumentList "install --id CrystalDewWorld.CrystalDiskInfo --silent --accept-source-agreements --accept-package-agreements" -Wait -PassThru -WindowStyle Hidden -ErrorAction Stop
							if ($proc.ExitCode -eq 0) { [System.Windows.Forms.MessageBox]::Show("CrystalDiskInfo installé avec succès.", "OK") }
							else { [System.Windows.Forms.MessageBox]::Show("Échec winget (code $($proc.ExitCode)).", "Erreur") }
						} catch { [System.Windows.Forms.MessageBox]::Show("Erreur : $_") }
					}
				})

				# ── Rapport Batterie ──────────────────────────────────────────────────────────────
				$b63.Add_Click({
					$out = "$env:TEMP\battery_report.html"
					powercfg /batteryreport /output $out 2>$null
					if (Test-Path $out) { Start-Process $out }
					else { [System.Windows.Forms.MessageBox]::Show("Aucune batterie détectée ou erreur.") }
				})

				# ── Bouton Fermer (nettoyage + fermeture) ────────────────────────
				$bFermerSub = New-Object System.Windows.Forms.Button
				$bFermerSub.Text = "✕  Fermer"
				$bFermerSub.Size = New-Object System.Drawing.Size(580, 36)
				$bFermerSub.Location = New-Object System.Drawing.Point(30, 338)
				$bFermerSub.FlatStyle = "Flat"
				$bFermerSub.FlatAppearance.BorderSize = 0
				$bFermerSub.BackColor = [System.Drawing.Color]::FromArgb(55, 65, 81)
				$bFermerSub.ForeColor = [System.Drawing.Color]::White
				$bFermerSub.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)
				$bFermerSub.Cursor = "Hand"
				$bFermerSub.Add_Click({
					# Executer nettoyage.ps1 si present (apres validation syntaxique)
					$nettoyageScript = "$env:TEMP\nettoyage.ps1"
					if (Test-Path $nettoyageScript) {
						$scriptContent = Get-Content -Path $nettoyageScript -Raw -Encoding UTF8
						$syntaxValid = $true
						try { [void][scriptblock]::Create($scriptContent) } catch { $syntaxValid = $false }
						if ($scriptContent -and $syntaxValid) {
							Start-Process -FilePath "powershell.exe" -ArgumentList "-NoProfile -ExecutionPolicy Bypass -NoExit -File `"$nettoyageScript`""
						} else {
							[System.Windows.Forms.MessageBox]::Show("nettoyage.ps1 est vide ou invalide, execution annulee.", "Securite")
						}
					}
					# Nettoyage des fichiers temporaires
					$tempFolders = @($env:TEMP, $env:TMP, "$env:LOCALAPPDATA\Temp") | Where-Object { $_ } | Sort-Object -Unique
					foreach ($folder in $tempFolders) {
						if (-not (Test-Path $folder)) { continue }
						Get-ChildItem -Path $folder -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object { Remove-Item -Path $_.FullName -ErrorAction SilentlyContinue }
						Get-ChildItem -Path $folder -Directory -Recurse -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | ForEach-Object { if (-not (Get-ChildItem -Path $_.FullName -ErrorAction SilentlyContinue)) { Remove-Item -Path $_.FullName -ErrorAction SilentlyContinue } }
					}
					# Desinstaller DriversCloud si present
					if (Test-Path "C:\Program Files\Cybelsoft\DriversCloud.com") {
						Start-Process -Wait -FilePath "winget" -ArgumentList "uninstall --id=Cybelsoft.DriversCloud --silent"
					}
					# Auto-suppression du zip telecharge et du dossier extrait dans Telechargements
					$downloadsDir = Join-Path $env:USERPROFILE 'Downloads'
					$zipPath = Join-Path $downloadsDir 'MultInstall.zip'
					$extractedDir = Join-Path $downloadsDir 'MultInstall'
					Start-Process cmd -ArgumentList "/c timeout /t 3 /nobreak > nul && del /f /q `"$zipPath`" 2>nul && rmdir /s /q `"$extractedDir`" 2>nul" -WindowStyle Hidden
					$fSub.Close()
					$form.Close()
				})
				$fSub.Controls.Add($bFermerSub)

				[void]$fSub.ShowDialog()
			})
		}

		else
		{
			$button.BackColor = [System.Drawing.Color]::LightGray
			$button.ForeColor = [System.Drawing.Color]::Gray
			$button.Enabled = $false
		}
		
	# Journal: tracer l ouverture de chaque outil
	$button.Add_MouseDown({ try { if ($_.Button -eq [System.Windows.Forms.MouseButtons]::Left) { $t = $this.Text; if ($t -and $t.Trim() -and $t -ne "Journal Intervention") { Add-Journal ("Ouvre: " + $t) } } } catch {} })
	$form.Controls.Add($button)
}


# Position y du dernier bouton + hauteur du bouton + marge
$textBoxY = [Math]::Round($offsetY + ($buttonHeight + 10) * ([Math]::Ceiling(54 / $buttonsPerRow))) + 5

# Créer une zone de texte pour les commentaires
$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Location = New-Object System.Drawing.Point(35, $textBoxY) # Positionner la zone de texte en dessous des boutons
$textBoxHeight = $form.ClientSize.Height - $textBoxY - 120
$textBox.Size = New-Object System.Drawing.Size(1080, $textBoxHeight) # Utiliser la hauteur calculée pour la zone de texte
$textBox.Multiline = $true
$textBox.ScrollBars = 'Vertical' # Ajouter une barre de défilement verticale

$buttonFermer = New-Object RoundButton
$buttonFermer.Size = New-Object System.Drawing.Size(320, 48)
$buttonFermer.Location = New-Object System.Drawing.Point([int]($textBox.Left + ($textBox.Width / 2) - 160), ($textBox.Bottom + 12))
$buttonFermer.Text = "Fermer"
$buttonFermer.Font = $font # Appliquer la police au bouton
$buttonFermer.BackColor = [System.Drawing.Color]::FromArgb(220, 38, 38)
$buttonFermer.ForeColor = [System.Drawing.Color]::White
$buttonFermer.Add_MouseEnter({
		$buttonFermer.BackColor = [System.Drawing.Color]::FromArgb(239, 68, 68)
	})
$buttonFermer.Add_MouseLeave({
		$buttonFermer.BackColor = [System.Drawing.Color]::FromArgb(220, 38, 38)
	})
$buttonFermer.Add_Click({

		# 0. Exécuter nettoyage.ps1 dans une nouvelle fenêtre (après validation syntaxique)
		$nettoyageScript = "$env:TEMP\nettoyage.ps1"
		if (Test-Path $nettoyageScript)
		{
			$scriptContent = Get-Content -Path $nettoyageScript -Raw -Encoding UTF8
			$syntaxValid = $true
			try { [void][scriptblock]::Create($scriptContent) } catch { $syntaxValid = $false }
			if ($scriptContent -and $syntaxValid)
			{
				$textBox.AppendText("Exécution du script de nettoyage..." + [Environment]::NewLine)
				[System.Windows.Forms.Application]::DoEvents()
				Start-Process -FilePath "powershell.exe" `
					-ArgumentList "-NoProfile -ExecutionPolicy Bypass -NoExit -File `"$nettoyageScript`""
			}
			else
			{
				$textBox.AppendText("⚠️ nettoyage.ps1 est vide ou invalide, exécution annulée." + [Environment]::NewLine)
				[System.Windows.Forms.Application]::DoEvents()
			}
		}

		# 1. Nettoyer les dossiers temporaires (skip fichiers verrouillés)
		$textBox.AppendText("Nettoyage des fichiers temporaires..." + [Environment]::NewLine)
		[System.Windows.Forms.Application]::DoEvents()

		$tempFolders = @($env:TEMP, $env:TMP, "$env:LOCALAPPDATA\Temp") |
			Where-Object { $_ } | Sort-Object -Unique

		foreach ($folder in $tempFolders)
		{
			if (-not (Test-Path $folder)) { continue }
			Get-ChildItem -Path $folder -File -Recurse -ErrorAction SilentlyContinue |
				ForEach-Object { Remove-Item -Path $_.FullName -ErrorAction SilentlyContinue }
			Get-ChildItem -Path $folder -Directory -Recurse -ErrorAction SilentlyContinue |
				Sort-Object FullName -Descending |
				ForEach-Object {
					if (-not (Get-ChildItem -Path $_.FullName -ErrorAction SilentlyContinue))
					{ Remove-Item -Path $_.FullName -ErrorAction SilentlyContinue }
				}
		}
		$textBox.AppendText("✅ Nettoyage terminé." + [Environment]::NewLine)
		[System.Windows.Forms.Application]::DoEvents()

		# 2. Désinstaller DriversCloud si présent
		$DriversCloudPath = "C:\Program Files\Cybelsoft\DriversCloud.com"
		if (Test-Path $DriversCloudPath)
		{
			Start-Process -Wait -FilePath "winget" -ArgumentList "uninstall --id=Cybelsoft.DriversCloud --silent"
		}

		# 3. Auto-suppression du zip telecharge et du dossier extrait dans Telechargements
		#    (délai CMD de 3 sec pour laisser le temps à l'appli de se fermer)
		$downloadsDir = Join-Path $env:USERPROFILE 'Downloads'
		$zipPath = Join-Path $downloadsDir 'MultInstall.zip'
		$extractedDir = Join-Path $downloadsDir 'MultInstall'
		Start-Process cmd -ArgumentList "/c timeout /t 3 /nobreak > nul && del /f /q `"$zipPath`" 2>nul && rmdir /s /q `"$extractedDir`" 2>nul" -WindowStyle Hidden

		# 3b. Suppression des profils WiFi enregistres pendant l'intervention
		$wifiProfilesToRemove = @("WIFI_IPv4", "ObjCo")
		foreach ($prof in $wifiProfilesToRemove)
		{
			netsh wlan delete profile name="$prof" 2>$null | Out-Null
		}

		# 4. Signaler la fermeture du journal puis fermer
		try { $jsig = [System.Threading.EventWaitHandle]::OpenExisting("Global\MultInstallJournalClose"); [void]$jsig.Set(); Start-Sleep -Milliseconds 1100 } catch {}
		$form.Close()
	})
$buttonx = New-Object System.Windows.Forms.Button
$buttonx.Location = New-Object System.Drawing.Point(1130, 10)
$buttonx.Size = New-Object System.Drawing.Size(10, 10)
$buttonx.Text = "X"
$buttonx.Font = $font # Appliquer la police au bouton
$buttonx.BackColor = [System.Drawing.Color]::White
$buttonx.Add_MouseEnter({

	})
$buttonx.Add_MouseLeave({
		$buttonx.BackColor = [System.Drawing.Color]::White
	})
$buttonx.Add_Click({
		try { $jsig = [System.Threading.EventWaitHandle]::OpenExisting("Global\MultInstallJournalClose"); [void]$jsig.Set(); Start-Sleep -Milliseconds 1100 } catch {}
		$form.Close()
	})
# URL du fichier à télécharger
$url = "https://github.com/Stephinfo/StephInstall/raw/main/nettoyage.ps1"

# Chemin pour sauvegarder le fichier téléchargé
$output = "$env:TEMP\nettoyage.ps1"

# Chemin pour le fichier journal (logfile)
$filePath = "$env:TEMP\logfile.txt"

# Créez le dossier s'il n'existe pas
if (-not (Test-Path "$env:TEMP"))
{
	New-Item -Path "$env:TEMP" -ItemType Directory -ErrorAction SilentlyContinue
}

# Créez le fichier journal (logfile) s'il n'existe pas
if (-not (Test-Path $filePath))
{
	New-Item -Path $filePath -ItemType File | Out-Null
	$textBox.AppendText("Fichier créé." + [Environment]::NewLine)
}
else
{
	$textBox.AppendText("Le fichier $filePath existe déjà. Il ne sera pas remplacé." + [Environment]::NewLine)
}
# Vérifiez si le fichier nettoyage.ps1 existe déjà
if (Test-Path $output)
{
	Add-Content -Path $filePath -Value "Le fichier $output existe déjà. Il sera écrasé."
}
# --- Suppression du zip MultInstall et du dossier extrait gérée par le bouton Fermer ---
# (La suppression est planifiée via CMD au moment où l'utilisateur clique sur Fermer)

# Téléchargez et écrasez le fichier
try
{
	Invoke-WebRequest -Uri $url -OutFile $output -UseBasicParsing -TimeoutSec 30
	Add-Content -Path $filePath -Value "Fichier nettoyage.ps1 téléchargé."
}
catch
{
	Add-Content -Path $filePath -Value "Erreur lors du téléchargement de nettoyage.ps1 : $_"
}

# Vérifiez si le fichier "nettoyage.ps1" est bien à sa place après le téléchargement
if (Test-Path $output)
{
	Add-Content -Path $filePath -Value "Le fichier nettoyage.ps1 est bien en place."
}
else
{
	Add-Content -Path $filePath -Value "Erreur : Le fichier nettoyage.ps1 est introuvable!"
}

# Vérifiez si "Dossiers Temp ok" est déjà dans le fichier
$content = Get-Content -Path $filePath
if ($content -notcontains "Dossiers Temp ok")
{
	Add-Content -Path $filePath -Value "Dossiers Temp ok"
}

$form.Controls.Add($textBox)
$form.Controls.Add($buttonFermer)
$form.Controls.Add($buttonx)
# Afficher le formulaire
Add-Journal ("===== Session MultInstall demarree sur " + $env:COMPUTERNAME + " (" + $env:USERNAME + ") =====")
Show-JournalWindow
[void]$form.ShowDialog()
